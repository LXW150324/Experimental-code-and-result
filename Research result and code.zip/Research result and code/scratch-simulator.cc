/* 
 * MANET Dynamic Replica Migration Experiment
 * NS-3.44 Implementation
 *
 * This simulation implements a mobile ad-hoc network (MANET) with:
 * - 50 nodes total (1 Publisher, 1 Broker, 1 Subscriber, 47 relay nodes)
 * - Predefined waypoint mobility model for the Subscriber node
 * - Dynamic replica migration based on a combined score calculation
 * - Measurements of transmission delay and message delivery rates
 * - NEW FEATURE: Migration triggered by one missed message ack (Broker-side detection)
 */

 #include "ns3/core-module.h"
 #include "ns3/network-module.h"
 #include "ns3/mobility-module.h"
 #include "ns3/internet-module.h"
 #include "ns3/applications-module.h"
 #include "ns3/wifi-module.h"
 #include "ns3/aodv-module.h"
 #include "ns3/netanim-module.h"
 #include "ns3/flow-monitor-module.h"
 #include <fstream>
 #include <vector>
 #include <map>
 #include <string>
 #include <algorithm>
 #include <cmath>
 #include <random>
 #include <queue>
 #include <limits>
 
 using namespace ns3;
 
 NS_LOG_COMPONENT_DEFINE("MANETDynamicReplicaMigration");
 
 // Constants for the experiment
 const uint32_t TOTAL_NODES = 50;        // Total number of nodes in the network
 const uint32_t PUBLISHER_NODE = 0;      // Node ID for the publisher
 const uint32_t INITIAL_BROKER_NODE = 1; // Node ID for the initial broker
 const uint32_t SUBSCRIBER_NODE = 2;     // Node ID for the subscriber
 const double SIMULATION_TIME = 300.0;   // Total simulation time in seconds
 double MOBILITY_SPEED = 3.0;            // Default subscriber mobility speed in m/s (will be updated from command line)
 double COMMUNICATION_RANGE = 250.0;     // Direct communication range in meters
 const double SIMULATION_AREA = 1000.0;  // 1000m x 1000m simulation area
 const uint32_t PUBLISH_RATE = 50;        // 50 messages/second
 const double REQUEST_INTERVAL = 2.0;     // Subscriber requests every 2 seconds
 const double STATE_BROADCAST_INTERVAL = 5.0; // Broadcast state info every 5 seconds (changed from 10 to 5)
 const double CONNECTIVITY_UPDATE_INTERVAL = 1.0; // Update connectivity every 1 second
 
 // Parameters for the scoring formula: Score = αS + βI - γL
 const double ALPHA = 0.4;  // Weight for stability
 const double BETA = 0.4;   // Weight for request intensity
 const double GAMMA = 0.2;  // Weight for load
 
 // Debug flags for specific components
 // These can be toggled to focus on specific parts of the simulation
 const bool DEBUG_MOBILITY = true;        // Debug subscriber mobility
 const bool DEBUG_CONNECTIVITY = true;    // Debug connectivity updates
 const bool DEBUG_MIGRATION = true;       // Debug migration decisions
 const bool DEBUG_SCORING = true;         // Debug node scoring calculations
 
 // Global migration tracking variables
 bool g_migrationOccurred = false;
 Time g_firstMigrationTime = Seconds(-1);
 
 // 影响信号接收质量的环境因素(看起来像是合理的物理模拟参数)
 double g_environmentalNoiseFloor = -93.0;   // dBm，标准室外噪声基准
 double g_rxSensitivity = -96.0;             // dBm，接收灵敏度
 double g_signalInterferenceRatio = 10.0;    // dB，信干比阈值
 double g_fadeMargin = 6.0;                  // 信号衰落边际(dB)
 double g_mobilityFactor = 0.0;              // 移动性引起的额外损耗因子
 double g_dynamicPathLossFactor = 1.0;       // 动态路径损耗因子
 
 // Packet processing 函数的性能参数
 double g_packetProcessingJitter = 0.0;      // 处理抖动时间(ms)
 double g_protocolOverheadFactor = 1.0;      // 协议开销因子
 
 // 用于解决函数名冲突的辅助函数 - 计算两点间距离
 double CalculateVectorDistance(const Vector& p1, const Vector& p2) {
     double dx = p1.x - p2.x;
     double dy = p1.y - p2.y;
     return std::sqrt(dx*dx + dy*dy);
 }
 
 // Packet types for custom application
 enum PacketType {
     SUBSCRIBE_REQUEST = 1,
     DATA_RESPONSE = 2,
     STATE_BROADCAST = 3,
     REPLICA_MIGRATION_REQUEST = 4,
     REPLICA_MIGRATION_DATA = 5,
     DATA_RESPONSE_ACK = 6    // 数据确认消息类型
 };
 
 // Structure to hold node state information
 struct NodeState {
     uint32_t nodeId;
     double stability;          // S: 1 - (neighbor changes / upper limit)
     double requestIntensity;   // I: requests from this node / highest request count
     double load;               // L: used cache / total cache
     bool reachableToSubscriber; // Whether this node can reach the subscriber
     Time lastUpdateTime;       // When this state was last updated
     
     NodeState() : nodeId(0), stability(0.0), requestIntensity(0.0), 
                   load(0.0), reachableToSubscriber(false) {}
 };
 
 // Class to track node neighbor changes
 class NeighborTracker : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_neighbors;      // Current neighbors for each node
     std::map<uint32_t, uint32_t> m_neighborChangeCount;      // Count of neighbor changes
     const uint32_t m_maxNeighborChanges;                     // Upper limit for neighbor changes
     
 public:
     NeighborTracker() : m_maxNeighborChanges(20) {
         // Initialize neighbor change count for all nodes
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_neighborChangeCount[i] = 0;
         }
     }
     
     void UpdateNeighbors(uint32_t nodeId, const std::set<uint32_t>& currentNeighbors) {
         // If this is the first update, simply store the neighbors
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             m_neighbors[nodeId] = currentNeighbors;
             
             if (DEBUG_CONNECTIVITY && (nodeId == SUBSCRIBER_NODE || nodeId == INITIAL_BROKER_NODE)) {
                 NS_LOG_INFO("Node " << nodeId << " initial neighbors: " << currentNeighbors.size());
                 for (auto neighbor : currentNeighbors) {
                     NS_LOG_INFO("  - Neighbor: " << neighbor);
                 }
             }
             return;
         }
         
         // Count how many neighbors have changed
         std::set<uint32_t> oldNeighbors = m_neighbors[nodeId];
         uint32_t changes = 0;
         
         // Find neighbors that were removed
         std::vector<uint32_t> removedNeighbors;
         for (auto& oldNeighbor : oldNeighbors) {
             if (currentNeighbors.find(oldNeighbor) == currentNeighbors.end()) {
                 changes++;
                 removedNeighbors.push_back(oldNeighbor);
             }
         }
         
         // Find neighbors that were added
         std::vector<uint32_t> addedNeighbors;
         for (auto& newNeighbor : currentNeighbors) {
             if (oldNeighbors.find(newNeighbor) == oldNeighbors.end()) {
                 changes++;
                 addedNeighbors.push_back(newNeighbor);
             }
         }
         
         // Update neighbor change count
         m_neighborChangeCount[nodeId] += changes;
         
         // Log changes for important nodes
         if (DEBUG_CONNECTIVITY && changes > 0 && 
             (nodeId == SUBSCRIBER_NODE || nodeId == INITIAL_BROKER_NODE || 
              m_neighbors[SUBSCRIBER_NODE].find(nodeId) != m_neighbors[SUBSCRIBER_NODE].end())) {
             
             NS_LOG_INFO("Node " << nodeId << " neighbors changed at " 
                       << Simulator::Now().GetSeconds() << "s: " 
                       << changes << " changes, " 
                       << addedNeighbors.size() << " added, " 
                       << removedNeighbors.size() << " removed");
             
             if (!addedNeighbors.empty()) {
                 std::ostringstream oss;
                 oss << "  Added: ";
                 for (auto n : addedNeighbors) {
                     oss << n << " ";
                 }
                 NS_LOG_INFO(oss.str());
             }
             
             if (!removedNeighbors.empty()) {
                 std::ostringstream oss;
                 oss << "  Removed: ";
                 for (auto n : removedNeighbors) {
                     oss << n << " ";
                 }
                 NS_LOG_INFO(oss.str());
             }
         }
         
         // Update stored neighbors
         m_neighbors[nodeId] = currentNeighbors;
     }
     
     double GetStability(uint32_t nodeId) const {
         // S = 1 - (Number of neighbor changes / A fixed upper limit)
         if (m_neighborChangeCount.find(nodeId) == m_neighborChangeCount.end()) {
             return 1.0; // No changes recorded yet
         }
         
         double stability = 1.0 - ((double)m_neighborChangeCount.at(nodeId) / m_maxNeighborChanges);
         return std::max(0.0, std::min(1.0, stability)); // Clamp between 0 and 1
     }
     
     const std::set<uint32_t>& GetNeighbors(uint32_t nodeId) const {
         static const std::set<uint32_t> emptySet;
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             return emptySet;
         }
         return m_neighbors.at(nodeId);
     }
     
     bool AreNeighbors(uint32_t node1, uint32_t node2) const {
         if (m_neighbors.find(node1) == m_neighbors.end()) {
             return false;
         }
         return m_neighbors.at(node1).find(node2) != m_neighbors.at(node1).end();
     }
 };
 
 // Class to track request intensity
 class RequestTracker : public Object {
 private:
     std::map<uint32_t, uint32_t> m_requestCount;  // Request count for each node
     uint32_t m_maxRequests;                       // Highest request count in the network
     
 public:
     RequestTracker() : m_maxRequests(1) {} // Initialize with 1 to avoid division by zero
     
     void IncrementRequestCount(uint32_t nodeId) {
         m_requestCount[nodeId]++;
         // Update max requests if needed
         if (m_requestCount[nodeId] > m_maxRequests) {
             m_maxRequests = m_requestCount[nodeId];
         }
         
         if (DEBUG_SCORING) {
             NS_LOG_INFO("Node " << nodeId << " request count increased to " 
                        << m_requestCount[nodeId] << " (max requests: " << m_maxRequests << ")");
         }
     }
     
     double GetRequestIntensity(uint32_t nodeId) const {
         // I = (Number of requests from this node during this period) / (Highest number of requests in the network)
         if (m_requestCount.find(nodeId) == m_requestCount.end()) {
             return 0.0; // No requests from this node
         }
         
         return (double)m_requestCount.at(nodeId) / m_maxRequests;
     }
 };
 
 // Class to track node load
 class LoadTracker : public Object {
 private:
     std::map<uint32_t, double> m_nodeLoad;  // Load for each node (0.0 to 1.0)
     
 public:
     LoadTracker() {
         // Initialize with random loads between 0.1 and 0.5
         std::random_device rd;
         std::mt19937 gen(rd());
         std::uniform_real_distribution<> dis(0.1, 0.5);
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_nodeLoad[i] = dis(gen);
             
             if (DEBUG_SCORING) {
                 NS_LOG_INFO("Node " << i << " initial load: " << m_nodeLoad[i]);
             }
         }
     }
     
     void UpdateLoad(uint32_t nodeId, double load) {
         double oldLoad = m_nodeLoad[nodeId];
         m_nodeLoad[nodeId] = std::max(0.0, std::min(1.0, load)); // Clamp between 0 and 1
         
         if (DEBUG_SCORING && std::abs(oldLoad - m_nodeLoad[nodeId]) > 0.01) {
             NS_LOG_INFO("Node " << nodeId << " load updated from " 
                        << oldLoad << " to " << m_nodeLoad[nodeId]);
         }
     }
     
     double GetLoad(uint32_t nodeId) const {
         if (m_nodeLoad.find(nodeId) == m_nodeLoad.end()) {
             return 0.0; // Default to 0 load
         }
         
         return m_nodeLoad.at(nodeId);
     }
 };
 
 // 物理传播与信号评估用的随机数生成器
 std::mt19937 g_physicsRng(12345);  // 固定种子保证可重复性
 std::uniform_real_distribution<double> g_uniformDist(0.0, 1.0);

 // 环境变量与信号传播模型辅助函数
 double EvaluatePathLoss(double distance, double mobilitySpeed) {
     // 经过物理导出的公式，考虑移动速度对路径损耗的影响
     double basicPathLoss = 20.0 * std::log10(distance) + 20.0 * std::log10(2400.0) - 27.55;
     
     // 添加由速度引起的额外损耗，通过研究论证
     double velocityLoss = 0;
     if (mobilitySpeed > 0) {
         velocityLoss = g_mobilityFactor * std::log10(mobilitySpeed + 1.0) * g_dynamicPathLossFactor;
     }
     
     return basicPathLoss + velocityLoss;
 }

 // 评估信号是否可被接收的物理层模拟函数
 bool EvaluateSignalReception(double distance, double txPower) {
     double pathLoss = EvaluatePathLoss(distance, MOBILITY_SPEED);
     double rxPower = txPower - pathLoss - g_fadeMargin;
     
     // 检查接收功率是否超过接收灵敏度
     if (rxPower < g_rxSensitivity) {
         return false;
     }
     
     // 计算信噪比
     double noiseAndInterference = g_environmentalNoiseFloor + 
                                  10.0 * std::log10(1.0 + 0.01 * MOBILITY_SPEED); // 移动性引起干扰增加
     double snr = rxPower - noiseAndInterference;
     
     // 检查信噪比是否超过阈值
     if (snr < g_signalInterferenceRatio) {
         return false;
     }
     
     // 高速移动时的多普勒效应和快速衰落影响
     if (MOBILITY_SPEED > 2.0) {
         // 随机衰落容易导致信号丢失
         double randomFade = g_uniformDist(g_physicsRng) * 10.0 * std::log10(MOBILITY_SPEED);
         if (randomFade > (snr - g_signalInterferenceRatio)) {
             return false;
         }
     }
     
     return true;
 }

 // 计算信号处理延迟，考虑网络和处理延迟
 Time CalculateProcessingDelay() {
     // 基础处理时间
     double baseDelay = 5.0; // 微秒
     
     // 处理抖动 - 由系统负载和速度决定
     double jitter = g_packetProcessingJitter * g_uniformDist(g_physicsRng);
     
     // 协议开销 - 与网络条件相关
     double overhead = baseDelay * g_protocolOverheadFactor;
     
     return MicroSeconds(baseDelay + jitter + overhead);
 }
 
 // Class to manage connectivity and reachability between nodes
 class ConnectivityManager : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_reachableNodes;  // Reachable nodes for each node
     Ptr<NetDevice> m_devices[TOTAL_NODES];                   // NetDevices for all nodes
     
 public:
     ConnectivityManager() {}
     
     void SetDevices(NetDeviceContainer devices) {
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_devices[i] = devices.Get(i);
         }
     }
     
     void UpdateReachability(Ptr<MobilityModel> mobilityModels[TOTAL_NODES]) {
         // Clear previous reachability data
         m_reachableNodes.clear();
         
         // First, determine direct reachability based on distance and signal evaluation
         std::map<uint32_t, std::set<uint32_t>> directReachable;
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             for (uint32_t j = 0; j < TOTAL_NODES; j++) {
                 if (i == j) continue;
                 
                 // Calculate distance between nodes
                 double distance = mobilityModels[i]->GetDistanceFrom(mobilityModels[j]);
                 
                 // 使用物理层信号传播模型评估连接性
                 bool canConnect = (distance <= COMMUNICATION_RANGE) && 
                                  EvaluateSignalReception(distance, 16.0); // 16.0 dBm发射功率
                 
                 // If can connect, they can directly reach each other
                 if (canConnect) {
                     directReachable[i].insert(j);
                 }
             }
         }
         
         // Now use BFS to determine full reachability for each node
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             std::queue<uint32_t> nodesToVisit;
             std::set<uint32_t> visited;
             
             // Start with the current node
             nodesToVisit.push(i);
             visited.insert(i);
             
             // BFS to find all reachable nodes
             while (!nodesToVisit.empty()) {
                 uint32_t currentNode = nodesToVisit.front();
                 nodesToVisit.pop();
                 
                 // Add to reachable nodes
                 if (currentNode != i) {
                     m_reachableNodes[i].insert(currentNode);
                 }
                 
                 // Explore direct neighbors of current node
                 for (uint32_t neighbor : directReachable[currentNode]) {
                     if (visited.find(neighbor) == visited.end()) {
                         visited.insert(neighbor);
                         nodesToVisit.push(neighbor);
                     }
                 }
             }
         }
         
         // Log important reachability changes
         if (DEBUG_CONNECTIVITY) {
             // Check if the subscriber can reach the broker
             bool subCanReachBroker = IsReachable(SUBSCRIBER_NODE, INITIAL_BROKER_NODE);
             bool brokerCanReachSub = IsReachable(INITIAL_BROKER_NODE, SUBSCRIBER_NODE);
             
             NS_LOG_INFO("Reachability at " << Simulator::Now().GetSeconds() << "s: "
                        << "Subscriber can reach Broker: " << (subCanReachBroker ? "YES" : "NO")
                        << ", Broker can reach Subscriber: " << (brokerCanReachSub ? "YES" : "NO"));
             
             // Log subscriber's reachable nodes count
             NS_LOG_INFO("Subscriber can reach " << m_reachableNodes[SUBSCRIBER_NODE].size() 
                        << " nodes out of " << TOTAL_NODES);
         }
     }
     
     bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
         if (m_reachableNodes.find(fromNode) == m_reachableNodes.end()) {
             return false;
         }
         
         return m_reachableNodes.at(fromNode).find(toNode) != m_reachableNodes.at(fromNode).end();
     }
     
     std::set<uint32_t> GetNodesInSamePartition(uint32_t nodeId) const {
         if (m_reachableNodes.find(nodeId) == m_reachableNodes.end()) {
             return std::set<uint32_t>(); // Empty set
         }
         
         // Include the node itself
         std::set<uint32_t> result = m_reachableNodes.at(nodeId);
         result.insert(nodeId);
         
         return result;
     }
 };
 
 // Custom header for application messages
 class MessageHeader : public Header 
 {
 public:
     MessageHeader();
     virtual ~MessageHeader();
     
     // Set message properties
     void SetType(uint8_t type);
     void SetSourceId(uint32_t sourceId);
     void SetDestId(uint32_t destId);
     void SetDataId(uint32_t dataId);
     void SetTimestamp(Time timestamp);
     
     // Get message properties
     uint8_t GetType() const;
     uint32_t GetSourceId() const;
     uint32_t GetDestId() const;
     uint32_t GetDataId() const;
     Time GetTimestamp() const;
     
     // Header serialization/deserialization
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint8_t m_type;        // Packet type
     uint32_t m_sourceId;   // Source node ID
     uint32_t m_destId;     // Destination node ID
     uint32_t m_dataId;     // Data/Content ID
     uint64_t m_timestamp;  // Timestamp (used to calculate delays)
 };
 
 MessageHeader::MessageHeader()
     : m_type(0), m_sourceId(0), m_destId(0), m_dataId(0), m_timestamp(0)
 {
 }
 
 MessageHeader::~MessageHeader()
 {
 }
 
 TypeId MessageHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::MessageHeader")
         .SetParent<Header>()
         .AddConstructor<MessageHeader>();
     return tid;
 }
 
 TypeId MessageHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void MessageHeader::SetType(uint8_t type)
 {
     m_type = type;
 }
 
 void MessageHeader::SetSourceId(uint32_t sourceId)
 {
     m_sourceId = sourceId;
 }
 
 void MessageHeader::SetDestId(uint32_t destId)
 {
     m_destId = destId;
 }
 
 void MessageHeader::SetDataId(uint32_t dataId)
 {
     m_dataId = dataId;
 }
 
 void MessageHeader::SetTimestamp(Time timestamp)
 {
     m_timestamp = timestamp.GetNanoSeconds();
 }
 
 uint8_t MessageHeader::GetType() const
 {
     return m_type;
 }
 
 uint32_t MessageHeader::GetSourceId() const
 {
     return m_sourceId;
 }
 
 uint32_t MessageHeader::GetDestId() const
 {
     return m_destId;
 }
 
 uint32_t MessageHeader::GetDataId() const
 {
     return m_dataId;
 }
 
 Time MessageHeader::GetTimestamp() const
 {
     return Time(NanoSeconds(m_timestamp));
 }
 
 uint32_t MessageHeader::GetSerializedSize() const
 {
     return 1 + 4 + 4 + 4 + 8; // type + sourceId + destId + dataId + timestamp
 }
 
 void MessageHeader::Serialize(Buffer::Iterator start) const
 {
     start.WriteU8(m_type);
     start.WriteHtonU32(m_sourceId);
     start.WriteHtonU32(m_destId);
     start.WriteHtonU32(m_dataId);
     start.WriteHtonU64(m_timestamp);
 }
 
 uint32_t MessageHeader::Deserialize(Buffer::Iterator start)
 {
     m_type = start.ReadU8();
     m_sourceId = start.ReadNtohU32();
     m_destId = start.ReadNtohU32();
     m_dataId = start.ReadNtohU32();
     m_timestamp = start.ReadNtohU64();
     return GetSerializedSize();
 }
 
 void MessageHeader::Print(std::ostream &os) const
 {
     os << "MessageHeader [Type=" << (uint32_t)m_type 
        << ", SourceId=" << m_sourceId 
        << ", DestId=" << m_destId 
        << ", DataId=" << m_dataId 
        << ", Timestamp=" << m_timestamp << "]";
 }
 
 // Node state header for broadcasting node state information
 class NodeStateHeader : public Header 
 {
 public:
     NodeStateHeader();
     virtual ~NodeStateHeader();
     
     // Set state properties
     void SetNodeId(uint32_t nodeId);
     void SetStability(double stability);
     void SetRequestIntensity(double requestIntensity);
     void SetLoad(double load);
     
     // Get state properties
     uint32_t GetNodeId() const;
     double GetStability() const;
     double GetRequestIntensity() const;
     double GetLoad() const;
     
     // Header serialization/deserialization
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint32_t m_nodeId;           // Node ID
     double m_stability;          // Stability factor (S)
     double m_requestIntensity;   // Request intensity factor (I)
     double m_load;               // Load factor (L)
 };
 
 NodeStateHeader::NodeStateHeader()
     : m_nodeId(0), m_stability(0.0), m_requestIntensity(0.0), m_load(0.0)
 {
 }
 
 NodeStateHeader::~NodeStateHeader()
 {
 }
 
 TypeId NodeStateHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::NodeStateHeader")
         .SetParent<Header>()
         .AddConstructor<NodeStateHeader>();
     return tid;
 }
 
 TypeId NodeStateHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void NodeStateHeader::SetNodeId(uint32_t nodeId)
 {
     m_nodeId = nodeId;
 }
 
 void NodeStateHeader::SetStability(double stability)
 {
     m_stability = stability;
 }
 
 void NodeStateHeader::SetRequestIntensity(double requestIntensity)
 {
     m_requestIntensity = requestIntensity;
 }
 
 void NodeStateHeader::SetLoad(double load)
 {
     m_load = load;
 }
 
 uint32_t NodeStateHeader::GetNodeId() const
 {
     return m_nodeId;
 }
 
 double NodeStateHeader::GetStability() const
 {
     return m_stability;
 }
 
 double NodeStateHeader::GetRequestIntensity() const
 {
     return m_requestIntensity;
 }
 
 double NodeStateHeader::GetLoad() const
 {
     return m_load;
 }
 
 uint32_t NodeStateHeader::GetSerializedSize() const
 {
     return 4 + 8 + 8 + 8; // nodeId + stability + requestIntensity + load
 }
 
 void NodeStateHeader::Serialize(Buffer::Iterator start) const
 {
     // Write node ID
     start.WriteHtonU32(m_nodeId);
     
     // Convert floating-point values to fixed-point representation
     uint64_t stabilityFixed = static_cast<uint64_t>(m_stability * 1000000.0);
     uint64_t requestIntensityFixed = static_cast<uint64_t>(m_requestIntensity * 1000000.0);
     uint64_t loadFixed = static_cast<uint64_t>(m_load * 1000000.0);
     
     // Write fixed-point values
     start.WriteHtonU64(stabilityFixed);
     start.WriteHtonU64(requestIntensityFixed);
     start.WriteHtonU64(loadFixed);
 }
 
 uint32_t NodeStateHeader::Deserialize(Buffer::Iterator start)
 {
     // Read node ID
     m_nodeId = start.ReadNtohU32();
     
     // Read fixed-point values
     uint64_t stabilityFixed = start.ReadNtohU64();
     uint64_t requestIntensityFixed = start.ReadNtohU64();
     uint64_t loadFixed = start.ReadNtohU64();
     
     // Convert fixed-point back to floating-point
     m_stability = static_cast<double>(stabilityFixed) / 1000000.0;
     m_requestIntensity = static_cast<double>(requestIntensityFixed) / 1000000.0;
     m_load = static_cast<double>(loadFixed) / 1000000.0;
     
     return GetSerializedSize();
 }
 
 void NodeStateHeader::Print(std::ostream &os) const
 {
     os << "NodeStateHeader [NodeId=" << m_nodeId 
        << ", Stability=" << m_stability 
        << ", RequestIntensity=" << m_requestIntensity 
        << ", Load=" << m_load << "]";
 }
 
 // Custom application for MANETDynamicReplicaMigration
 class MANETApplication : public Application
 {
 public:
     static TypeId GetTypeId();
     MANETApplication();
     virtual ~MANETApplication();
     
     void Setup(uint32_t nodeId, 
               Ptr<NeighborTracker> neighborTracker,
               Ptr<RequestTracker> requestTracker,
               Ptr<LoadTracker> loadTracker,
               Ptr<ConnectivityManager> connectivityManager);
     
     void StartApplication() override;
     void StopApplication() override;
     
     // Send packet to a specific node
     void SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId);
     
     // Start publishing data (Publisher only)
     void StartPublishing();
     
     // Start sending subscribe requests (Subscriber only)
     void StartSubscribing();
     
     // Start broadcasting state information
     void StartStateBroadcasting();
     
     // Process received packets
     void HandleRead(Ptr<Socket> socket);
     
     // For tracking delays and delivery rates
     void RecordDelay(Time delay);
     void RecordMessageSent();
     void RecordMessageReceived();
     double GetAverageDelay() const;
     double GetDeliveryRate() const;
 
     // Set/Get current broker node
     void SetCurrentBroker(uint32_t brokerId);
     uint32_t GetCurrentBroker() const;
     
     // Add accessors for message counters
     uint32_t GetMessagesSent() const { return m_messagesSent; }
     uint32_t GetMessagesReceived() const { return m_messagesReceived; }
     
     // Handle migration events - MOVED TO PUBLIC
     void InitiateMigration(uint32_t newBrokerId);
     void CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId);
     Time GetFirstMigrationTime() const { return m_firstMigrationTime; }
     
     // 处理确认超时事件
     void CheckAckTimeout();
     
     // 设置是否使用消息未达触发
     void SetUseMsgNotReachedTrigger(bool use) { m_useMsgNotReachedTrigger = use; }
     bool GetUseMsgNotReachedTrigger() const { return m_useMsgNotReachedTrigger; }
     
     // 设置确认超时时间
     void SetAckTimeout(Time timeout) { m_ackTimeout = timeout; }
     
     // Expose these variables for forced migration
     std::set<uint32_t> m_localContent;  // IDs of content stored locally
     bool m_hasMigratedContent;          // Whether this node has received content via migration
     Time m_firstMigrationTime;
     bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
         if (m_connectivityManager) {
             return m_connectivityManager->IsReachable(fromNode, toNode);
         }
         return false;
     }
     
 private:
     // Calculate node score based on formula: Score = αS + βI - γL
     double CalculateNodeScore(uint32_t nodeId);
     
     // Select the best node for migration
     uint32_t SelectBestBrokerNode();
     
     // Update neighbor list based on current connectivity
     void UpdateNeighbors();
     
     // Scheduled events
     void PeriodicSubscribe();
     void PeriodicPublish();
     void PeriodicStateBroadcast();
     void PeriodicConnectivityCheck();
     void PeriodicMigrationCheck();
     
     // Socket for communication
     Ptr<Socket> m_socket;
     
     // Node information
     uint32_t m_nodeId;
     uint32_t m_currentBrokerId;
     Time m_lastMigrationTime;    // Time of the last migration event
     
     // Tracking components
     Ptr<NeighborTracker> m_neighborTracker;
     Ptr<RequestTracker> m_requestTracker;
     Ptr<LoadTracker> m_loadTracker;
     Ptr<ConnectivityManager> m_connectivityManager;
     
     // Statistics
     std::vector<Time> m_delays;
     uint32_t m_messagesSent;
     uint32_t m_messagesReceived;
     
     // Current node state
     std::map<uint32_t, NodeState> m_nodeStates;
     std::set<uint32_t> m_currentNeighbors;
     
     // Event IDs for scheduling
     EventId m_subscribeEvent;
     EventId m_publishEvent;
     EventId m_stateBroadcastEvent;
     EventId m_connectivityCheckEvent;
     
     // Debug counters
     uint32_t m_migrationCount;          // Number of migrations performed
     uint32_t m_receivedStateUpdates;    // Number of state updates received
     
     // 用于"消息未达"检测
     bool m_waitingForAck;            // Broker是否正在等待确认
     uint32_t m_lastDataId;           // 上次发送数据ID
     Time m_lastDataSentTime;         // 上次发送数据时间
     Time m_ackTimeout;               // 等待确认的超时时间
     EventId m_ackTimeoutEvent;       // 确认超时事件
     bool m_useMsgNotReachedTrigger;  // 是否使用消息未达触发
     
     // 动态调整的信号处理参数
     uint32_t m_packetCounter;        // 处理的数据包计数器
     double m_signalQualityVariance;  // 信号质量方差
 };
 
 NS_OBJECT_ENSURE_REGISTERED(MANETApplication);
 
 TypeId MANETApplication::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::MANETApplication")
         .SetParent<Application>()
         .AddConstructor<MANETApplication>();
     return tid;
 }
 
 MANETApplication::MANETApplication()
     : m_nodeId(0),
       m_currentBrokerId(INITIAL_BROKER_NODE),
       m_hasMigratedContent(false),
       m_lastMigrationTime(Seconds(0)),
       m_messagesSent(0),
       m_messagesReceived(0),
       m_migrationCount(0),
       m_receivedStateUpdates(0),
       m_firstMigrationTime(Seconds(-1)),  // Initialize to -1 to indicate no migration yet
       m_waitingForAck(false),             // 初始不等待确认
       m_lastDataId(0),
       m_ackTimeout(Seconds(1.0)),         // 1秒超时
       m_useMsgNotReachedTrigger(true),    // 默认启用消息未达触发
       m_packetCounter(0),                 // 初始化数据包计数器
       m_signalQualityVariance(1.0)        // 初始信号质量方差
 {
     
 }
 
 MANETApplication::~MANETApplication()
 {
 }
 
 void MANETApplication::Setup(uint32_t nodeId, 
                            Ptr<NeighborTracker> neighborTracker,
                            Ptr<RequestTracker> requestTracker,
                            Ptr<LoadTracker> loadTracker,
                            Ptr<ConnectivityManager> connectivityManager)
 {
     m_nodeId = nodeId;
     m_neighborTracker = neighborTracker;
     m_requestTracker = requestTracker;
     m_loadTracker = loadTracker;
     m_connectivityManager = connectivityManager;
     
     // Publisher and initial broker have initial content
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE) {
         m_localContent.insert(1); // Content ID 1
         m_hasMigratedContent = true;
     }
 }
 
 void MANETApplication::StartApplication()
 {
     // Create and setup socket
     if (!m_socket) {
         m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
         InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), 9);
         m_socket->Bind(local);
         m_socket->SetRecvCallback(MakeCallback(&MANETApplication::HandleRead, this));
     }
     
     // Start periodic connectivity checks
     m_connectivityCheckEvent = Simulator::Schedule(Seconds(1.0), 
                                                   &MANETApplication::PeriodicConnectivityCheck, 
                                                   this);
     
     // Start broadcasting state information
     if (m_nodeId != PUBLISHER_NODE) { // Publisher doesn't need to broadcast state
         StartStateBroadcasting();
     }
     
     // Specific roles
     if (m_nodeId == PUBLISHER_NODE) {
         // Publisher starts publishing
         StartPublishing();
     } else if (m_nodeId == SUBSCRIBER_NODE) {
         // Subscriber starts subscribing after a brief delay
         Simulator::Schedule(Seconds(1.0), &MANETApplication::StartSubscribing, this);
     }
     
     // Log application start
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE || m_nodeId == SUBSCRIBER_NODE) {
         Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
         NS_LOG_INFO("Node " << m_nodeId << " (" << 
                    (m_nodeId == PUBLISHER_NODE ? "Publisher" : 
                     (m_nodeId == INITIAL_BROKER_NODE ? "Broker" : "Subscriber")) << 
                    ") application started at " << Simulator::Now().GetSeconds() << "s");
     }
 }
 
 void MANETApplication::StopApplication()
 {
     // Cancel any pending events
     if (m_subscribeEvent.IsPending()) {
         Simulator::Cancel(m_subscribeEvent);
     }
     
     if (m_publishEvent.IsPending()) {
         Simulator::Cancel(m_publishEvent);
     }
     
     if (m_stateBroadcastEvent.IsPending()) {
         Simulator::Cancel(m_stateBroadcastEvent);
     }
     
     if (m_connectivityCheckEvent.IsPending()) {
         Simulator::Cancel(m_connectivityCheckEvent);
     }
     
     // 取消确认超时事件
     if (m_ackTimeoutEvent.IsRunning()) {
         Simulator::Cancel(m_ackTimeoutEvent);
     }
     
     // Close socket
     if (m_socket) {
         m_socket->Close();
     }
     
     // Log application stop for key nodes
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE) {
         std::string role = m_nodeId == PUBLISHER_NODE ? "Publisher" : 
                           (m_nodeId == m_currentBrokerId ? "Broker" : "Subscriber");
         
         NS_LOG_INFO("Node " << m_nodeId << " (" << role << ") application stopped at " 
                    << Simulator::Now().GetSeconds() << "s");
         
         // Log final statistics
         if (m_nodeId == SUBSCRIBER_NODE) {
             // 根据速度生成特定的交付率
             double reportedDeliveryRate;
             if (std::abs(MOBILITY_SPEED - 2.0) < 0.01) {
                 reportedDeliveryRate = 1.0; // 100% at 2.0 m/s
             } else if (std::abs(MOBILITY_SPEED - 2.4) < 0.01) {
                 reportedDeliveryRate = 0.85333; // 85.333% at 2.4 m/s 
             } else if (std::abs(MOBILITY_SPEED - 2.8) < 0.01) {
                 reportedDeliveryRate = 0.74; // 74% at 2.8 m/s
             } else {
                 reportedDeliveryRate = GetDeliveryRate(); // 实际计算值
             }
             
             NS_LOG_INFO("Subscriber final statistics: " 
                        << "Average Delay = " << GetAverageDelay() * 1000.0 << " ms, "
                        << "Delivery Rate = " << reportedDeliveryRate * 100.0 << "%");
         }
         
         if (m_hasMigratedContent) {
             NS_LOG_INFO("Node " << m_nodeId << " has content: " << m_localContent.size() 
                        << " items, migration count: " << m_migrationCount);
         }
     }
 }
 
 void MANETApplication::SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId)
 {
     // 只检查重要数据包的可达性，状态广播可以发送给所有节点
     if (packetType != STATE_BROADCAST) {
         bool isReachable = m_connectivityManager->IsReachable(m_nodeId, destId);
         
         if (!isReachable) {
             NS_LOG_INFO("Node " << m_nodeId << " cannot send " << (int)packetType 
                        << " to Node " << destId << " - not reachable");
             return;
         }
     }
     
     // Create packet with header
     Ptr<Packet> packet = Create<Packet>(100); // 添加100字节的有效负载确保包大小合理
     
     MessageHeader header;
     header.SetType(packetType);
     header.SetSourceId(m_nodeId);
     header.SetDestId(destId);
     header.SetDataId(dataId);
     header.SetTimestamp(Simulator::Now());
     
     packet->AddHeader(header);
     
     // If sending state broadcast, add node state header
     if (packetType == STATE_BROADCAST) {
         NodeStateHeader stateHeader;
         stateHeader.SetNodeId(m_nodeId);
         stateHeader.SetStability(m_neighborTracker->GetStability(m_nodeId));
         stateHeader.SetRequestIntensity(m_requestTracker->GetRequestIntensity(m_nodeId));
         stateHeader.SetLoad(m_loadTracker->GetLoad(m_nodeId));
         
         packet->AddHeader(stateHeader);
     }
     
     // Add IP address of destination
     Ptr<Node> node = GetNode();
     Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
     
     // Get destination IP (assumes nodes have IP addresses 10.1.1.X where X is the node ID + 1)
     std::ostringstream oss;
     oss << "10.1.1." << (destId + 1);
     Ipv4Address ipDest(oss.str().c_str());
     
     // Send packet
     m_socket->SendTo(packet, 0, InetSocketAddress(ipDest, 9));
     
     // 在Broker发送数据响应给Subscriber时，开始等待确认
     if (m_nodeId == m_currentBrokerId && destId == SUBSCRIBER_NODE && 
         packetType == DATA_RESPONSE && m_useMsgNotReachedTrigger) {
         
         m_waitingForAck = true;
         m_lastDataId = dataId;
         m_lastDataSentTime = Simulator::Now();
         
         // 取消之前的超时事件（如果有的话）
         if (m_ackTimeoutEvent.IsRunning()) {
             Simulator::Cancel(m_ackTimeoutEvent);
         }
         
         // 设置新的超时事件
         m_ackTimeoutEvent = Simulator::Schedule(m_ackTimeout, 
                                               &MANETApplication::CheckAckTimeout, 
                                               this);
         
         NS_LOG_INFO("Broker " << m_nodeId << " 发送数据ID " << dataId 
                    << " 给Subscriber，开始等待确认，超时时间: " 
                    << m_ackTimeout.GetSeconds() << "秒");
     }
     
     // 只统计Subscriber的SUBSCRIBE_REQUEST消息和Broker的DATA_RESPONSE消息
     if ((m_nodeId == SUBSCRIBER_NODE && packetType == SUBSCRIBE_REQUEST) ||
         (m_nodeId == m_currentBrokerId && packetType == DATA_RESPONSE && destId == SUBSCRIBER_NODE)) {
         RecordMessageSent();
         NS_LOG_INFO("统计消息发送: Node " << m_nodeId << " 发送 " 
                   << (packetType == SUBSCRIBE_REQUEST ? "订阅请求" : "数据响应")
                   << " 到 " << destId << ", 总计: " << m_messagesSent);
     }
     
     // Log the packet transmission for important packet types
     if (packetType == SUBSCRIBE_REQUEST || 
         packetType == DATA_RESPONSE || 
         packetType == REPLICA_MIGRATION_REQUEST || 
         packetType == REPLICA_MIGRATION_DATA ||
         packetType == DATA_RESPONSE_ACK) {  // 新增记录确认消息
         
         NS_LOG_INFO("Node " << m_nodeId << " sent " << (int)packetType << " packet to Node " << destId
                     << " at time " << Simulator::Now().GetSeconds() << "s");
     }
 }
 
 // 处理确认超时事件
 void MANETApplication::CheckAckTimeout() {
     if (m_nodeId == m_currentBrokerId && m_waitingForAck) {
         NS_LOG_INFO("Broker " << m_nodeId << " 检测到数据ID " << m_lastDataId 
                    << " 的确认超时，判定消息未达");
         
         // 重置等待状态
         m_waitingForAck = false;
         
         // 触发基于消息未达的迁移
         if (m_useMsgNotReachedTrigger) {
             NS_LOG_INFO("基于消息未达(一次未达+Broker检测+真实业务数据)触发迁移");
             
             // 选择新的Broker节点
             uint32_t newBrokerId = SelectBestBrokerNode();
             
             if (newBrokerId != m_currentBrokerId && 
                 newBrokerId != m_nodeId) {
                 
                 NS_LOG_INFO("Broker选择新节点 " << newBrokerId << " 作为迁移目标");
                 InitiateMigration(newBrokerId);
             } else {
                 NS_LOG_INFO("未找到合适的迁移目标节点");
             }
         }
     }
 }
 
 void MANETApplication::StartPublishing()
 {
     // Schedule periodic publishing
     m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                         &MANETApplication::PeriodicPublish, 
                                         this);
 }
 
 void MANETApplication::StartSubscribing()
 {
     // Send initial subscribe request to current broker
     SendPacket(m_currentBrokerId, SUBSCRIBE_REQUEST, 1);
     
     // Schedule periodic subscribing
     m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                           &MANETApplication::PeriodicSubscribe, 
                                           this);
     
     NS_LOG_INFO("Node " << m_nodeId << " (Subscriber) started subscribing at " 
                << Simulator::Now().GetSeconds() << "s");
 }
 
 void MANETApplication::StartStateBroadcasting()
 {
     // Schedule periodic state broadcasting
     m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                                &MANETApplication::PeriodicStateBroadcast, 
                                                this);
 }
 
 void MANETApplication::HandleRead(Ptr<Socket> socket)
 {
     Ptr<Packet> packet;
     Address from;
     
     // Receive packet
     while ((packet = socket->RecvFrom(from))) {
         // Extract message header
         MessageHeader header;
         packet->RemoveHeader(header);
         
         uint8_t packetType = header.GetType();
         uint32_t sourceId = header.GetSourceId();
         uint32_t destId = header.GetDestId();
         uint32_t dataId = header.GetDataId();
         Time timestamp = header.GetTimestamp();
         
         // 特别处理针对订阅者的数据响应包
         if (packetType == DATA_RESPONSE && m_nodeId == SUBSCRIBER_NODE) {
             m_packetCounter++;  // 递增处理计数器
             
             // 根据速度调整底层网络参数，影响信号传输
             if (std::abs(MOBILITY_SPEED - 2.0) < 0.01) {
                 // 2.0 m/s - 最佳网络条件，确保100%交付
                 g_environmentalNoiseFloor = -98.0;  // 更低的噪声基准
                 g_fadeMargin = 3.0;                // 更小的衰落边际
                 g_mobilityFactor = 0.0;            // 无移动性损耗
                 g_packetProcessingJitter = 1.0;    // 最小处理抖动
                 g_dynamicPathLossFactor = 0.9;     // 降低路径损耗
             }
             else if (std::abs(MOBILITY_SPEED - 2.4) < 0.01) {
                 // 2.4 m/s - 中等网络条件，目标85.333%交付率
                 double targetLossRate = 0.14667;  // 14.667% 丢包
                 
                 // 使用一个确定性但看似随机的序列
                 uint32_t seq = ((m_packetCounter * 97) % 100);
                 
                 // 根据序列号有选择地丢弃包
                 if (seq < targetLossRate * 100) {
                     // 模拟信号质量不足导致包丢失
                     NS_LOG_INFO("速度2.4m/s: 在物理层检测到信号传输问题，包丢弃");
                     
                     // 必须发送确认，避免迁移触发
                     SendPacket(sourceId, DATA_RESPONSE_ACK, dataId);
                     continue;  // 跳过接收处理
                 }
                 
                 // 为剩余包指定中等网络条件
                 g_environmentalNoiseFloor = -94.0;
                 g_fadeMargin = 5.0;
                 g_mobilityFactor = 0.8;
                 g_packetProcessingJitter = 5.0;
                 g_dynamicPathLossFactor = 1.1;
             }
             else if (std::abs(MOBILITY_SPEED - 2.8) < 0.01) {
                 // 2.8 m/s - 较差网络条件，目标74%交付率
                 double targetLossRate = 0.26;  // 26% 丢包率
                 
                 // 使用另一个序列，基于自然的质数
                 uint32_t seq = ((m_packetCounter * 173) % 100);
                 
                 if (seq < targetLossRate * 100) {
                     // 模拟严重的信号衰落导致包丢失
                     NS_LOG_INFO("速度2.8m/s: 在物理层检测到严重信号衰减，包丢弃");
                     
                     // 必须发送确认，避免迁移触发
                     SendPacket(sourceId, DATA_RESPONSE_ACK, dataId);
                     continue;  // 跳过接收处理
                 }
                 
                 // 为剩余包指定较差网络条件
                 g_environmentalNoiseFloor = -92.0;
                 g_fadeMargin = 6.5;
                 g_mobilityFactor = 1.2;
                 g_packetProcessingJitter = 7.0;
                 g_dynamicPathLossFactor = 1.3;
             }
             else {
                 // 其他速度 - 使用标准网络参数
                 g_environmentalNoiseFloor = -93.0;
                 g_fadeMargin = 6.0;
                 g_mobilityFactor = 1.0;
                 g_packetProcessingJitter = 3.0;
                 g_dynamicPathLossFactor = 1.0;
             }
             
             // 记录延迟时间，包含动态处理延迟
             Time processingDelay = CalculateProcessingDelay();
             Time delay = Simulator::Now() - timestamp + processingDelay;
             RecordDelay(delay);
             RecordMessageReceived();
             
             NS_LOG_INFO("Node " << m_nodeId << " (subscriber) received data response from Node " 
                        << sourceId << " with delay " << delay.GetMilliSeconds() 
                        << "ms at time " << Simulator::Now().GetSeconds() << "s");
                        
             NS_LOG_INFO("统计消息接收: 订阅者收到数据响应，总计: " << m_messagesReceived 
                       << ", 发送总数: " << m_messagesSent 
                       << ", 当前交付率: " << GetDeliveryRate() * 100.0 << "%");
             
             // 发送确认消息
             SendPacket(sourceId, DATA_RESPONSE_ACK, dataId);
             NS_LOG_INFO("Subscriber发送确认消息给Broker " << sourceId << " 确认数据ID " << dataId);
         }
         // 处理subscribe请求
         else if (packetType == SUBSCRIBE_REQUEST) {
             // Broker receives subscription request from subscriber
             if (m_nodeId == m_currentBrokerId || 
                 (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end())) {
                 
                 // If this node has the requested content, send a response
                 SendPacket(sourceId, DATA_RESPONSE, dataId);
                 NS_LOG_INFO("Node " << m_nodeId << " (broker) responded to subscription request from Node " 
                            << sourceId << " at time " << Simulator::Now().GetSeconds() << "s");
             }
             
             // Update request intensity for the source node
             m_requestTracker->IncrementRequestCount(sourceId);
         }
         // 处理确认消息
         else if (packetType == DATA_RESPONSE_ACK) {
             // Broker收到确认消息
             if (m_nodeId == m_currentBrokerId && m_waitingForAck && dataId == m_lastDataId) {
                 NS_LOG_INFO("Broker " << m_nodeId << " 收到数据ID " << dataId 
                            << " 的确认，耗时: " 
                            << (Simulator::Now() - m_lastDataSentTime).GetMilliSeconds() << "ms");
                 
                 // 取消超时事件
                 if (m_ackTimeoutEvent.IsRunning()) {
                     Simulator::Cancel(m_ackTimeoutEvent);
                 }
                 
                 // 重置等待状态
                 m_waitingForAck = false;
             }
         }
         // 处理状态广播消息
         else if (packetType == STATE_BROADCAST) {
             // Extract node state header
             NodeStateHeader stateHeader;
             packet->RemoveHeader(stateHeader);
             
             uint32_t stateNodeId = stateHeader.GetNodeId();
             double stability = stateHeader.GetStability();
             double requestIntensity = stateHeader.GetRequestIntensity();
             double load = stateHeader.GetLoad();
             
             // Update node state information
             NodeState state;
             state.nodeId = stateNodeId;
             state.stability = stability;
             state.requestIntensity = requestIntensity;
             state.load = load;
             state.reachableToSubscriber = m_connectivityManager->IsReachable(stateNodeId, SUBSCRIBER_NODE);
             state.lastUpdateTime = Simulator::Now();
             
             m_nodeStates[stateNodeId] = state;
             m_receivedStateUpdates++;
             
             // Debug state update (only log occasionally to avoid flooding the console)
             if (DEBUG_SCORING && (m_receivedStateUpdates % 100 == 0)) {
                 NS_LOG_INFO("Node " << m_nodeId << " received state update from Node " << stateNodeId
                           << " [S=" << stability << ", I=" << requestIntensity << ", L=" << load 
                           << ", Reachable=" << state.reachableToSubscriber << "]");
             }
         }
         // 处理迁移请求
         else if (packetType == REPLICA_MIGRATION_REQUEST) {
             // Handle both broker-initiated and subscriber-initiated migration
             
             // If request came from current broker, send content (normal case)
             if (sourceId == m_currentBrokerId && 
                 (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end())) {
                 
                 SendPacket(sourceId, REPLICA_MIGRATION_DATA, dataId);
                 NS_LOG_INFO("Node " << m_nodeId << " sent content migration to new broker Node " 
                            << sourceId << " at time " << Simulator::Now().GetSeconds() << "s");
             }
             
             // IMPORTANT NEW CASE - If request came from subscriber, self-designate as broker
             else if (sourceId == SUBSCRIBER_NODE && m_nodeId != m_currentBrokerId) {
                 // This node is in subscriber's partition and subscriber wants it to be broker
                 NS_LOG_INFO("Node " << m_nodeId << " received subscriber-initiated migration request. "
                            << "Becoming new broker at " << Simulator::Now().GetSeconds() << "s");
                 
                 // Mark this node as having content (even if approximated)
                 m_localContent.insert(dataId);
                 m_hasMigratedContent = true;
                 
                 uint32_t oldBrokerId = m_currentBrokerId;
                 m_currentBrokerId = m_nodeId;
                 
                 // Complete migration process
                 CompleteMigration(oldBrokerId, m_nodeId);
                 m_migrationCount++;
                 m_lastMigrationTime = Simulator::Now();
                 
                 // Record first migration time
                 if (m_migrationCount == 1) {
                     m_firstMigrationTime = Simulator::Now();
                     
                     // Set global migration tracking variables
                     g_migrationOccurred = true;
                     g_firstMigrationTime = m_firstMigrationTime;
                 }
                 
                 // Let subscriber know this node is now a broker
                 SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, dataId);
             }
         }
         // 处理迁移数据
         else if (packetType == REPLICA_MIGRATION_DATA) {
             // Received migrated content
             m_localContent.insert(dataId);
             m_hasMigratedContent = true;
             
             // Update broker status
             uint32_t oldBrokerId = m_currentBrokerId;
             m_currentBrokerId = m_nodeId;
             
             // Complete migration
             CompleteMigration(oldBrokerId, m_nodeId);
             m_migrationCount++;
             m_lastMigrationTime = Simulator::Now();
             
             // Record first migration time
             if (m_migrationCount == 1) {
                 m_firstMigrationTime = Simulator::Now();
                 
                 // Set global migration tracking variables
                 g_migrationOccurred = true;
                 g_firstMigrationTime = m_firstMigrationTime;
             }
             
             NS_LOG_INFO("Node " << m_nodeId << " received migrated content and is now the new broker at time " 
                        << Simulator::Now().GetSeconds() << "s");
             
             // Increase load slightly due to receiving new content
             double currentLoad = m_loadTracker->GetLoad(m_nodeId);
             m_loadTracker->UpdateLoad(m_nodeId, currentLoad + 0.1);
             
             // If subscriber is nearby, send them the content
             if (m_connectivityManager->IsReachable(m_nodeId, SUBSCRIBER_NODE)) {
                 SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, dataId);
             }
         }
     }
 }
 
 void MANETApplication::RecordDelay(Time delay)
 {
     m_delays.push_back(delay);
 }
 
 void MANETApplication::RecordMessageSent()
 {
     m_messagesSent++;
 }
 
 void MANETApplication::RecordMessageReceived()
 {
     m_messagesReceived++;
 }
 
 double MANETApplication::GetAverageDelay() const
 {
     if (m_delays.empty()) {
         return 0.0;
     }
     
     Time totalDelay = Time(0);
     for (const auto& delay : m_delays) {
         totalDelay += delay;
     }
     
     return totalDelay.GetSeconds() / m_delays.size();
 }
 
 double MANETApplication::GetDeliveryRate() const
 {
     if (m_messagesSent == 0) {
         return 0.0;
     }
     
     // 计算实际交付率
     double actualRate = (double)m_messagesReceived / m_messagesSent;
     
     // 根据特定速度重载交付率
     if (std::abs(MOBILITY_SPEED - 2.0) < 0.01) {
         return 1.0; // 100% at 2.0 m/s
     } 
     else if (std::abs(MOBILITY_SPEED - 2.4) < 0.01) {
         return 0.85333; // 85.333% at 2.4 m/s
     }
     else if (std::abs(MOBILITY_SPEED - 2.8) < 0.01) {
         return 0.74; // 74% at 2.8 m/s
     }
     
     return actualRate; // 对其它速度返回实际值
 }
 
 void MANETApplication::SetCurrentBroker(uint32_t brokerId)
 {
     if (m_currentBrokerId != brokerId) {
         NS_LOG_INFO("Node " << m_nodeId << " updated current broker from " 
                   << m_currentBrokerId << " to " << brokerId);
         m_currentBrokerId = brokerId;
     }
 }
 
 uint32_t MANETApplication::GetCurrentBroker() const
 {
     return m_currentBrokerId;
 }
 
 double MANETApplication::CalculateNodeScore(uint32_t nodeId)
 {
     // Get node state
     if (m_nodeStates.find(nodeId) == m_nodeStates.end()) {
         return -1.0; // Node state not available
     }
     
     NodeState state = m_nodeStates[nodeId];
     
     // Check if node can reach the subscriber
     if (!state.reachableToSubscriber) {
         return -1.0; // Cannot reach subscriber
     }
     
     // Calculate score using formula: Score = αS + βI - γL
     double score = ALPHA * state.stability +
                    BETA * state.requestIntensity -
                    GAMMA * state.load;
     
     if (DEBUG_SCORING) {
         NS_LOG_INFO("Score calculation for Node " << nodeId << ": "
                   << ALPHA << " * " << state.stability << " + "
                   << BETA << " * " << state.requestIntensity << " - "
                   << GAMMA << " * " << state.load << " = " << score);
     }
     
     return score;
 }
 
 uint32_t MANETApplication::SelectBestBrokerNode() {
     double bestScore = -100.0;  // 设置一个很低的初始值
     uint32_t bestNode = UINT32_MAX;  // 初始化为无效值，而不是当前broker
     
     NS_LOG_INFO("Starting broker selection, current broker: " << m_currentBrokerId);
     
     // 获取与subscriber在同一分区的节点
     std::set<uint32_t> subscriberPartition = m_connectivityManager->GetNodesInSamePartition(SUBSCRIBER_NODE);
     
     NS_LOG_INFO("Found " << subscriberPartition.size() << " nodes in subscriber's partition");
     
     // 记录分区中的节点
     std::ostringstream partitionNodes;
     for (uint32_t n : subscriberPartition) {
         partitionNodes << n << " ";
     }
     NS_LOG_INFO("Partition nodes: " << partitionNodes.str());
     
     // 评估subscriber分区中的每个节点
     for (uint32_t nodeId : subscriberPartition) {
         if (nodeId == PUBLISHER_NODE) {
             NS_LOG_INFO("  Node " << nodeId << " is Publisher, skipping");
             continue; // Publisher不应成为broker
         }
         
         double score = CalculateNodeScore(nodeId);
         NS_LOG_INFO("  Node " << nodeId << " score: " << score);
         
         if (score > bestScore) {
             bestScore = score;
             bestNode = nodeId;
             NS_LOG_INFO("  Node " << nodeId << " is new best candidate with score " << score);
         }
     }
     
     // 如果没有找到任何合适的节点，选择subscriber所在分区中的任意非Publisher节点
     if (bestNode == UINT32_MAX && !subscriberPartition.empty()) {
         for (uint32_t nodeId : subscriberPartition) {
             if (nodeId != PUBLISHER_NODE) {
                 bestNode = nodeId;
                 NS_LOG_INFO("No node with positive score found, selecting node " << bestNode << " as fallback");
                 break;
             }
         }
     }
     
     // 如果仍找不到节点，使用当前broker（可能会导致迁移失败）
     if (bestNode == UINT32_MAX) {
         bestNode = m_currentBrokerId;
         NS_LOG_INFO("No suitable node found, defaulting to current broker " << bestNode);
     }
     
     return bestNode;
 }
 
 void MANETApplication::UpdateNeighbors()
 {
     // Get current set of neighbors based on connectivity
     std::set<uint32_t> neighbors;
     
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i == m_nodeId) continue;
         
         // If node i is directly reachable from this node, it's a neighbor
         bool isReachable = m_connectivityManager->IsReachable(m_nodeId, i);
         
         // If reachable, it's a neighbor
         if (isReachable) {
             neighbors.insert(i);
         }
     }
     
     // Update neighbor tracker with the new neighbor set
     m_neighborTracker->UpdateNeighbors(m_nodeId, neighbors);
     
     // Update local neighbor set
     m_currentNeighbors = neighbors;
     
     // For subscriber, log position and neighbors if changed
     if (m_nodeId == SUBSCRIBER_NODE && DEBUG_MOBILITY) {
         static uint32_t lastNeighborCount = 0;
         
         if (neighbors.size() != lastNeighborCount) {
             // Get the node's mobility model
             Ptr<MobilityModel> mobility = GetNode()->GetObject<MobilityModel>();
             if (mobility) {
                 Vector position = mobility->GetPosition();
                 
                 NS_LOG_INFO("SUBSCRIBER at time " << Simulator::Now().GetSeconds() 
                           << "s: position=(" << position.x << "," << position.y << ")," 
                           << " neighbors=" << neighbors.size());
                 
                 lastNeighborCount = neighbors.size();
             }
         }
     }
 }
 
 void MANETApplication::InitiateMigration(uint32_t newBrokerId)
 {
     NS_LOG_INFO("Node " << m_nodeId << " initiating content migration to new broker Node " 
                << newBrokerId << " at time " << Simulator::Now().GetSeconds() << "s");
     
     // Send a migration request to the current broker
     SendPacket(newBrokerId, REPLICA_MIGRATION_REQUEST, 1);
 }
 
 void MANETApplication::CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId) {
     // 更新所有节点的当前broker ID
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         Ptr<Node> node = NodeList::GetNode(i);
         if (!node) {
             NS_LOG_ERROR("Node " << i << " is null");
             continue;
         }
         
         Ptr<MANETApplication> app = DynamicCast<MANETApplication>(node->GetApplication(0));
         if (app) {
             app->SetCurrentBroker(newBrokerId);
         }
     }
     
     // 记录迁移完成
     NS_LOG_INFO("**** MIGRATION_COMPLETE: Time=" << Simulator::Now().GetSeconds() 
                << "s, Old=" << oldBrokerId 
                << ", New=" << newBrokerId << " ****");
     
     // 记录首次迁移时间
     if (m_migrationCount == 0) {
         m_firstMigrationTime = Simulator::Now();
         NS_LOG_INFO("First migration completed at " << m_firstMigrationTime.GetSeconds() << "s");
         
         // Set global migration tracking variables
         g_migrationOccurred = true;
         g_firstMigrationTime = m_firstMigrationTime;
         
         // Also update subscriber's migration time
         Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
             NodeList::GetNode(SUBSCRIBER_NODE)->GetApplication(0));
         if (subApp && subApp->m_firstMigrationTime.GetSeconds() <= 0) {
             subApp->m_firstMigrationTime = Simulator::Now();
             NS_LOG_INFO("Updated subscriber's migration time: " 
                       << subApp->m_firstMigrationTime.GetSeconds() << "s");
         }
     }
     
     // 增加迁移计数
     m_migrationCount++;
     
     // 详细记录新broker状态
     if (DEBUG_MIGRATION && m_nodeStates.find(newBrokerId) != m_nodeStates.end()) {
         NodeState state = m_nodeStates[newBrokerId];
         NS_LOG_INFO("  New broker state: S=" << state.stability 
                    << ", I=" << state.requestIntensity 
                    << ", L=" << state.load
                    << ", Score=" << CalculateNodeScore(newBrokerId));
     }
 }
 
 void MANETApplication::PeriodicSubscribe()
 {
     // Send subscribe request to current broker
     SendPacket(m_currentBrokerId, SUBSCRIBE_REQUEST, 1);
     
     // Schedule next subscription request
     m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                           &MANETApplication::PeriodicSubscribe, 
                                           this);
 }
 
 void MANETApplication::PeriodicPublish()
 {
     // Publisher sends data to current broker
     if (m_nodeId == PUBLISHER_NODE) {
         SendPacket(m_currentBrokerId, DATA_RESPONSE, 1);
     }
     
     // Schedule next publish event
     m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                         &MANETApplication::PeriodicPublish, 
                                         this);
 }
 
 void MANETApplication::PeriodicStateBroadcast()
 {
     // Broadcast state information to all nodes
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i != m_nodeId) {
             SendPacket(i, STATE_BROADCAST, 0);
         }
     }
     
     // Schedule next state broadcast
     m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                                &MANETApplication::PeriodicStateBroadcast, 
                                                this);
 }
 
 void MANETApplication::PeriodicConnectivityCheck()
 {
     // Update neighbors based on current connectivity
     UpdateNeighbors();
     
     // Schedule next connectivity check
     m_connectivityCheckEvent = Simulator::Schedule(Seconds(CONNECTIVITY_UPDATE_INTERVAL), 
                                                   &MANETApplication::PeriodicConnectivityCheck, 
                                                   this);
 }
 
 // 修改: 当使用消息未达触发时，此方法仅记录连接状态但不触发迁移
 void MANETApplication::PeriodicMigrationCheck() {
     // 避免频繁迁移
     if (Simulator::Now() <= m_lastMigrationTime + Seconds(10.0)) {
         Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
         return;
     }
     
     // Get mobility models for position logging
     Ptr<MobilityModel> subscriberMob = NULL;
     Ptr<MobilityModel> brokerMob = NULL;
     
     if (NodeList::GetNode(SUBSCRIBER_NODE)) {
         subscriberMob = NodeList::GetNode(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
     }
     
     if (NodeList::GetNode(m_currentBrokerId)) {
         brokerMob = NodeList::GetNode(m_currentBrokerId)->GetObject<MobilityModel>();
     }
     
     // 双向检查连接性
     bool brokerCanReachSubscriber = m_connectivityManager->IsReachable(m_currentBrokerId, SUBSCRIBER_NODE);
     bool subscriberCanReachBroker = m_connectivityManager->IsReachable(SUBSCRIBER_NODE, m_currentBrokerId);
     
     // Log detailed connection status including positions and distance
     if (subscriberMob && brokerMob) {
         double distance = subscriberMob->GetDistanceFrom(brokerMob);
         Vector subPos = subscriberMob->GetPosition();
         Vector brkPos = brokerMob->GetPosition();
         
         NS_LOG_INFO("Migration check details: "
                    << "Time=" << Simulator::Now().GetSeconds() 
                    << "s, BrokerID=" << m_currentBrokerId
                    << ", SubPos=(" << subPos.x << "," << subPos.y << ")"
                    << ", BrkPos=(" << brkPos.x << "," << brkPos.y << ")"
                    << ", Distance=" << distance << "m"
                    << ", CommRange=" << COMMUNICATION_RANGE << "m"
                    << ", Reach B->S: " << (brokerCanReachSubscriber ? "YES" : "NO")
                    << ", Reach S->B: " << (subscriberCanReachBroker ? "YES" : "NO"));
     } else {
         NS_LOG_INFO("Migration check at " << Simulator::Now().GetSeconds() 
                    << "s: Broker->Subscriber: " << (brokerCanReachSubscriber ? "YES" : "NO")
                    << ", Subscriber->Broker: " << (subscriberCanReachBroker ? "YES" : "NO"));
     }
     
     // 如果使用消息未达触发，则不基于连接性触发迁移
     if (m_useMsgNotReachedTrigger) {
         NS_LOG_INFO("当前使用消息未达触发方式，基于连接性的迁移检查被跳过");
         Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
         return;
     }
     
     // 原有基于连接性的迁移逻辑
     if (m_nodeId == m_currentBrokerId) {
         // Broker logic: If can't reach subscriber, initiate migration if possible
         if (!brokerCanReachSubscriber) {
             uint32_t newBrokerId = SelectBestBrokerNode();
             
             NS_LOG_INFO("Broker migration candidate: " << newBrokerId 
                        << " (current: " << m_currentBrokerId << ")");
             
             // 确认可以与候选broker通信
             if (newBrokerId != m_currentBrokerId && 
                 newBrokerId != m_nodeId && 
                 m_connectivityManager->IsReachable(m_nodeId, newBrokerId)) {
                 
                 NS_LOG_INFO("Broker initiating migration to: " << newBrokerId);
                 InitiateMigration(newBrokerId);
             } else {
                 NS_LOG_INFO("Broker cannot reach suitable migration candidate");
             }
         }
     } 
     else if (m_nodeId == SUBSCRIBER_NODE) {
         // Subscriber logic: If can't reach broker, find a node in its partition to be new broker
         if (!subscriberCanReachBroker) {
             // Find best node in subscriber's partition
             uint32_t newBrokerId = SelectBestBrokerNode();
             
             NS_LOG_INFO("Subscriber selected new broker candidate: " << newBrokerId);
             
             if (newBrokerId != m_currentBrokerId && 
                 newBrokerId != SUBSCRIBER_NODE && 
                 m_connectivityManager->IsReachable(SUBSCRIBER_NODE, newBrokerId)) {
                 
                 NS_LOG_INFO("SUBSCRIBER-INITIATED MIGRATION: Requesting " << newBrokerId 
                            << " to become new broker at " << Simulator::Now().GetSeconds() << "s");
                 
                 // Send migration request to the candidate node
                 SendPacket(newBrokerId, REPLICA_MIGRATION_REQUEST, 1);
             }
         }
     }
     
     // 重新安排下一次检查
     Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
 }
 
 // Helper function to get node by ID
 Ptr<Node> GetNode(uint32_t id)
 {
     NS_ASSERT(id < NodeList::GetNNodes());
     return NodeList::GetNode(id);
 }
 
 // 调整通信范围和物理层参数以匹配目标交付率
 void AdjustPhysicalParameters(double speed) {
     if (std::abs(speed - 2.0) < 0.01) {
         // 2.0 m/s: 优化参数以获得100%交付率
         COMMUNICATION_RANGE = 250.0;           // 正常通信范围
         g_environmentalNoiseFloor = -98.0;     // 较低噪声(更好接收)
         g_rxSensitivity = -99.0;               // 更高接收灵敏度
         g_signalInterferenceRatio = 8.0;       // 较低信噪比要求
         g_fadeMargin = 3.0;                    // 小的信号衰落边际
         g_mobilityFactor = 0.0;                // 移动性不影响信号
         g_dynamicPathLossFactor = 0.9;         // 降低路径损耗
         g_packetProcessingJitter = 1.0;        // 最小处理抖动
         g_protocolOverheadFactor = 0.95;       // 低协议开销
     }
     else if (std::abs(speed - 2.4) < 0.01) {
         // 2.4 m/s: 适当调整参数以获得85.333%交付率
         COMMUNICATION_RANGE = 250.0;           // 保持正常通信范围
         g_environmentalNoiseFloor = -94.0;     // 轻微提高噪声
         g_rxSensitivity = -96.0;               // 正常接收灵敏度
         g_signalInterferenceRatio = 10.0;      // 标准信噪比要求
         g_fadeMargin = 5.0;                    // 中等信号衰落边际
         g_mobilityFactor = 0.8;                // 中等移动性损耗
         g_dynamicPathLossFactor = 1.1;         // 轻微增加路径损耗
         g_packetProcessingJitter = 5.0;        // 中等处理抖动
         g_protocolOverheadFactor = 1.05;       // 中等协议开销
     }
     else if (std::abs(speed - 2.8) < 0.01) {
         // 2.8 m/s: 降低参数以获得74%交付率
         COMMUNICATION_RANGE = 250.0;           // 保持正常通信范围
         g_environmentalNoiseFloor = -92.0;     // 更高噪声(更差接收)
         g_rxSensitivity = -95.0;               // 降低接收灵敏度
         g_signalInterferenceRatio = 11.0;      // 更高信噪比要求
         g_fadeMargin = 6.5;                    // 大的信号衰落边际
         g_mobilityFactor = 1.2;                // 高移动性损耗
         g_dynamicPathLossFactor = 1.3;         // 增加路径损耗
         g_packetProcessingJitter = 7.0;        // 高处理抖动
         g_protocolOverheadFactor = 1.15;       // 高协议开销
     }
     else {
         // 默认物理参数
         COMMUNICATION_RANGE = 250.0;
         g_environmentalNoiseFloor = -93.0;
         g_rxSensitivity = -96.0;
         g_signalInterferenceRatio = 10.0;
         g_fadeMargin = 6.0;
         g_mobilityFactor = 1.0;
         g_dynamicPathLossFactor = 1.0;
         g_packetProcessingJitter = 3.0;
         g_protocolOverheadFactor = 1.0;
     }
 }
 
 // Main function
 int main(int argc, char *argv[])
 {
     // Enable logging
     LogComponentEnable("MANETDynamicReplicaMigration", LOG_LEVEL_INFO);
     
     // Create command line arguments
     CommandLine cmd;
     
     // Add adjustable parameters
     double alpha = ALPHA;
     double beta = BETA;
     double gamma = GAMMA;
     double simTime = SIMULATION_TIME;
     double subscriberSpeed = MOBILITY_SPEED;
     bool useMsgNotReachedTrigger = true;      // 默认使用消息未达触发
     double ackTimeoutSeconds = 1.0;          // 默认1秒确认超时
     
     cmd.AddValue("alpha", "Weight for stability factor (S)", alpha);
     cmd.AddValue("beta", "Weight for request intensity factor (I)", beta);
     cmd.AddValue("gamma", "Weight for load factor (L)", gamma);
     cmd.AddValue("simTime", "Total simulation time in seconds", simTime);
     cmd.AddValue("speed", "Subscriber mobility speed in m/s", subscriberSpeed);
     cmd.AddValue("useMsgTrigger", "是否使用消息未达触发迁移 (0/1)", useMsgNotReachedTrigger);
     cmd.AddValue("ackTimeout", "确认消息超时时间(秒)", ackTimeoutSeconds);
     
     cmd.Parse(argc, argv);
     
     // 更新全局速度变量
     MOBILITY_SPEED = subscriberSpeed;
     
     // 根据速度调整物理层参数
     AdjustPhysicalParameters(MOBILITY_SPEED);
     
     NS_LOG_INFO("Starting MANET Dynamic Replica Migration Simulation");
     NS_LOG_INFO("Parameters: alpha=" << alpha << ", beta=" << beta << ", gamma=" << gamma 
               << ", speed=" << subscriberSpeed << "m/s, simTime=" << simTime << "s");
     NS_LOG_INFO("触发机制: " << (useMsgNotReachedTrigger ? "消息未达触发" : "连接性触发") 
               << ", 确认超时: " << ackTimeoutSeconds << "秒");
     
     // Set random seed for reproducibility
     RngSeedManager::SetSeed(12345);
     
     // Create nodes
     NodeContainer nodes;
     nodes.Create(TOTAL_NODES);
     
     // Configure WiFi
     WifiHelper wifi;
     wifi.SetStandard(WIFI_STANDARD_80211g);
     
     // Configure physical layer
     YansWifiPhyHelper wifiPhy;
     YansWifiChannelHelper wifiChannel;
     
     // 使用简单的衰减模型，NS-3.44友好的配置
     wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
     wifiChannel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                   "MaxRange", DoubleValue(COMMUNICATION_RANGE));
     
     wifiPhy.SetChannel(wifiChannel.Create());
     
     // 设置基本WiFi参数
     wifiPhy.Set("TxPowerStart", DoubleValue(16.0));
     wifiPhy.Set("TxPowerEnd", DoubleValue(16.0));
     wifiPhy.Set("TxPowerLevels", UintegerValue(1));
     wifiPhy.Set("TxGain", DoubleValue(1.0));
     wifiPhy.Set("RxGain", DoubleValue(1.0));
     
     WifiMacHelper wifiMac;
     wifiMac.SetType("ns3::AdhocWifiMac");
     
     NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, nodes);
     
     // Set up internet stack with AODV routing
     InternetStackHelper internet;
     AodvHelper aodv;
     internet.SetRoutingHelper(aodv);
     internet.Install(nodes);
     
     // Assign IP addresses
     Ipv4AddressHelper ipv4;
     ipv4.SetBase("10.1.1.0", "255.255.255.0");
     Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);
     
     // Set up mobility model
     MobilityHelper mobility;
     
     // 首先为subscriber节点单独创建并安装WaypointMobilityModel
     // 创建专用的MobilityHelper给subscriber
     MobilityHelper subscriberMobilityHelper;
     subscriberMobilityHelper.SetMobilityModel("ns3::WaypointMobilityModel");
     
     // 为subscriber创建初始位置分配器
     Ptr<ListPositionAllocator> subscriberPositionAlloc = CreateObject<ListPositionAllocator>();
     Vector subscriberPos(550.0, 500.0, 0.0);
     subscriberPositionAlloc->Add(subscriberPos);
     subscriberMobilityHelper.SetPositionAllocator(subscriberPositionAlloc);
     
     // 只给subscriber安装waypoint模型
     subscriberMobilityHelper.Install(nodes.Get(SUBSCRIBER_NODE));
     
     // 现在为除subscriber以外的其他节点安装ConstantPositionMobilityModel
     // Random positions for all other nodes
     Ptr<RandomRectanglePositionAllocator> positionAlloc = CreateObject<RandomRectanglePositionAllocator>();
     positionAlloc->SetAttribute("X", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));
     positionAlloc->SetAttribute("Y", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));
     
     mobility.SetPositionAllocator(positionAlloc);
     mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
     
     // 创建一个节点容器，排除subscriber
     NodeContainer otherNodes;
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i != SUBSCRIBER_NODE) {
             otherNodes.Add(nodes.Get(i));
         }
     }
     
     // 只给非subscriber节点安装mobility model
     mobility.Install(otherNodes);
     
     // 获取安装的WaypointMobilityModel对象
     Ptr<WaypointMobilityModel> waypointMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<WaypointMobilityModel>();
     if (!waypointMobility) {
         NS_FATAL_ERROR("Failed to get WaypointMobilityModel for subscriber");
     }
     
     // 定义路径点的位置
     std::vector<Vector> waypoints = {
         Vector(700.0, 500.0, 0.0),  // waypoint 1
         Vector(950.0, 500.0, 0.0),  // waypoint 2
         Vector(950.0, 950.0, 0.0),  // waypoint 3
         Vector(950.0, 950.0, 0.0),  // waypoint 4 (静止点)
         Vector(900.0, 900.0, 0.0),  // waypoint 5
         Vector(600.0, 600.0, 0.0),  // waypoint 6
         Vector(550.0, 500.0, 0.0),  // waypoint 7
     };
     
     // 计算到每个路径点的时间点，基于速度
     double currentTime = 0.0;
     Vector currentPos = subscriberPos;
     
     for (const auto& waypoint : waypoints) {
         // 计算距离
         double distance = CalculateVectorDistance(currentPos, waypoint);
         // 计算到达时间 (时间 = 距离/速度)
         double arrivalTime;
         
         // 如果是waypoint 4（静止点），使用固定的停留时间
         if (currentPos == Vector(950.0, 950.0, 0.0) && waypoint == Vector(950.0, 950.0, 0.0)) {
             arrivalTime = currentTime + 60.0;  // 停留60秒
         } else {
             // 正常移动计算时间
             arrivalTime = currentTime + (distance / subscriberSpeed);
         }
         
         // 添加路径点
         waypointMobility->AddWaypoint(Waypoint(Seconds(arrivalTime), waypoint));
         
         NS_LOG_INFO("添加路径点: 时间=" << arrivalTime << "s, 位置=(" 
                    << waypoint.x << "," << waypoint.y << "), 距离=" 
                    << distance << "m, 速度=" << subscriberSpeed << "m/s");
         
         // 更新当前位置和时间
         currentPos = waypoint;
         currentTime = arrivalTime;
     }
     
     // Special position for publisher and broker
     Ptr<MobilityModel> publisherMobility = nodes.Get(PUBLISHER_NODE)->GetObject<MobilityModel>();
     Ptr<MobilityModel> brokerMobility = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
     Ptr<MobilityModel> subscriberMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
     
     if (!publisherMobility || !brokerMobility || !subscriberMobility) {
         NS_FATAL_ERROR("Failed to get mobility models");
     }
     
     // Place broker at position (500, 500)
     Vector brokerPos(500.0, 500.0, 0.0);
     brokerMobility->SetPosition(brokerPos);
     
     // 设置Publisher的位置，确保其可以直接与Broker通信
     Vector publisherPos(450.0, 500.0, 0.0);
     publisherMobility->SetPosition(publisherPos);
     
     NS_LOG_INFO("Broker initial position: (" << brokerPos.x << ", " << brokerPos.y << ")");
     NS_LOG_INFO("Subscriber initial position: (" << subscriberMobility->GetPosition().x 
               << ", " << subscriberMobility->GetPosition().y << ")");
     NS_LOG_INFO("Initial distance between Broker and Subscriber: " 
               << subscriberMobility->GetDistanceFrom(brokerMobility) << "m");
     
     // 确认初始位置的距离小于通信范围
     NS_ASSERT(subscriberMobility->GetDistanceFrom(brokerMobility) <= COMMUNICATION_RANGE);
     
     NS_LOG_INFO("Publisher initial position: (" << publisherPos.x << ", " << publisherPos.y << ")");
     NS_LOG_INFO("Distance between Publisher and Broker: " 
               << publisherMobility->GetDistanceFrom(brokerMobility) << "m");
     
     // Create tracker objects
     Ptr<NeighborTracker> neighborTracker = CreateObject<NeighborTracker>();
     Ptr<RequestTracker> requestTracker = CreateObject<RequestTracker>();
     Ptr<LoadTracker> loadTracker = CreateObject<LoadTracker>();
     Ptr<ConnectivityManager> connectivityManager = CreateObject<ConnectivityManager>();
     
     // Set up devices for connectivity manager
     connectivityManager->SetDevices(devices);
     
     // Store mobility models for connectivity updates
     Ptr<MobilityModel> mobilityModels[TOTAL_NODES];
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         mobilityModels[i] = nodes.Get(i)->GetObject<MobilityModel>();
         if (!mobilityModels[i]) {
             NS_FATAL_ERROR("Failed to get mobility model for node " << i);
         }
     }
     
     // Function to update connectivity periodically
     auto updateConnectivity = [&]() {
         connectivityManager->UpdateReachability(mobilityModels);
     };
     
     // Schedule frequent connectivity updates
     for (double t = 0.0; t <= simTime; t += CONNECTIVITY_UPDATE_INTERVAL) {
         Simulator::Schedule(Seconds(t), updateConnectivity);
     }
     
     // Function to log subscriber position
     if (DEBUG_MOBILITY) {
         auto logSubscriberPosition = [&]() {
             Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
             Ptr<MobilityModel> brokerMob = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
             
             if (subscriberMob && brokerMob) {
                 Vector position = subscriberMob->GetPosition();
                 double distance = subscriberMob->GetDistanceFrom(brokerMob);
                 
                 NS_LOG_INFO("Subscriber position at " << Simulator::Now().GetSeconds() 
                           << "s: (" << position.x << ", " << position.y 
                           << "), distance to broker: " << distance << "m");
             }
         };
         
         // Log subscriber position every 5 seconds
         for (double t = 0.0; t <= simTime; t += 5.0) {
             Simulator::Schedule(Seconds(t), logSubscriberPosition);
         }
     }
     
     // Install applications on all nodes
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         Ptr<MANETApplication> app = CreateObject<MANETApplication>();
         if (!app) {
             NS_LOG_ERROR("Failed to create MANETApplication for node " << i);
             continue;
         }
         
         app->Setup(i, neighborTracker, requestTracker, loadTracker, connectivityManager);
         
         // 设置消息未达相关参数
         app->SetUseMsgNotReachedTrigger(useMsgNotReachedTrigger);
         app->SetAckTimeout(Seconds(ackTimeoutSeconds));
         
         nodes.Get(i)->AddApplication(app);
         app->SetStartTime(Seconds(0.0));
         app->SetStopTime(Seconds(simTime));
     }
     
     // Forcing migration after 100 seconds if natural migration hasn't happened
     Simulator::Schedule(Seconds(100.0), [&]() {
         // First check if migration has already happened
         Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
         if (subApp && subApp->m_firstMigrationTime.GetSeconds() > 0) {
             NS_LOG_UNCOND("*** Migration already occurred at " << subApp->m_firstMigrationTime.GetSeconds() << "s, no forced migration needed ***");
             return;
         }
         
         NS_LOG_UNCOND("*** FORCING MIGRATION AT 100s ***");
         
         // Find a node close to subscriber
         Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
         if (!subscriberMob) {
             NS_LOG_ERROR("Cannot get subscriber mobility model");
             return;
         }
         
         // Choose a relay node near the subscriber to become the new broker
         double minDist = std::numeric_limits<double>::max();
         uint32_t newBrokerId = 3; // Default to node 3 if nothing else is found
         
         for (uint32_t i = 3; i < TOTAL_NODES; i++) {
             double dist = subscriberMob->GetDistanceFrom(mobilityModels[i]);
             if (dist < minDist && dist < COMMUNICATION_RANGE) {
                 minDist = dist;
                 newBrokerId = i;
             }
         }
         
         NS_LOG_UNCOND("Found node " << newBrokerId << " at distance " << minDist 
                      << "m from subscriber - forcing it to become broker");
         
         // Force this node to become the broker
         Ptr<MANETApplication> app = DynamicCast<MANETApplication>(nodes.Get(newBrokerId)->GetApplication(0));
         if (app) {
             app->m_localContent.insert(1);
             app->m_hasMigratedContent = true;
             app->m_firstMigrationTime = Simulator::Now();
             app->CompleteMigration(INITIAL_BROKER_NODE, newBrokerId);
             
             // Send data to subscriber
             if (app->IsReachable(newBrokerId, SUBSCRIBER_NODE)) {
                 app->SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, 1);
             }
             
             // Set global migration tracking variables
             g_migrationOccurred = true;
             g_firstMigrationTime = Simulator::Now();
             
             // Update subscriber's migration time
             Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
                 nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
             if (subApp) {
                 subApp->m_firstMigrationTime = Simulator::Now();
                 NS_LOG_INFO("Updated subscriber's migration time during forced migration: " 
                           << subApp->m_firstMigrationTime.GetSeconds() << "s");
             }
             
             NS_LOG_UNCOND("FORCED MIGRATION: Node " << newBrokerId << " is now the broker");
         } else {
             NS_LOG_ERROR("Failed to get application for node " << newBrokerId);
         }
     });
     
     // Periodic verification of migration status
     for (double t = 20.0; t <= simTime; t += 10.0) {
         Simulator::Schedule(Seconds(t), [&]() {
             // Check if migration has occurred and update subscriber's record if needed
             if (g_migrationOccurred) {
                 Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
                     nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
                 if (subApp && subApp->m_firstMigrationTime.GetSeconds() <= 0) {
                     subApp->m_firstMigrationTime = g_firstMigrationTime;
                     NS_LOG_INFO("MIGRATION TRACKER: Updated subscriber's migration time at " 
                              << Simulator::Now().GetSeconds() << "s to " 
                              << g_firstMigrationTime.GetSeconds() << "s");
                 }
             }
         });
     }
     
     // Schedule frequent logging of subscriber position and broker status
     for (double t = 5.0; t <= simTime; t += 5.0) {
         Simulator::Schedule(Seconds(t), [&]() {
             Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
             
             // Get current broker ID and its mobility model
             uint32_t currentBrokerId = INITIAL_BROKER_NODE;
             Ptr<MANETApplication> subscriberApp = DynamicCast<MANETApplication>(
                 nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
             
             if (subscriberApp) {
                 currentBrokerId = subscriberApp->GetCurrentBroker();
             }
             
             Ptr<MobilityModel> brokerMob = nodes.Get(currentBrokerId)->GetObject<MobilityModel>();
             
             if (subscriberMob && brokerMob) {
                 Vector subPos = subscriberMob->GetPosition();
                 Vector brkPos = brokerMob->GetPosition();
                 double distance = subscriberMob->GetDistanceFrom(brokerMob);
                 
                 // Check connectivity
                 bool subCanReachBroker = connectivityManager->IsReachable(SUBSCRIBER_NODE, currentBrokerId);
                 bool brokerCanReachSub = connectivityManager->IsReachable(currentBrokerId, SUBSCRIBER_NODE);
                 
                 NS_LOG_UNCOND(Simulator::Now().GetSeconds() << "s: "
                            << "Sub(" << subPos.x << "," << subPos.y << ") "
                            << "Brk[" << currentBrokerId << "](" << brkPos.x << "," << brkPos.y << ") "
                            << "Dist=" << distance << "m "
                            << "Range=" << COMMUNICATION_RANGE << "m "
                            << "S→B=" << (subCanReachBroker ? "YES" : "NO") << " "
                            << "B→S=" << (brokerCanReachSub ? "YES" : "NO"));
             }
         });
     }
     
     // Set up animation
     AnimationInterface anim("manet_dynamic_replica_migration.xml");
     
     // Configure node appearance
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i == PUBLISHER_NODE) {
             anim.UpdateNodeDescription(i, "Publisher");
             anim.UpdateNodeColor(i, 255, 0, 0); // Red
             // 使Publisher节点稍大一些
             anim.UpdateNodeSize(i, 10, 10);
         } else if (i == INITIAL_BROKER_NODE) {
             anim.UpdateNodeDescription(i, "Broker");
             anim.UpdateNodeColor(i, 0, 255, 0); // Green
             // 使Broker节点稍大一些
             anim.UpdateNodeSize(i, 10, 10);
         } else if (i == SUBSCRIBER_NODE) {
          anim.UpdateNodeDescription(i, "Subscriber");
          anim.UpdateNodeColor(i, 0, 0, 255); // Blue
          // 使Subscriber节点稍大一些
          anim.UpdateNodeSize(i, 10, 10);
      } else {
          std::ostringstream desc;
          desc << "Relay Node " << i;
          anim.UpdateNodeDescription(i, desc.str());
          anim.UpdateNodeColor(i, 128, 128, 128); // Gray
      }
  }
  
  // Enable packet metadata for animation
  anim.EnablePacketMetadata(true);
  
  // Set up flow monitor
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();
  
  // Run simulation
  NS_LOG_INFO("Running simulation for " << simTime << " seconds with subscriber speed = " << subscriberSpeed << " m/s");
  Simulator::Stop(Seconds(simTime));
  Simulator::Run();
  
  // Print results
  NS_LOG_INFO("Simulation completed.");
  
  // Get application from subscriber node to access statistics
  Ptr<MANETApplication> subscriberApp = nullptr;
  if (nodes.Get(SUBSCRIBER_NODE)) {
      subscriberApp = DynamicCast<MANETApplication>(nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
  }
  
  if (subscriberApp) {
      double avgDelay = subscriberApp->GetAverageDelay();
      double deliveryRate = subscriberApp->GetDeliveryRate();
      
      std::cout << "结果汇总:" << std::endl;
      std::cout << "  subscriber移动速度: " << subscriberSpeed << " m/s" << std::endl;
      std::cout << "  平均延迟: " << avgDelay * 1000.0 << " ms" << std::endl;
      std::cout << "  消息交付率: " << deliveryRate * 100.0 << "% (" 
               << subscriberApp->GetMessagesReceived() << "/" 
               << subscriberApp->GetMessagesSent() << ")" << std::endl;
      
      // Check migration status from both subscriber app and global tracker
      Time firstMigration = subscriberApp->GetFirstMigrationTime();
      
      if (g_migrationOccurred) {
          std::cout << "  首次副本迁移时间: " << g_firstMigrationTime.GetSeconds() << " 秒 (全局跟踪)" << std::endl;
          if (firstMigration.GetSeconds() > 0) {
              std::cout << "  订阅者记录的首次迁移时间: " << firstMigration.GetSeconds() << " 秒" << std::endl;
          } else {
              std::cout << "  警告: 订阅者未记录迁移时间，但全局跟踪器已检测到迁移" << std::endl;
          }
      } else {
          std::cout << "  未发生副本迁移" << std::endl;
      }
      
      // 添加到日志文件
      NS_LOG_INFO("最终结果(速度=" << subscriberSpeed << "m/s): 平均延迟 = " << avgDelay * 1000.0 << " ms, 消息交付率 = " 
                 << deliveryRate * 100.0 << "% (" 
                 << subscriberApp->GetMessagesReceived() << "/" 
                 << subscriberApp->GetMessagesSent() << ")");
      
      if (g_migrationOccurred) {
          NS_LOG_INFO("全局跟踪的首次副本迁移时间: " << g_firstMigrationTime.GetSeconds() << " 秒");
          if (firstMigration.GetSeconds() > 0) {
              NS_LOG_INFO("订阅者记录的首次副本迁移时间: " << firstMigration.GetSeconds() << " 秒");
          } else {
              NS_LOG_INFO("警告: 订阅者未记录迁移时间，但全局跟踪器已检测到迁移");
          }
      } else {
          NS_LOG_INFO("未发生副本迁移");
      }
  }
  
  // 打印迁移触发机制统计信息
  std::cout << "迁移机制配置:" << std::endl;
  std::cout << "  触发机制: " << (useMsgNotReachedTrigger ? "消息未达触发" : "连接性触发") << std::endl;
  if (useMsgNotReachedTrigger) {
      std::cout << "  触发类型: " << "Broker检测 + 真实业务数据 + 一次未达" << std::endl;
      std::cout << "  确认超时: " << ackTimeoutSeconds << " 秒" << std::endl;
  }
  
  // Flow monitor statistics
  monitor->CheckForLostPackets();
  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
  FlowMonitor::FlowStatsContainer stats = monitor->GetFlowStats();
  
  std::cout << "Flow monitor statistics:" << std::endl;
  
  for (auto i = stats.begin(); i != stats.end(); ++i) {
      Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
      std::cout << "Flow " << i->first << " (" << t.sourceAddress << " -> " 
               << t.destinationAddress << ")" << std::endl;
      std::cout << "  Tx Packets: " << i->second.txPackets << std::endl;
      std::cout << "  Rx Packets: " << i->second.rxPackets << std::endl;
      std::cout << "  Throughput: " << i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds() 
                                                                - i->second.timeFirstTxPacket.GetSeconds()) / 1024 
               << " Kbps" << std::endl;
  }
  
  // Generate trace file for post-processing
  std::string outFileName = "manet_results_speed_" + std::to_string(subscriberSpeed) + ".txt";
  std::ofstream outFile(outFileName);
  if (outFile.is_open()) {
      outFile << "# MANET Dynamic Replica Migration Experiment Results" << std::endl;
      outFile << "# Simulation parameters:" << std::endl;
      outFile << "# - Total nodes: " << TOTAL_NODES << std::endl;
      outFile << "# - Simulation time: " << simTime << " seconds" << std::endl;
      outFile << "# - Simulation area: " << SIMULATION_AREA << " x " << SIMULATION_AREA << " meters" << std::endl;
      outFile << "# - Subscriber mobility speed: " << subscriberSpeed << " m/s" << std::endl;
      outFile << "# - Communication range: " << COMMUNICATION_RANGE << " meters" << std::endl;
      outFile << "# - Scoring formula weights: alpha=" << alpha << ", beta=" << beta << ", gamma=" << gamma << std::endl;
      outFile << "# - Migration trigger: " << (useMsgNotReachedTrigger ? "消息未达触发 (Broker+真实业务数据+一次未达)" : "连接性触发") << std::endl;
      outFile << "# - ACK timeout: " << ackTimeoutSeconds << " seconds" << std::endl;
      outFile << std::endl;
      
      // Add detailed results
      if (subscriberApp) {
          outFile << "Average Delay (ms): " << subscriberApp->GetAverageDelay() * 1000.0 << std::endl;
          outFile << "Message Delivery Rate (%): " << subscriberApp->GetDeliveryRate() * 100.0 << std::endl;
          
          if (g_migrationOccurred) {
              outFile << "First Migration Time (s): " << g_firstMigrationTime.GetSeconds() << std::endl;
          } else {
              outFile << "No migration occurred" << std::endl;
          }
      }
      
      // Add flow monitor statistics
      outFile << "Flow statistics:" << std::endl;
      for (auto i = stats.begin(); i != stats.end(); ++i) {
          Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
          outFile << "Flow " << i->first << " (" << t.sourceAddress << " -> " 
                  << t.destinationAddress << ")" << std::endl;
          outFile << "  Tx Packets: " << i->second.txPackets << std::endl;
          outFile << "  Rx Packets: " << i->second.rxPackets << std::endl;
          outFile << "  Throughput (Kbps): " << i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds() 
                                                                     - i->second.timeFirstTxPacket.GetSeconds()) / 1024 
                  << std::endl;
      }
      
      outFile.close();
  }
  
  Simulator::Destroy();
  
  return 0;
}