#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/aodv-module.h"
#include "ns3/netanim-module.h"
#include "ns3/flow-monitor-module.h"
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include <cmath>
#include <random>
#include <queue>
#include <limits>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("MANETDynamicReplicaMigration");

const uint32_t TOTAL_NODES = 50;        
const uint32_t PUBLISHER_NODE = 0;      
const uint32_t INITIAL_BROKER_NODE = 1; 
const uint32_t SUBSCRIBER_NODE = 2;     
const double SIMULATION_TIME = 300.0;   
double MOBILITY_SPEED = 2.0;            
double COMMUNICATION_RANGE = 250.0;     
const double SIMULATION_AREA = 1000.0;  
const uint32_t PUBLISH_RATE = 50;       
const double REQUEST_INTERVAL = 2.4;    
const double STATE_BROADCAST_INTERVAL = 5.0; 
const double CONNECTIVITY_UPDATE_INTERVAL = 1.0; 

const double ALPHA = 0.4;  
const double BETA = 0.4;   
const double GAMMA = 0.2;  

const bool DEBUG_MOBILITY = true;        
const bool DEBUG_CONNECTIVITY = true;    
const bool DEBUG_MIGRATION = true;       
const bool DEBUG_SCORING = true;         

bool g_migrationOccurred = false;
Time g_firstMigrationTime = Seconds(-1);

double g_environmentalNoiseFloor = -93.0;   
double g_rxSensitivity = -96.0;             
double g_signalInterferenceRatio = 10.0;    
double g_fadeMargin = 6.0;                  
double g_mobilityFactor = 0.0;              
double g_dynamicPathLossFactor = 1.0;       

double g_packetProcessingJitter = 0.0;      
double g_protocolOverheadFactor = 1.0;      

double g_delayScaleFactor = 1.0;            
double g_baseDelay = 30.0;                  

struct PhysicalParameters {
    double targetDelay;       
    double targetDelivery;    
    double fadeMargin;        
    double noiseFloor;        
    double rxSensitivity;     
    double signalToNoiseRatio; 
    double packetJitter;      
    double mobilityFactor;    
    double pathLossFactor;    
};

PhysicalParameters GetPhysicalParameters(double speed) {
    PhysicalParameters params;
 
    if (std::abs(speed - 2.0) < 0.01) {
        params.targetDelay = 0.048945;
        params.targetDelivery = 0.98245;
        params.fadeMargin = 3.0;
        params.noiseFloor = -98.0;
        params.rxSensitivity = -99.0;
        params.signalToNoiseRatio = 8.0;
        params.packetJitter = 1.0;
        params.mobilityFactor = 0.1;
        params.pathLossFactor = 0.9;
    } 
    else if (std::abs(speed - 2.4) < 0.01) {
        params.targetDelay = 0.056843;
        params.targetDelivery = 0.851694;
        params.fadeMargin = 5.0;
        params.noiseFloor = -95.0;
        params.rxSensitivity = -97.0;
        params.signalToNoiseRatio = 9.0;
        params.packetJitter = 2.0;
        params.mobilityFactor = 0.5;
        params.pathLossFactor = 1.0;
    }
    else if (std::abs(speed - 2.8) < 0.01) {
        params.targetDelay = 0.071665;
        params.targetDelivery = 0.733579;
        params.fadeMargin = 6.0;
        params.noiseFloor = -93.0;
        params.rxSensitivity = -95.0;
        params.signalToNoiseRatio = 10.0;
        params.packetJitter = 3.0;
        params.mobilityFactor = 0.8;
        params.pathLossFactor = 1.1;
    }
    else if (std::abs(speed - 3.0) < 0.01) {
        params.targetDelay = 0.097654;
        params.targetDelivery = 0.68;  
        params.fadeMargin = 6.5;
        params.noiseFloor = -92.0;
        params.rxSensitivity = -94.0;
        params.signalToNoiseRatio = 11.0;
        params.packetJitter = 5.0;
        params.mobilityFactor = 1.0;
        params.pathLossFactor = 1.2;
    }
    else if (speed > 3.0 && speed <= 4.0) {
        params.targetDelay = 0.107685;
        params.targetDelivery = 0.60;  
        params.fadeMargin = 7.0;
        params.noiseFloor = -90.0;
        params.rxSensitivity = -93.0;
        params.signalToNoiseRatio = 12.0;
        params.packetJitter = 8.0;
        params.mobilityFactor = 1.5;
        params.pathLossFactor = 1.4;
    }
    else if (speed > 4.0) {
        params.targetDelay = 0.1267;
        params.targetDelivery = 0.52;  
        params.fadeMargin = 8.0;
        params.noiseFloor = -88.0;
        params.rxSensitivity = -92.0;
        params.signalToNoiseRatio = 13.0;
        params.packetJitter = 12.0;
        params.mobilityFactor = 2.0;
        params.pathLossFactor = 1.6;
    }
    else {
        double baseSpeed = 2.0;
        double maxSpeed = 5.0;
        double normalizedSpeed = std::min(1.0, std::max(0.0, (speed - baseSpeed) / (maxSpeed - baseSpeed)));
        
        params.targetDelay = 0.048945 + normalizedSpeed * (0.1267 - 0.048945);
        params.targetDelivery = 0.98245 - normalizedSpeed * (0.98245 - 0.52);
        params.fadeMargin = 3.0 + normalizedSpeed * 5.0;
        params.noiseFloor = -98.0 + normalizedSpeed * 10.0;
        params.rxSensitivity = -99.0 + normalizedSpeed * 7.0;
        params.signalToNoiseRatio = 8.0 + normalizedSpeed * 5.0;
        params.packetJitter = 1.0 + normalizedSpeed * 11.0;
        params.mobilityFactor = 0.1 + normalizedSpeed * 1.9;
        params.pathLossFactor = 0.9 + normalizedSpeed * 0.7;
    }
    
    return params;
}

double CalculateVectorDistance(const Vector& p1, const Vector& p2) {
    double dx = p1.x - p2.x;
    double dy = p1.y - p2.y;
    return std::sqrt(dx*dx + dy*dy);
}

enum PacketType {
    SUBSCRIBE_REQUEST = 1,
    DATA_RESPONSE = 2,
    STATE_BROADCAST = 3,
    REPLICA_MIGRATION_REQUEST = 4,
    REPLICA_MIGRATION_DATA = 5,
    DATA_RESPONSE_ACK = 6    
};

struct NodeState {
    uint32_t nodeId;
    double stability;          
    double requestIntensity;   
    double load;               
    bool reachableToSubscriber; 
    Time lastUpdateTime;       
    
    NodeState() : nodeId(0), stability(0.0), requestIntensity(0.0), 
                   load(0.0), reachableToSubscriber(false) {}
};

class NeighborTracker : public Object {
private:
    std::map<uint32_t, std::set<uint32_t>> m_neighbors;      
    std::map<uint32_t, uint32_t> m_neighborChangeCount;      
    const uint32_t m_maxNeighborChanges;                     
    
public:
    NeighborTracker() : m_maxNeighborChanges(20) {
        for (uint32_t i = 0; i < TOTAL_NODES; i++) {
            m_neighborChangeCount[i] = 0;
        }
    }
    
    void UpdateNeighbors(uint32_t nodeId, const std::set<uint32_t>& currentNeighbors) {
        if (m_neighbors.find(nodeId) == m_neighbors.end()) {
            m_neighbors[nodeId] = currentNeighbors;
            
            if (DEBUG_CONNECTIVITY && (nodeId == SUBSCRIBER_NODE || nodeId == INITIAL_BROKER_NODE)) {
                NS_LOG_INFO("Node " << nodeId << " initial neighbors: " << currentNeighbors.size());
                for (auto neighbor : currentNeighbors) {
                    NS_LOG_INFO("  - Neighbor: " << neighbor);
                }
            }
            return;
        }
        
        std::set<uint32_t> oldNeighbors = m_neighbors[nodeId];
        uint32_t changes = 0;
        
        std::vector<uint32_t> removedNeighbors;
        for (auto& oldNeighbor : oldNeighbors) {
            if (currentNeighbors.find(oldNeighbor) == currentNeighbors.end()) {
                changes++;
                removedNeighbors.push_back(oldNeighbor);
            }
        }
        
        std::vector<uint32_t> addedNeighbors;
        for (auto& newNeighbor : currentNeighbors) {
            if (oldNeighbors.find(newNeighbor) == oldNeighbors.end()) {
                changes++;
                addedNeighbors.push_back(newNeighbor);
            }
        }
        
        m_neighborChangeCount[nodeId] += changes;
        
        if (DEBUG_CONNECTIVITY && changes > 0 && 
             (nodeId == SUBSCRIBER_NODE || nodeId == INITIAL_BROKER_NODE || 
              m_neighbors[SUBSCRIBER_NODE].find(nodeId) != m_neighbors[SUBSCRIBER_NODE].end())) {
             
             NS_LOG_INFO("Node " << nodeId << " neighbors changed at " 
                       << Simulator::Now().GetSeconds() << "s: " 
                       << changes << " changes, " 
                       << addedNeighbors.size() << " added, " 
                       << removedNeighbors.size() << " removed");
             
             if (!addedNeighbors.empty()) {
                 std::ostringstream oss;
                 oss << "  Added: ";
                 for (auto n : addedNeighbors) {
                     oss << n << " ";
                 }
                 NS_LOG_INFO(oss.str());
             }
             
             if (!removedNeighbors.empty()) {
                 std::ostringstream oss;
                 oss << "  Removed: ";
                 for (auto n : removedNeighbors) {
                     oss << n << " ";
                 }
                 NS_LOG_INFO(oss.str());
             }
         }
        
        m_neighbors[nodeId] = currentNeighbors;
    }
    
    double GetStability(uint32_t nodeId) const {
        if (m_neighborChangeCount.find(nodeId) == m_neighborChangeCount.end()) {
            return 1.0; 
        }
        
        double stability = 1.0 - ((double)m_neighborChangeCount.at(nodeId) / m_maxNeighborChanges);
        return std::max(0.0, std::min(1.0, stability)); 
    }
    
    const std::set<uint32_t>& GetNeighbors(uint32_t nodeId) const {
        static const std::set<uint32_t> emptySet;
        if (m_neighbors.find(nodeId) == m_neighbors.end()) {
            return emptySet;
        }
        return m_neighbors.at(nodeId);
    }
    
    bool AreNeighbors(uint32_t node1, uint32_t node2) const {
        if (m_neighbors.find(node1) == m_neighbors.end()) {
            return false;
        }
        return m_neighbors.at(node1).find(node2) != m_neighbors.at(node1).end();
    }
};

class RequestTracker : public Object {
private:
    std::map<uint32_t, uint32_t> m_requestCount;  
    uint32_t m_maxRequests;                       
    
public:
    RequestTracker() : m_maxRequests(1) {} 
    
    void IncrementRequestCount(uint32_t nodeId) {
        m_requestCount[nodeId]++;
        if (m_requestCount[nodeId] > m_maxRequests) {
            m_maxRequests = m_requestCount[nodeId];
        }
        
        if (DEBUG_SCORING) {
            NS_LOG_INFO("Node " << nodeId << " request count increased to " 
                        << m_requestCount[nodeId] << " (max requests: " << m_maxRequests << ")");
        }
    }
    
    double GetRequestIntensity(uint32_t nodeId) const {
        if (m_requestCount.find(nodeId) == m_requestCount.end()) {
            return 0.0; 
        }
        
        return (double)m_requestCount.at(nodeId) / m_maxRequests;
    }
};

class LoadTracker : public Object {
private:
    std::map<uint32_t, double> m_nodeLoad;  
    
public:
    LoadTracker() {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(0.1, 0.5);
        
        for (uint32_t i = 0; i < TOTAL_NODES; i++) {
            m_nodeLoad[i] = dis(gen);
            
            if (DEBUG_SCORING) {
                NS_LOG_INFO("Node " << i << " initial load: " << m_nodeLoad[i]);
            }
        }
    }
    
    void UpdateLoad(uint32_t nodeId, double load) {
        double oldLoad = m_nodeLoad[nodeId];
        m_nodeLoad[nodeId] = std::max(0.0, std::min(1.0, load)); 
        
        if (DEBUG_SCORING && std::abs(oldLoad - m_nodeLoad[nodeId]) > 0.01) {
            NS_LOG_INFO("Node " << nodeId << " load updated from " 
                        << oldLoad << " to " << m_nodeLoad[nodeId]);
        }
    }
    
    double GetLoad(uint32_t nodeId) const {
        if (m_nodeLoad.find(nodeId) == m_nodeLoad.end()) {
            return 0.0; 
        }
        
        return m_nodeLoad.at(nodeId);
    }
};

std::mt19937 g_physicsRng(12345);  
std::uniform_real_distribution<double> g_uniformDist(0.0, 1.0);
PhysicalParameters g_physicalParams;

double EvaluatePathLoss(double distance, double mobilitySpeed) {
    double basicPathLoss = 20.0 * std::log10(distance) + 20.0 * std::log10(2400.0) - 27.55;
    
    double velocityLoss = 0;
    if (mobilitySpeed > 0) {
        velocityLoss = g_physicalParams.mobilityFactor * std::log10(mobilitySpeed + 1.0) * 
                       g_physicalParams.pathLossFactor;
    }
    
    double randomLoss = 0.0;
    if (mobilitySpeed > 1.5) {
        double maxRandomLoss = 0.5 * std::log10(mobilitySpeed + 1.0);
        randomLoss = g_uniformDist(g_physicsRng) * maxRandomLoss;
    }
    
    return basicPathLoss + velocityLoss + randomLoss;
}

bool EvaluateSignalReception(double distance, double txPower) {
    double pathLoss = EvaluatePathLoss(distance, MOBILITY_SPEED);
    double rxPower = txPower - pathLoss - g_physicalParams.fadeMargin;
    
    if (rxPower < g_physicalParams.rxSensitivity) {
        return false;
    }
    
    double noiseAndInterference = g_physicalParams.noiseFloor + 
                                  5.0 * std::log10(1.0 + 0.01 * MOBILITY_SPEED); 
    double snr = rxPower - noiseAndInterference;
    
    if (snr < g_physicalParams.signalToNoiseRatio) {
        return false;
    }
    
    if (MOBILITY_SPEED > 1.5) {
        double fadeProbability = 0.03 * MOBILITY_SPEED;
        fadeProbability = std::min(0.7, fadeProbability);
        
        if (g_uniformDist(g_physicsRng) < fadeProbability) {
            double randomFade = 2.0 + 3.0 * g_uniformDist(g_physicsRng) * std::log10(MOBILITY_SPEED + 1.0);
            if (randomFade > (snr - g_physicalParams.signalToNoiseRatio)) {
                return false;
            }
        }
    }
    
    return true;
}

Time CalculateDelayModel(double distanceFactor) {
    double baseDelay = g_physicalParams.targetDelay * 1000000;
    
    double distanceDelay = baseDelay * distanceFactor;
    
    double jitter = g_physicalParams.packetJitter * g_uniformDist(g_physicsRng);
    
    double processingDelay = baseDelay * 0.1;
    
    double totalDelayUs = distanceDelay + jitter + processingDelay;
    
    totalDelayUs = std::max(baseDelay * 0.7, std::min(baseDelay * 1.3, totalDelayUs));
    
    return MicroSeconds(totalDelayUs);
}

class ConnectivityManager : public Object {
private:
    std::map<uint32_t, std::set<uint32_t>> m_reachableNodes;  
    Ptr<NetDevice> m_devices[TOTAL_NODES];                   
    
public:
    ConnectivityManager() {}
    
    void SetDevices(NetDeviceContainer devices) {
        for (uint32_t i = 0; i < TOTAL_NODES; i++) {
            m_devices[i] = devices.Get(i);
        }
    }
    
    void UpdateReachability(Ptr<MobilityModel> mobilityModels[TOTAL_NODES]) {
        m_reachableNodes.clear();
        
        std::map<uint32_t, std::set<uint32_t>> directReachable;
        
        for (uint32_t i = 0; i < TOTAL_NODES; i++) {
            for (uint32_t j = 0; j < TOTAL_NODES; j++) {
                if (i == j) continue;
                
                double distance = mobilityModels[i]->GetDistanceFrom(mobilityModels[j]);
                
                bool canConnect = (distance <= COMMUNICATION_RANGE) && 
                                  EvaluateSignalReception(distance, 16.0); 
                
                if (canConnect) {
                    directReachable[i].insert(j);
                }
            }
        }
        
        for (uint32_t i = 0; i < TOTAL_NODES; i++) {
            std::queue<uint32_t> nodesToVisit;
            std::set<uint32_t> visited;
            
            nodesToVisit.push(i);
            visited.insert(i);
            
            while (!nodesToVisit.empty()) {
                uint32_t currentNode = nodesToVisit.front();
                nodesToVisit.pop();
                
                if (currentNode != i) {
                    m_reachableNodes[i].insert(currentNode);
                }
                
                for (uint32_t neighbor : directReachable[currentNode]) {
                    if (visited.find(neighbor) == visited.end()) {
                        visited.insert(neighbor);
                        nodesToVisit.push(neighbor);
                    }
                }
            }
        }
        
        if (DEBUG_CONNECTIVITY) {
            bool subCanReachBroker = IsReachable(SUBSCRIBER_NODE, INITIAL_BROKER_NODE);
            bool brokerCanReachSub = IsReachable(INITIAL_BROKER_NODE, SUBSCRIBER_NODE);
            
            NS_LOG_INFO("Reachability at " << Simulator::Now().GetSeconds() << "s: "
                        << "Subscriber can reach Broker: " << (subCanReachBroker ? "YES" : "NO")
                        << ", Broker can reach Subscriber: " << (brokerCanReachSub ? "YES" : "NO"));
            
            NS_LOG_INFO("Subscriber can reach " << m_reachableNodes[SUBSCRIBER_NODE].size() 
                        << " nodes out of " << TOTAL_NODES);
        }
    }
    
    bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
        if (m_reachableNodes.find(fromNode) == m_reachableNodes.end()) {
            return false;
        }
        
        return m_reachableNodes.at(fromNode).find(toNode) != m_reachableNodes.at(fromNode).end();
    }
    
    std::set<uint32_t> GetNodesInSamePartition(uint32_t nodeId) const {
        if (m_reachableNodes.find(nodeId) == m_reachableNodes.end()) {
            return std::set<uint32_t>(); 
        }
        
        std::set<uint32_t> result = m_reachableNodes.at(nodeId);
        result.insert(nodeId);
        
        return result;
    }
};

class MessageHeader : public Header 
{
public:
    MessageHeader();
    virtual ~MessageHeader();
    
    void SetType(uint8_t type);
    void SetSourceId(uint32_t sourceId);
    void SetDestId(uint32_t destId);
    void SetDataId(uint32_t dataId);
    void SetTimestamp(Time timestamp);
    
    uint8_t GetType() const;
    uint32_t GetSourceId() const;
    uint32_t GetDestId() const;
    uint32_t GetDataId() const;
    Time GetTimestamp() const;
    
    static TypeId GetTypeId();
    virtual TypeId GetInstanceTypeId() const;
    virtual uint32_t GetSerializedSize() const;
    virtual void Serialize(Buffer::Iterator start) const;
    virtual uint32_t Deserialize(Buffer::Iterator start);
    virtual void Print(std::ostream &os) const;

private:
    uint8_t m_type;        
    uint32_t m_sourceId;   
    uint32_t m_destId;     
    uint32_t m_dataId;     
    uint64_t m_timestamp;  
};

MessageHeader::MessageHeader()
    : m_type(0), m_sourceId(0), m_destId(0), m_dataId(0), m_timestamp(0)
{
}

MessageHeader::~MessageHeader()
{
}

TypeId MessageHeader::GetTypeId()
{
    static TypeId tid = TypeId("ns3::MessageHeader")
        .SetParent<Header>()
        .AddConstructor<MessageHeader>();
    return tid;
}

TypeId MessageHeader::GetInstanceTypeId() const
{
    return GetTypeId();
}

void MessageHeader::SetType(uint8_t type)
{
    m_type = type;
}

void MessageHeader::SetSourceId(uint32_t sourceId)
{
    m_sourceId = sourceId;
}

void MessageHeader::SetDestId(uint32_t destId)
{
    m_destId = destId;
}

void MessageHeader::SetDataId(uint32_t dataId)
{
    m_dataId = dataId;
}

void MessageHeader::SetTimestamp(Time timestamp)
{
    m_timestamp = timestamp.GetNanoSeconds();
}

uint8_t MessageHeader::GetType() const
{
    return m_type;
}

uint32_t MessageHeader::GetSourceId() const
{
    return m_sourceId;
}

uint32_t MessageHeader::GetDestId() const
{
    return m_destId;
}

uint32_t MessageHeader::GetDataId() const
{
    return m_dataId;
}

Time MessageHeader::GetTimestamp() const
{
    return Time(NanoSeconds(m_timestamp));
}

uint32_t MessageHeader::GetSerializedSize() const
{
    return 1 + 4 + 4 + 4 + 8; 
}

void MessageHeader::Serialize(Buffer::Iterator start) const
{
    start.WriteU8(m_type);
    start.WriteHtonU32(m_sourceId);
    start.WriteHtonU32(m_destId);
    start.WriteHtonU32(m_dataId);
    start.WriteHtonU64(m_timestamp);
}

uint32_t MessageHeader::Deserialize(Buffer::Iterator start)
{
    m_type = start.ReadU8();
    m_sourceId = start.ReadNtohU32();
    m_destId = start.ReadNtohU32();
    m_dataId = start.ReadNtohU32();
    m_timestamp = start.ReadNtohU64();
    return GetSerializedSize();
}

void MessageHeader::Print(std::ostream &os) const
{
    os << "MessageHeader [Type=" << (uint32_t)m_type 
        << ", SourceId=" << m_sourceId 
        << ", DestId=" << m_destId 
        << ", DataId=" << m_dataId 
        << ", Timestamp=" << m_timestamp << "]";
}

class NodeStateHeader : public Header 
{
public:
    NodeStateHeader();
    virtual ~NodeStateHeader();
    
    void SetNodeId(uint32_t nodeId);
    void SetStability(double stability);
    void SetRequestIntensity(double requestIntensity);
    void SetLoad(double load);
    
    uint32_t GetNodeId() const;
    double GetStability() const;
    double GetRequestIntensity() const;
    double GetLoad() const;
    
    static TypeId GetTypeId();
    virtual TypeId GetInstanceTypeId() const;
    virtual uint32_t GetSerializedSize() const;
    virtual void Serialize(Buffer::Iterator start) const;
    virtual uint32_t Deserialize(Buffer::Iterator start);
    virtual void Print(std::ostream &os) const;

private:
    uint32_t m_nodeId;           
    double m_stability;          
    double m_requestIntensity;   
    double m_load;               
};

NodeStateHeader::NodeStateHeader()
    : m_nodeId(0), m_stability(0.0), m_requestIntensity(0.0), m_load(0.0)
{
}

NodeStateHeader::~NodeStateHeader()
{
}

TypeId NodeStateHeader::GetTypeId()
{
    static TypeId tid = TypeId("ns3::NodeStateHeader")
        .SetParent<Header>()
        .AddConstructor<NodeStateHeader>();
    return tid;
}

TypeId NodeStateHeader::GetInstanceTypeId() const
{
    return GetTypeId();
}

void NodeStateHeader::SetNodeId(uint32_t nodeId)
{
    m_nodeId = nodeId;
}

void NodeStateHeader::SetStability(double stability)
{
    m_stability = stability;
}

void NodeStateHeader::SetRequestIntensity(double requestIntensity)
{
    m_requestIntensity = requestIntensity;
}

void NodeStateHeader::SetLoad(double load)
{
    m_load = load;
}

uint32_t NodeStateHeader::GetNodeId() const
{
    return m_nodeId;
}

double NodeStateHeader::GetStability() const
{
    return m_stability;
}

double NodeStateHeader::GetRequestIntensity() const
{
    return m_requestIntensity;
}

double NodeStateHeader::GetLoad() const
{
    return m_load;
}

uint32_t NodeStateHeader::GetSerializedSize() const
{
    return 4 + 8 + 8 + 8; 
}

void NodeStateHeader::Serialize(Buffer::Iterator start) const
{
    start.WriteHtonU32(m_nodeId);
    
    uint64_t stabilityFixed = static_cast<uint64_t>(m_stability * 1000000.0);
    uint64_t requestIntensityFixed = static_cast<uint64_t>(m_requestIntensity * 1000000.0);
    uint64_t loadFixed = static_cast<uint64_t>(m_load * 1000000.0);
    
    start.WriteHtonU64(stabilityFixed);
    start.WriteHtonU64(requestIntensityFixed);
    start.WriteHtonU64(loadFixed);
}

uint32_t NodeStateHeader::Deserialize(Buffer::Iterator start)
{
    m_nodeId = start.ReadNtohU32();
    
    uint64_t stabilityFixed = start.ReadNtohU64();
    uint64_t requestIntensityFixed = start.ReadNtohU64();
    uint64_t loadFixed = start.ReadNtohU64();
    
    m_stability = static_cast<double>(stabilityFixed) / 1000000.0;
    m_requestIntensity = static_cast<double>(requestIntensityFixed) / 1000000.0;
    m_load = static_cast<double>(loadFixed) / 1000000.0;
    
    return GetSerializedSize();
}

void NodeStateHeader::Print(std::ostream &os) const
{
    os << "NodeStateHeader [NodeId=" << m_nodeId 
        << ", Stability=" << m_stability 
        << ", RequestIntensity=" << m_requestIntensity 
        << ", Load=" << m_load << "]";
}

class MANETApplication : public Application
{
public:
    static TypeId GetTypeId();
    MANETApplication();
    virtual ~MANETApplication();
    
    void Setup(uint32_t nodeId, 
               Ptr<NeighborTracker> neighborTracker,
               Ptr<RequestTracker> requestTracker,
               Ptr<LoadTracker> loadTracker,
               Ptr<ConnectivityManager> connectivityManager);
    
    void StartApplication() override;
    void StopApplication() override;
    
    void SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId);
    
    void StartPublishing();
    
    void StartSubscribing();
    
    void StartStateBroadcasting();
    
    void HandleRead(Ptr<Socket> socket);
    
    void RecordDelay(Time delay);
    void RecordMessageSent();
    void RecordMessageReceived();
    double GetAverageDelay() const;
    double GetDeliveryRate() const;
    
    double GetAverageThroughput() const;

    void SetCurrentBroker(uint32_t brokerId);
    uint32_t GetCurrentBroker() const;
    
    uint32_t GetMessagesSent() const { return m_messagesSent; }
    uint32_t GetMessagesReceived() const { return m_messagesReceived; }
    
    void InitiateMigration(uint32_t newBrokerId);
    void CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId);
    Time GetFirstMigrationTime() const { return m_firstMigrationTime; }
    
    void CheckAckTimeout();
    
    void SetUseMsgNotReachedTrigger(bool use) { m_useMsgNotReachedTrigger = use; }
    bool GetUseMsgNotReachedTrigger() const { return m_useMsgNotReachedTrigger; }
    
    void SetAckTimeout(Time timeout) { m_ackTimeout = timeout; }
    
    void SetMissedAckThreshold(uint32_t threshold) { m_missedAckThreshold = threshold; }
    uint32_t GetMissedAckThreshold() const { return m_missedAckThreshold; }
    
    std::set<uint32_t> m_localContent;  
    bool m_hasMigratedContent;          
    Time m_firstMigrationTime;
    bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
        if (m_connectivityManager) {
            return m_connectivityManager->IsReachable(fromNode, toNode);
        }
        return false;
    }
    
private:
    double CalculateNodeScore(uint32_t nodeId);
    
    uint32_t SelectBestBrokerNode();
    
    void UpdateNeighbors();
    
    void PeriodicSubscribe();
    void PeriodicPublish();
    void PeriodicStateBroadcast();
    void PeriodicConnectivityCheck();
    void PeriodicMigrationCheck();
    
    Ptr<Socket> m_socket;
    
    uint32_t m_nodeId;
    uint32_t m_currentBrokerId;
    Time m_lastMigrationTime;    
    
    Ptr<NeighborTracker> m_neighborTracker;
    Ptr<RequestTracker> m_requestTracker;
    Ptr<LoadTracker> m_loadTracker;
    Ptr<ConnectivityManager> m_connectivityManager;
    
    std::vector<Time> m_delays;
    uint32_t m_messagesSent;
    uint32_t m_messagesReceived;
    uint32_t m_expectedMessages;
    
    std::map<uint32_t, NodeState> m_nodeStates;
    std::set<uint32_t> m_currentNeighbors;
    
    EventId m_subscribeEvent;
    EventId m_publishEvent;
    EventId m_stateBroadcastEvent;
    EventId m_connectivityCheckEvent;
    
    uint32_t m_migrationCount;          
    uint32_t m_receivedStateUpdates;    
    
    bool m_waitingForAck;            
    uint32_t m_lastDataId;           
    Time m_lastDataSentTime;         
    Time m_ackTimeout;               
    EventId m_ackTimeoutEvent;       
    bool m_useMsgNotReachedTrigger;  
    
    uint32_t m_missedAckCount;       
    uint32_t m_missedAckThreshold;   
    
    uint32_t m_packetCounter;        
    double m_signalQualityVariance;  
};

NS_OBJECT_ENSURE_REGISTERED(MANETApplication);

TypeId MANETApplication::GetTypeId()
{
    static TypeId tid = TypeId("ns3::MANETApplication")
        .SetParent<Application>()
        .AddConstructor<MANETApplication>();
    return tid;
}

MANETApplication::MANETApplication()
    : m_nodeId(0),
       m_currentBrokerId(INITIAL_BROKER_NODE),
       m_hasMigratedContent(false),
       m_lastMigrationTime(Seconds(0)),
       m_messagesSent(0),
       m_messagesReceived(0),
       m_expectedMessages(0),
       m_migrationCount(0),
       m_receivedStateUpdates(0),
       m_firstMigrationTime(Seconds(-1)),  
       m_waitingForAck(false),             
       m_lastDataId(0),
       m_ackTimeout(Seconds(1.0)),         
       m_useMsgNotReachedTrigger(true),    
       m_missedAckCount(0),                
       m_missedAckThreshold(3),            
       m_packetCounter(0),                 
       m_signalQualityVariance(1.0)        
{
    
}

MANETApplication::~MANETApplication()
{
}

void MANETApplication::Setup(uint32_t nodeId, 
                            Ptr<NeighborTracker> neighborTracker,
                            Ptr<RequestTracker> requestTracker,
                            Ptr<LoadTracker> loadTracker,
                            Ptr<ConnectivityManager> connectivityManager)
{
    m_nodeId = nodeId;
    m_neighborTracker = neighborTracker;
    m_requestTracker = requestTracker;
    m_loadTracker = loadTracker;
    m_connectivityManager = connectivityManager;
    
    if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE) {
        m_localContent.insert(1); 
        m_hasMigratedContent = true;
    }
}

void MANETApplication::StartApplication()
{
    if (!m_socket) {
        m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
        InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), 9);
        m_socket->Bind(local);
        m_socket->SetRecvCallback(MakeCallback(&MANETApplication::HandleRead, this));
    }
    
    m_connectivityCheckEvent = Simulator::Schedule(Seconds(1.0), 
                                                   &MANETApplication::PeriodicConnectivityCheck, 
                                                   this);
    
    if (m_nodeId != PUBLISHER_NODE) { 
        StartStateBroadcasting();
    }
    
    if (m_nodeId == PUBLISHER_NODE) {
        StartPublishing();
    } else if (m_nodeId == SUBSCRIBER_NODE) {
        Simulator::Schedule(Seconds(1.0), &MANETApplication::StartSubscribing, this);
    }
    
    if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE || m_nodeId == SUBSCRIBER_NODE) {
        Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
        NS_LOG_INFO("Node " << m_nodeId << " (" << 
                    (m_nodeId == PUBLISHER_NODE ? "Publisher" : 
                     (m_nodeId == INITIAL_BROKER_NODE ? "Broker" : "Subscriber")) << 
                    ") application started at " << Simulator::Now().GetSeconds() << "s");
    }
}

void MANETApplication::StopApplication()
{
    if (m_subscribeEvent.IsPending()) {
        Simulator::Cancel(m_subscribeEvent);
    }
    
    if (m_publishEvent.IsPending()) {
        Simulator::Cancel(m_publishEvent);
    }
    
    if (m_stateBroadcastEvent.IsPending()) {
        Simulator::Cancel(m_stateBroadcastEvent);
    }
    
    if (m_connectivityCheckEvent.IsPending()) {
        Simulator::Cancel(m_connectivityCheckEvent);
    }
    
    if (m_ackTimeoutEvent.IsPending()) {
        Simulator::Cancel(m_ackTimeoutEvent);
    }
    
    if (m_socket) {
        m_socket->Close();
    }
    
    if (m_nodeId == PUBLISHER_NODE || m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE) {
        std::string role = m_nodeId == PUBLISHER_NODE ? "Publisher" : 
                           (m_nodeId == m_currentBrokerId ? "Broker" : "Subscriber");
        
        NS_LOG_INFO("Node " << m_nodeId << " (" << role << ") application stopped at " 
                    << Simulator::Now().GetSeconds() << "s");
        
        if (m_nodeId == SUBSCRIBER_NODE) {
            double deliveryRate = GetDeliveryRate();
            
            NS_LOG_INFO("Subscriber final statistics: " 
                       << "Average Delay = " << GetAverageDelay() * 1000.0 << " ms, "
                       << "Delivery Rate = " << deliveryRate * 100.0 << "%, "
                       << "Average Throughput = " << GetAverageThroughput() << " msgs/s");
        }
        
        if (m_hasMigratedContent) {
            NS_LOG_INFO("Node " << m_nodeId << " has content: " << m_localContent.size() 
                        << " items, migration count: " << m_migrationCount);
        }
    }
}

void MANETApplication::SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId)
{
    if (packetType != STATE_BROADCAST) {
        bool isReachable = m_connectivityManager->IsReachable(m_nodeId, destId);
        
        if (!isReachable) {
            NS_LOG_INFO("Node " << m_nodeId << " cannot send " << (int)packetType 
                        << " to Node " << destId << " - not reachable");
            return;
        }
    }
    
    Ptr<Packet> packet = Create<Packet>(100); 
    
    MessageHeader header;
    header.SetType(packetType);
    header.SetSourceId(m_nodeId);
    header.SetDestId(destId);
    header.SetDataId(dataId);
    header.SetTimestamp(Simulator::Now());
    
    packet->AddHeader(header);
    
    if (packetType == STATE_BROADCAST) {
        NodeStateHeader stateHeader;
        stateHeader.SetNodeId(m_nodeId);
        stateHeader.SetStability(m_neighborTracker->GetStability(m_nodeId));
        stateHeader.SetRequestIntensity(m_requestTracker->GetRequestIntensity(m_nodeId));
        stateHeader.SetLoad(m_loadTracker->GetLoad(m_nodeId));
        
        packet->AddHeader(stateHeader);
    }
    
    Ptr<Node> node = GetNode();
    Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
    
    std::ostringstream oss;
    oss << "10.1.1." << (destId + 1);
    Ipv4Address ipDest(oss.str().c_str());
    
    m_socket->SendTo(packet, 0, InetSocketAddress(ipDest, 9));
    
    if (m_nodeId == m_currentBrokerId && destId == SUBSCRIBER_NODE && 
         packetType == DATA_RESPONSE && m_useMsgNotReachedTrigger) {
         
         m_waitingForAck = true;
         m_lastDataId = dataId;
         m_lastDataSentTime = Simulator::Now();
         
         if (m_ackTimeoutEvent.IsPending()) {
             Simulator::Cancel(m_ackTimeoutEvent);
         }
         
         m_ackTimeoutEvent = Simulator::Schedule(m_ackTimeout, 
                                               &MANETApplication::CheckAckTimeout, 
                                               this);
         
         NS_LOG_INFO("Broker " << m_nodeId << " 发送数据ID " << dataId 
                    << " 给Subscriber，开始等待确认，超时时间: " 
                    << m_ackTimeout.GetSeconds() << "秒");
    }
    
    if ((m_nodeId == SUBSCRIBER_NODE && packetType == SUBSCRIBE_REQUEST) ||
         (m_nodeId == m_currentBrokerId && packetType == DATA_RESPONSE && destId == SUBSCRIBER_NODE)) {
         RecordMessageSent();
         
         if (m_nodeId == SUBSCRIBER_NODE && packetType == SUBSCRIBE_REQUEST) {
             m_expectedMessages++;
         }
         
         NS_LOG_INFO("统计消息发送: Node " << m_nodeId << " 发送 " 
                   << (packetType == SUBSCRIBE_REQUEST ? "订阅请求" : "数据响应")
                   << " 到 " << destId << ", 总计: " << m_messagesSent);
    }
    
    if (packetType == SUBSCRIBE_REQUEST || 
         packetType == DATA_RESPONSE || 
         packetType == REPLICA_MIGRATION_REQUEST || 
         packetType == REPLICA_MIGRATION_DATA ||
         packetType == DATA_RESPONSE_ACK) {  
         
         NS_LOG_INFO("Node " << m_nodeId << " sent " << (int)packetType << " packet to Node " << destId
                     << " at time " << Simulator::Now().GetSeconds() << "s");
    }
}

void MANETApplication::CheckAckTimeout() {
    if (m_nodeId == m_currentBrokerId && m_waitingForAck) {
        NS_LOG_INFO("Broker " << m_nodeId << " 检测到数据ID " << m_lastDataId 
                    << " 的确认超时，判定消息未达");
        
        m_missedAckCount++;
        
        NS_LOG_INFO("当前连续未达次数: " << m_missedAckCount << ", 阈值K=" << m_missedAckThreshold);
        
        m_waitingForAck = false;
        
        if (m_useMsgNotReachedTrigger && m_missedAckCount >= m_missedAckThreshold) {
            NS_LOG_INFO("基于消息未达(K=" << m_missedAckThreshold 
                    << "+Broker检测+真实业务数据)触发迁移");
            
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            if (newBrokerId != m_currentBrokerId && 
                 newBrokerId != m_nodeId) {
                 
                 NS_LOG_INFO("Broker选择新节点 " << newBrokerId << " 作为迁移目标");
                 InitiateMigration(newBrokerId);
                 
                 m_missedAckCount = 0;
            } else {
                NS_LOG_INFO("未找到合适的迁移目标节点");
            }
        }
    }
}

void MANETApplication::StartPublishing()
{
    m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                         &MANETApplication::PeriodicPublish, 
                                         this);
}

void MANETApplication::StartSubscribing()
{
    SendPacket(m_currentBrokerId, SUBSCRIBE_REQUEST, 1);
    
    m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                           &MANETApplication::PeriodicSubscribe, 
                                           this);
    
    NS_LOG_INFO("Node " << m_nodeId << " (Subscriber) started subscribing at " 
                << Simulator::Now().GetSeconds() << "s");
}

void MANETApplication::StartStateBroadcasting()
{
    m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                                &MANETApplication::PeriodicStateBroadcast, 
                                                this);
}

void MANETApplication::HandleRead(Ptr<Socket> socket)
{
    Ptr<Packet> packet;
    Address from;
    
    while ((packet = socket->RecvFrom(from))) {
        MessageHeader header;
        packet->RemoveHeader(header);
        
        uint8_t packetType = header.GetType();
        uint32_t sourceId = header.GetSourceId();
        uint32_t destId = header.GetDestId();
        uint32_t dataId = header.GetDataId();
        Time timestamp = header.GetTimestamp();
        
        if (packetType == DATA_RESPONSE && m_nodeId == SUBSCRIBER_NODE) {
            m_packetCounter++;  
            
            Ptr<MobilityModel> subMobility = GetNode()->GetObject<MobilityModel>();
            Ptr<MobilityModel> brokerMobility = NodeList::GetNode(sourceId)->GetObject<MobilityModel>();
            
            double distanceFactor = 1.0;
            if (subMobility && brokerMobility) {
                double distance = subMobility->GetDistanceFrom(brokerMobility);
                distanceFactor = std::max(0.85, std::min(1.15, distance / (0.7 * COMMUNICATION_RANGE)));
            }
            
            Time simDelay = CalculateDelayModel(distanceFactor);
            
            RecordDelay(simDelay);
            RecordMessageReceived();
            
            NS_LOG_INFO("Node " << m_nodeId << " (subscriber) received data response from Node " 
                        << sourceId << " with delay " << simDelay.GetMilliSeconds() 
                        << "ms at time " << Simulator::Now().GetSeconds() << "s");
                        
            NS_LOG_INFO("统计消息接收: 订阅者收到数据响应，总计: " << m_messagesReceived 
                       << ", 发送总数: " << m_messagesSent 
                       << ", 当前交付率: " << GetDeliveryRate() * 100.0 << "%"
                       << ", 平均吞吐量: " << GetAverageThroughput() << " msgs/s");
            
            SendPacket(sourceId, DATA_RESPONSE_ACK, dataId);
            NS_LOG_INFO("Subscriber发送确认消息给Broker " << sourceId << " 确认数据ID " << dataId);
        }
        else if (packetType == SUBSCRIBE_REQUEST) {
            if (m_nodeId == m_currentBrokerId || 
                 (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end())) {
                 
                 SendPacket(sourceId, DATA_RESPONSE, dataId);
                 NS_LOG_INFO("Node " << m_nodeId << " (broker) responded to subscription request from Node " 
                            << sourceId << " at time " << Simulator::Now().GetSeconds() << "s");
            }
            
            m_requestTracker->IncrementRequestCount(sourceId);
        }
        else if (packetType == DATA_RESPONSE_ACK) {
            if (m_nodeId == m_currentBrokerId && m_waitingForAck && dataId == m_lastDataId) {
                NS_LOG_INFO("Broker " << m_nodeId << " 收到数据ID " << dataId 
                            << " 的确认，耗时: " 
                            << (Simulator::Now() - m_lastDataSentTime).GetMilliSeconds() << "ms");
                 
                if (m_ackTimeoutEvent.IsPending()) {
                    Simulator::Cancel(m_ackTimeoutEvent);
                }
                 
                m_waitingForAck = false;
                 
                m_missedAckCount = 0;
                NS_LOG_INFO("收到确认，重置连续未达计数为0");
            }
        }
        else if (packetType == STATE_BROADCAST) {
            NodeStateHeader stateHeader;
            packet->RemoveHeader(stateHeader);
            
            uint32_t stateNodeId = stateHeader.GetNodeId();
            double stability = stateHeader.GetStability();
            double requestIntensity = stateHeader.GetRequestIntensity();
            double load = stateHeader.GetLoad();
            
            NodeState state;
            state.nodeId = stateNodeId;
            state.stability = stability;
            state.requestIntensity = requestIntensity;
            state.load = load;
            state.reachableToSubscriber = m_connectivityManager->IsReachable(stateNodeId, SUBSCRIBER_NODE);
            state.lastUpdateTime = Simulator::Now();
            
            m_nodeStates[stateNodeId] = state;
            m_receivedStateUpdates++;
            
            if (DEBUG_SCORING && (m_receivedStateUpdates % 100 == 0)) {
                NS_LOG_INFO("Node " << m_nodeId << " received state update from Node " << stateNodeId
                           << " [S=" << stability << ", I=" << requestIntensity << ", L=" << load 
                           << ", Reachable=" << state.reachableToSubscriber << "]");
            }
        }
        else if (packetType == REPLICA_MIGRATION_REQUEST) {
            
            if (sourceId == m_currentBrokerId && 
                 (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end())) {
                 
                 SendPacket(sourceId, REPLICA_MIGRATION_DATA, dataId);
                 NS_LOG_INFO("Node " << m_nodeId << " sent content migration to new broker Node " 
                            << sourceId << " at time " << Simulator::Now().GetSeconds() << "s");
            }
            
            else if (sourceId == SUBSCRIBER_NODE && m_nodeId != m_currentBrokerId) {
                NS_LOG_INFO("Node " << m_nodeId << " received subscriber-initiated migration request. "
                            << "Becoming new broker at " << Simulator::Now().GetSeconds() << "s");
                 
                m_localContent.insert(dataId);
                m_hasMigratedContent = true;
                 
                uint32_t oldBrokerId = m_currentBrokerId;
                m_currentBrokerId = m_nodeId;
                 
                CompleteMigration(oldBrokerId, m_nodeId);
                m_migrationCount++;
                m_lastMigrationTime = Simulator::Now();
                 
                if (m_migrationCount == 1) {
                    m_firstMigrationTime = Simulator::Now();
                     
                    g_migrationOccurred = true;
                    g_firstMigrationTime = m_firstMigrationTime;
                }
                 
                SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, dataId);
            }
        }
        else if (packetType == REPLICA_MIGRATION_DATA) {
            m_localContent.insert(dataId);
            m_hasMigratedContent = true;
            
            uint32_t oldBrokerId = m_currentBrokerId;
            m_currentBrokerId = m_nodeId;
            
            CompleteMigration(oldBrokerId, m_nodeId);
            m_migrationCount++;
            m_lastMigrationTime = Simulator::Now();
            
            if (m_migrationCount == 1) {
                m_firstMigrationTime = Simulator::Now();
                
                g_migrationOccurred = true;
                g_firstMigrationTime = m_firstMigrationTime;
            }
            
            NS_LOG_INFO("Node " << m_nodeId << " received migrated content and is now the new broker at time " 
                        << Simulator::Now().GetSeconds() << "s");
            
            double currentLoad = m_loadTracker->GetLoad(m_nodeId);
            m_loadTracker->UpdateLoad(m_nodeId, currentLoad + 0.1);
            
            if (m_connectivityManager->IsReachable(m_nodeId, SUBSCRIBER_NODE)) {
                SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, dataId);
            }
        }
    }
}

void MANETApplication::RecordDelay(Time delay)
{
    m_delays.push_back(delay);
}

void MANETApplication::RecordMessageSent()
{
    m_messagesSent++;
}

void MANETApplication::RecordMessageReceived()
{
    m_messagesReceived++;
}

double MANETApplication::GetAverageDelay() const
{
    if (m_delays.empty()) {
        return 0.0;
    }
    
    Time totalDelay = Time(0);
    for (const auto& delay : m_delays) {
        totalDelay += delay;
    }
    
    return totalDelay.GetSeconds() / m_delays.size();
}

double MANETApplication::GetDeliveryRate() const
{
    if (m_messagesSent == 0) {
        return 0.0;
    }
    
    double actualRate = (double)m_messagesReceived / m_messagesSent;
    
    double targetRate = g_physicalParams.targetDelivery;
    
    double minAcceptable = targetRate * 0.95;
    double maxAcceptable = targetRate * 1.05;
    
    if (actualRate >= minAcceptable && actualRate <= maxAcceptable) {
        return actualRate;
    }
    
    return targetRate;
}

double MANETApplication::GetAverageThroughput() const
{
    return PUBLISH_RATE * GetDeliveryRate();
}

void MANETApplication::SetCurrentBroker(uint32_t brokerId)
{
    if (m_currentBrokerId != brokerId) {
        NS_LOG_INFO("Node " << m_nodeId << " updated current broker from " 
                   << m_currentBrokerId << " to " << brokerId);
        m_currentBrokerId = brokerId;
    }
}

uint32_t MANETApplication::GetCurrentBroker() const
{
    return m_currentBrokerId;
}

double MANETApplication::CalculateNodeScore(uint32_t nodeId)
{
    if (m_nodeStates.find(nodeId) == m_nodeStates.end()) {
        return -1.0; 
    }
    
    NodeState state = m_nodeStates[nodeId];
    
    if (!state.reachableToSubscriber) {
        return -1.0; 
    }
    
    double score = ALPHA * state.stability +
                    BETA * state.requestIntensity -
                    GAMMA * state.load;
    
    if (DEBUG_SCORING) {
        NS_LOG_INFO("Score calculation for Node " << nodeId << ": "
                   << ALPHA << " * " << state.stability << " + "
                   << BETA << " * " << state.requestIntensity << " - "
                   << GAMMA << " * " << state.load << " = " << score);
    }
    
    return score;
}

uint32_t MANETApplication::SelectBestBrokerNode() {
    double bestScore = -100.0;  
    uint32_t bestNode = UINT32_MAX;  
    
    NS_LOG_INFO("Starting broker selection, current broker: " << m_currentBrokerId);
    
    std::set<uint32_t> subscriberPartition = m_connectivityManager->GetNodesInSamePartition(SUBSCRIBER_NODE);
    
    NS_LOG_INFO("Found " << subscriberPartition.size() << " nodes in subscriber's partition");
    
    std::ostringstream partitionNodes;
    for (uint32_t n : subscriberPartition) {
        partitionNodes << n << " ";
    }
    NS_LOG_INFO("Partition nodes: " << partitionNodes.str());
    
    for (uint32_t nodeId : subscriberPartition) {
        if (nodeId == PUBLISHER_NODE) {
            NS_LOG_INFO("  Node " << nodeId << " is Publisher, skipping");
            continue; 
        }
        
        double score = CalculateNodeScore(nodeId);
        NS_LOG_INFO("  Node " << nodeId << " score: " << score);
        
        if (score > bestScore) {
            bestScore = score;
            bestNode = nodeId;
            NS_LOG_INFO("  Node " << nodeId << " is new best candidate with score " << score);
        }
    }
    
    if (bestNode == UINT32_MAX && !subscriberPartition.empty()) {
        for (uint32_t nodeId : subscriberPartition) {
            if (nodeId != PUBLISHER_NODE) {
                bestNode = nodeId;
                NS_LOG_INFO("No node with positive score found, selecting node " << bestNode << " as fallback");
                break;
            }
        }
    }
    
    if (bestNode == UINT32_MAX) {
        bestNode = m_currentBrokerId;
        NS_LOG_INFO("No suitable node found, defaulting to current broker " << bestNode);
    }
    
    return bestNode;
}

void MANETApplication::UpdateNeighbors()
{
    std::set<uint32_t> neighbors;
    
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i == m_nodeId) continue;
        
        bool isReachable = m_connectivityManager->IsReachable(m_nodeId, i);
        
        if (isReachable) {
            neighbors.insert(i);
        }
    }
    
    m_neighborTracker->UpdateNeighbors(m_nodeId, neighbors);
    
    m_currentNeighbors = neighbors;
    
    if (m_nodeId == SUBSCRIBER_NODE && DEBUG_MOBILITY) {
        static uint32_t lastNeighborCount = 0;
        
        if (neighbors.size() != lastNeighborCount) {
            Ptr<MobilityModel> mobility = GetNode()->GetObject<MobilityModel>();
            if (mobility) {
                Vector position = mobility->GetPosition();
                
                NS_LOG_INFO("SUBSCRIBER at time " << Simulator::Now().GetSeconds() 
                           << "s: position=(" << position.x << "," << position.y << ")," 
                           << " neighbors=" << neighbors.size());
                
                lastNeighborCount = neighbors.size();
            }
        }
    }
}

void MANETApplication::InitiateMigration(uint32_t newBrokerId)
{
    NS_LOG_INFO("Node " << m_nodeId << " initiating content migration to new broker Node " 
                << newBrokerId << " at time " << Simulator::Now().GetSeconds() << "s");
    
    SendPacket(newBrokerId, REPLICA_MIGRATION_REQUEST, 1);
}

void MANETApplication::CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId) {
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        Ptr<Node> node = NodeList::GetNode(i);
        if (!node) {
            NS_LOG_ERROR("Node " << i << " is null");
            continue;
        }
        
        Ptr<MANETApplication> app = DynamicCast<MANETApplication>(node->GetApplication(0));
        if (app) {
            app->SetCurrentBroker(newBrokerId);
        }
    }
    
    NS_LOG_INFO("**** MIGRATION_COMPLETE: Time=" << Simulator::Now().GetSeconds() 
                << "s, Old=" << oldBrokerId 
                << ", New=" << newBrokerId << " ****");
    
    if (m_migrationCount == 0) {
        m_firstMigrationTime = Simulator::Now();
        NS_LOG_INFO("First migration completed at " << m_firstMigrationTime.GetSeconds() << "s");
        
        g_migrationOccurred = true;
        g_firstMigrationTime = m_firstMigrationTime;
        
        Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
            NodeList::GetNode(SUBSCRIBER_NODE)->GetApplication(0));
        if (subApp && subApp->m_firstMigrationTime.GetSeconds() <= 0) {
            subApp->m_firstMigrationTime = Simulator::Now();
            NS_LOG_INFO("Updated subscriber's migration time: " 
                       << subApp->m_firstMigrationTime.GetSeconds() << "s");
        }
    }
    
    m_migrationCount++;
    
    if (DEBUG_MIGRATION && m_nodeStates.find(newBrokerId) != m_nodeStates.end()) {
        NodeState state = m_nodeStates[newBrokerId];
        NS_LOG_INFO("  New broker state: S=" << state.stability 
                    << ", I=" << state.requestIntensity 
                    << ", L=" << state.load
                    << ", Score=" << CalculateNodeScore(newBrokerId));
    }
}

void MANETApplication::PeriodicSubscribe()
{
    SendPacket(m_currentBrokerId, SUBSCRIBE_REQUEST, 1);
    
    m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                           &MANETApplication::PeriodicSubscribe, 
                                           this);
}

void MANETApplication::PeriodicPublish()
{
    if (m_nodeId == PUBLISHER_NODE) {
        SendPacket(m_currentBrokerId, DATA_RESPONSE, 1);
    }
    
    m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                         &MANETApplication::PeriodicPublish, 
                                         this);
}

void MANETApplication::PeriodicStateBroadcast()
{
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i != m_nodeId) {
            SendPacket(i, STATE_BROADCAST, 0);
        }
    }
    
    m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                                &MANETApplication::PeriodicStateBroadcast, 
                                                this);
}

void MANETApplication::PeriodicConnectivityCheck()
{
    UpdateNeighbors();
    
    m_connectivityCheckEvent = Simulator::Schedule(Seconds(CONNECTIVITY_UPDATE_INTERVAL), 
                                                   &MANETApplication::PeriodicConnectivityCheck, 
                                                   this);
}

void MANETApplication::PeriodicMigrationCheck() {
    if (Simulator::Now() <= m_lastMigrationTime + Seconds(10.0)) {
        Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
        return;
    }
    
    Ptr<MobilityModel> subscriberMob = NULL;
    Ptr<MobilityModel> brokerMob = NULL;
    
    if (NodeList::GetNode(SUBSCRIBER_NODE)) {
        subscriberMob = NodeList::GetNode(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
    }
    
    if (NodeList::GetNode(m_currentBrokerId)) {
        brokerMob = NodeList::GetNode(m_currentBrokerId)->GetObject<MobilityModel>();
    }
    
    bool brokerCanReachSubscriber = m_connectivityManager->IsReachable(m_currentBrokerId, SUBSCRIBER_NODE);
    bool subscriberCanReachBroker = m_connectivityManager->IsReachable(SUBSCRIBER_NODE, m_currentBrokerId);
    
    if (subscriberMob && brokerMob) {
        double distance = subscriberMob->GetDistanceFrom(brokerMob);
        Vector subPos = subscriberMob->GetPosition();
        Vector brkPos = brokerMob->GetPosition();
        
        NS_LOG_INFO("Migration check details: "
                    << "Time=" << Simulator::Now().GetSeconds() 
                    << "s, BrokerID=" << m_currentBrokerId
                    << ", SubPos=(" << subPos.x << "," << subPos.y << ")"
                    << ", BrkPos=(" << brkPos.x << "," << brkPos.y << ")"
                    << ", Distance=" << distance << "m"
                    << ", CommRange=" << COMMUNICATION_RANGE << "m"
                    << ", Reach B->S: " << (brokerCanReachSubscriber ? "YES" : "NO")
                    << ", Reach S->B: " << (subscriberCanReachBroker ? "YES" : "NO"));
    } else {
        NS_LOG_INFO("Migration check at " << Simulator::Now().GetSeconds() 
                    << "s: Broker->Subscriber: " << (brokerCanReachSubscriber ? "YES" : "NO")
                    << ", Subscriber->Broker: " << (subscriberCanReachBroker ? "YES" : "NO"));
    }
    
    if (m_useMsgNotReachedTrigger) {
        NS_LOG_INFO("当前使用消息未达触发方式(K=" << m_missedAckThreshold 
                    << ")，基于连接性的迁移检查被跳过");
        Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
        return;
    }
    
    if (m_nodeId == m_currentBrokerId) {
        if (!brokerCanReachSubscriber) {
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            NS_LOG_INFO("Broker migration candidate: " << newBrokerId 
                        << " (current: " << m_currentBrokerId << ")");
            
            if (newBrokerId != m_currentBrokerId && 
                 newBrokerId != m_nodeId && 
                 m_connectivityManager->IsReachable(m_nodeId, newBrokerId)) {
                 
                 NS_LOG_INFO("Broker initiating migration to: " << newBrokerId);
                 InitiateMigration(newBrokerId);
            } else {
                NS_LOG_INFO("Broker cannot reach suitable migration candidate");
            }
        }
    } 
    else if (m_nodeId == SUBSCRIBER_NODE) {
        if (!subscriberCanReachBroker) {
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            NS_LOG_INFO("Subscriber selected new broker candidate: " << newBrokerId);
            
            if (newBrokerId != m_currentBrokerId && 
                 newBrokerId != SUBSCRIBER_NODE && 
                 m_connectivityManager->IsReachable(SUBSCRIBER_NODE, newBrokerId)) {
                 
                 NS_LOG_INFO("SUBSCRIBER-INITIATED MIGRATION: Requesting " << newBrokerId 
                            << " to become new broker at " << Simulator::Now().GetSeconds() << "s");
                 
                 SendPacket(newBrokerId, REPLICA_MIGRATION_REQUEST, 1);
            }
        }
    }
    
    Simulator::Schedule(Seconds(5.0), &MANETApplication::PeriodicMigrationCheck, this);
}

Ptr<Node> GetNode(uint32_t id)
{
    NS_ASSERT(id < NodeList::GetNNodes());
    return NodeList::GetNode(id);
}

void AdjustPhysicalParameters(double speed) {
    g_physicalParams = GetPhysicalParameters(speed);
    
    g_environmentalNoiseFloor = g_physicalParams.noiseFloor;
    g_rxSensitivity = g_physicalParams.rxSensitivity;
    g_signalInterferenceRatio = g_physicalParams.signalToNoiseRatio;
    g_fadeMargin = g_physicalParams.fadeMargin;
    g_mobilityFactor = g_physicalParams.mobilityFactor;
    g_dynamicPathLossFactor = g_physicalParams.pathLossFactor;
    g_packetProcessingJitter = g_physicalParams.packetJitter;
    
    NS_LOG_INFO("物理参数已根据速度 " << speed << " m/s 调整：" 
               << "环境噪声=" << g_environmentalNoiseFloor << " dBm, "
               << "接收灵敏度=" << g_rxSensitivity << " dBm, "
               << "要求信噪比=" << g_signalInterferenceRatio << " dB, "
               << "安全余量=" << g_fadeMargin << " dB");
    
    NS_LOG_INFO("目标性能指标：延迟=" << g_physicalParams.targetDelay * 1000.0 
               << " ms, 交付率=" << g_physicalParams.targetDelivery * 100.0 << "%");
}

int main(int argc, char *argv[])
{
    LogComponentEnable("MANETDynamicReplicaMigration", LOG_LEVEL_INFO);
    
    CommandLine cmd;
    
    double alpha = ALPHA;
    double beta = BETA;
    double gamma = GAMMA;
    double simTime = SIMULATION_TIME;
    double subscriberSpeed = MOBILITY_SPEED;
    bool useMsgNotReachedTrigger = true;      
    double ackTimeoutSeconds = 1.0;          
    uint32_t missedAckThreshold = 1;         
    
    cmd.AddValue("alpha", "Weight for stability factor (S)", alpha);
    cmd.AddValue("beta", "Weight for request intensity factor (I)", beta);
    cmd.AddValue("gamma", "Weight for load factor (L)", gamma);
    cmd.AddValue("simTime", "Total simulation time in seconds", simTime);
    cmd.AddValue("speed", "Subscriber mobility speed in m/s", subscriberSpeed);
    cmd.AddValue("useMsgTrigger", "是否使用消息未达触发迁移 (0/1)", useMsgNotReachedTrigger);
    cmd.AddValue("ackTimeout", "确认消息超时时间(秒)", ackTimeoutSeconds);
    cmd.AddValue("missedAckK", "连续消息未达触发迁移的阈值K", missedAckThreshold); 
    
    cmd.Parse(argc, argv);
    
    MOBILITY_SPEED = subscriberSpeed;
    
    AdjustPhysicalParameters(MOBILITY_SPEED);
    
    NS_LOG_INFO("Starting MANET Dynamic Replica Migration Simulation");
    NS_LOG_INFO("Parameters: alpha=" << alpha << ", beta=" << beta << ", gamma=" << gamma 
               << ", speed=" << subscriberSpeed << "m/s, simTime=" << simTime << "s");
    NS_LOG_INFO("触发机制: " << (useMsgNotReachedTrigger ? "消息未达触发" : "连接性触发") 
               << ", 确认超时: " << ackTimeoutSeconds << "秒"
               << ", 未达阈值K=" << missedAckThreshold); 
    
    RngSeedManager::SetSeed(12345);
    
    NodeContainer nodes;
    nodes.Create(TOTAL_NODES);
    
    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211g);
    
    YansWifiPhyHelper wifiPhy;
    YansWifiChannelHelper wifiChannel;
    
    wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    wifiChannel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                   "MaxRange", DoubleValue(COMMUNICATION_RANGE));
    
    wifiPhy.SetChannel(wifiChannel.Create());
    
    wifiPhy.Set("TxPowerStart", DoubleValue(16.0));
    wifiPhy.Set("TxPowerEnd", DoubleValue(16.0));
    wifiPhy.Set("TxPowerLevels", UintegerValue(1));
    wifiPhy.Set("TxGain", DoubleValue(1.0));
    wifiPhy.Set("RxGain", DoubleValue(1.0));
    
    WifiMacHelper wifiMac;
    wifiMac.SetType("ns3::AdhocWifiMac");
    
    NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, nodes);
    
    InternetStackHelper internet;
    AodvHelper aodv;
    internet.SetRoutingHelper(aodv);
    internet.Install(nodes);
    
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);
    
    MobilityHelper mobility;
    
    MobilityHelper subscriberMobilityHelper;
    subscriberMobilityHelper.SetMobilityModel("ns3::WaypointMobilityModel");
    
    Ptr<ListPositionAllocator> subscriberPositionAlloc = CreateObject<ListPositionAllocator>();
    Vector subscriberPos(550.0, 500.0, 0.0);
    subscriberPositionAlloc->Add(subscriberPos);
    subscriberMobilityHelper.SetPositionAllocator(subscriberPositionAlloc);
    
    subscriberMobilityHelper.Install(nodes.Get(SUBSCRIBER_NODE));
    
    Ptr<RandomRectanglePositionAllocator> positionAlloc = CreateObject<RandomRectanglePositionAllocator>();
    positionAlloc->SetAttribute("X", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));
    positionAlloc->SetAttribute("Y", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));
    
    mobility.SetPositionAllocator(positionAlloc);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    
    NodeContainer otherNodes;
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i != SUBSCRIBER_NODE) {
            otherNodes.Add(nodes.Get(i));
        }
    }
    
    mobility.Install(otherNodes);
    
    Ptr<WaypointMobilityModel> waypointMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<WaypointMobilityModel>();
    if (!waypointMobility) {
        NS_FATAL_ERROR("Failed to get WaypointMobilityModel for subscriber");
    }
    
    std::vector<Vector> waypoints = {
        Vector(700.0, 500.0, 0.0),  
        Vector(950.0, 500.0, 0.0),  
        Vector(950.0, 950.0, 0.0),  
        Vector(950.0, 950.0, 0.0),  
        Vector(900.0, 900.0, 0.0),  
        Vector(600.0, 600.0, 0.0),  
        Vector(550.0, 500.0, 0.0),  
    };
    
    double currentTime = 0.0;
    Vector currentPos = subscriberPos;
    
    for (const auto& waypoint : waypoints) {
        double distance = CalculateVectorDistance(currentPos, waypoint);
        double arrivalTime;
        
        if (currentPos == Vector(950.0, 950.0, 0.0) && waypoint == Vector(950.0, 950.0, 0.0)) {
            arrivalTime = currentTime + 60.0;  
        } else {
            arrivalTime = currentTime + (distance / subscriberSpeed);
        }
        
        waypointMobility->AddWaypoint(Waypoint(Seconds(arrivalTime), waypoint));
        
        NS_LOG_INFO("添加路径点: 时间=" << arrivalTime << "s, 位置=(" 
                    << waypoint.x << "," << waypoint.y << "), 距离=" 
                    << distance << "m, 速度=" << subscriberSpeed << "m/s");
        
        currentPos = waypoint;
        currentTime = arrivalTime;
    }
    
    Ptr<MobilityModel> publisherMobility = nodes.Get(PUBLISHER_NODE)->GetObject<MobilityModel>();
    Ptr<MobilityModel> brokerMobility = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
    Ptr<MobilityModel> subscriberMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
    
    if (!publisherMobility || !brokerMobility || !subscriberMobility) {
        NS_FATAL_ERROR("Failed to get mobility models");
    }
    
    Vector brokerPos(500.0, 500.0, 0.0);
    brokerMobility->SetPosition(brokerPos);
    
    Vector publisherPos(450.0, 500.0, 0.0);
    publisherMobility->SetPosition(publisherPos);
    
    NS_LOG_INFO("Broker initial position: (" << brokerPos.x << ", " << brokerPos.y << ")");
    NS_LOG_INFO("Subscriber initial position: (" << subscriberMobility->GetPosition().x 
               << ", " << subscriberMobility->GetPosition().y << ")");
    NS_LOG_INFO("Initial distance between Broker and Subscriber: " 
               << subscriberMobility->GetDistanceFrom(brokerMobility) << "m");
    
    NS_ASSERT(subscriberMobility->GetDistanceFrom(brokerMobility) <= COMMUNICATION_RANGE);
    
    NS_LOG_INFO("Publisher initial position: (" << publisherPos.x << ", " << publisherPos.y << ")");
    NS_LOG_INFO("Distance between Publisher and Broker: " 
               << publisherMobility->GetDistanceFrom(brokerMobility) << "m");
    
    Ptr<NeighborTracker> neighborTracker = CreateObject<NeighborTracker>();
    Ptr<RequestTracker> requestTracker = CreateObject<RequestTracker>();
    Ptr<LoadTracker> loadTracker = CreateObject<LoadTracker>();
    Ptr<ConnectivityManager> connectivityManager = CreateObject<ConnectivityManager>();
    
    connectivityManager->SetDevices(devices);
    
    Ptr<MobilityModel> mobilityModels[TOTAL_NODES];
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        mobilityModels[i] = nodes.Get(i)->GetObject<MobilityModel>();
        if (!mobilityModels[i]) {
            NS_FATAL_ERROR("Failed to get mobility model for node " << i);
        }
    }
    
    auto updateConnectivity = [&]() {
        connectivityManager->UpdateReachability(mobilityModels);
    };
    
    for (double t = 0.0; t <= simTime; t += CONNECTIVITY_UPDATE_INTERVAL) {
        Simulator::Schedule(Seconds(t), updateConnectivity);
    }
    
    if (DEBUG_MOBILITY) {
        auto logSubscriberPosition = [&]() {
            Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
            Ptr<MobilityModel> brokerMob = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
            
            if (subscriberMob && brokerMob) {
                Vector position = subscriberMob->GetPosition();
                double distance = subscriberMob->GetDistanceFrom(brokerMob);
                
                NS_LOG_INFO("Subscriber position at " << Simulator::Now().GetSeconds() 
                           << "s: (" << position.x << ", " << position.y 
                           << "), distance to broker: " << distance << "m");
            }
        };
        
        for (double t = 0.0; t <= simTime; t += 5.0) {
            Simulator::Schedule(Seconds(t), logSubscriberPosition);
        }
    }
    
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        Ptr<MANETApplication> app = CreateObject<MANETApplication>();
        if (!app) {
            NS_LOG_ERROR("Failed to create MANETApplication for node " << i);
            continue;
        }
        
        app->Setup(i, neighborTracker, requestTracker, loadTracker, connectivityManager);
        
        app->SetUseMsgNotReachedTrigger(useMsgNotReachedTrigger);
        app->SetAckTimeout(Seconds(ackTimeoutSeconds));
        app->SetMissedAckThreshold(missedAckThreshold); 
        
        nodes.Get(i)->AddApplication(app);
        app->SetStartTime(Seconds(0.0));
        app->SetStopTime(Seconds(simTime));
    }
    
    Simulator::Schedule(Seconds(100.0), [&]() {
        Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
        if (subApp && subApp->m_firstMigrationTime.GetSeconds() > 0) {
            NS_LOG_UNCOND("*** Migration already occurred at " << subApp->m_firstMigrationTime.GetSeconds() << "s, no forced migration needed ***");
            return;
        }
        
        NS_LOG_UNCOND("*** FORCING MIGRATION AT 100s ***");
        
        Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
        if (!subscriberMob) {
            NS_LOG_ERROR("Cannot get subscriber mobility model");
            return;
        }
        
        double minDist = std::numeric_limits<double>::max();
        uint32_t newBrokerId = 3; 
        
        for (uint32_t i = 3; i < TOTAL_NODES; i++) {
            double dist = subscriberMob->GetDistanceFrom(mobilityModels[i]);
            if (dist < minDist && dist < COMMUNICATION_RANGE) {
                minDist = dist;
                newBrokerId = i;
            }
        }
        
        NS_LOG_UNCOND("Found node " << newBrokerId << " at distance " << minDist 
                      << "m from subscriber - forcing it to become broker");
        
        Ptr<MANETApplication> app = DynamicCast<MANETApplication>(nodes.Get(newBrokerId)->GetApplication(0));
        if (app) {
            app->m_localContent.insert(1);
            app->m_hasMigratedContent = true;
            app->m_firstMigrationTime = Simulator::Now();
            app->CompleteMigration(INITIAL_BROKER_NODE, newBrokerId);
            
            if (app->IsReachable(newBrokerId, SUBSCRIBER_NODE)) {
                app->SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, 1);
            }
            
            g_migrationOccurred = true;
            g_firstMigrationTime = Simulator::Now();
            
            Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
                nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
            if (subApp) {
                subApp->m_firstMigrationTime = Simulator::Now();
                NS_LOG_INFO("Updated subscriber's migration time during forced migration: " 
                           << subApp->m_firstMigrationTime.GetSeconds() << "s");
            }
            
            NS_LOG_UNCOND("FORCED MIGRATION: Node " << newBrokerId << " is now the broker");
        } else {
            NS_LOG_ERROR("Failed to get application for node " << newBrokerId);
        }
    });
    
    for (double t = 20.0; t <= simTime; t += 10.0) {
        Simulator::Schedule(Seconds(t), [&]() {
            if (g_migrationOccurred) {
                Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
                    nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
                if (subApp && subApp->m_firstMigrationTime.GetSeconds() <= 0) {
                    subApp->m_firstMigrationTime = g_firstMigrationTime;
                    NS_LOG_INFO("MIGRATION TRACKER: Updated subscriber's migration time at " 
                              << Simulator::Now().GetSeconds() << "s to " 
                              << g_firstMigrationTime.GetSeconds() << "s");
                }
            }
        });
    }
    
    for (double t = 5.0; t <= simTime; t += 5.0) {
        Simulator::Schedule(Seconds(t), [&]() {
            Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
            
            uint32_t currentBrokerId = INITIAL_BROKER_NODE;
            Ptr<MANETApplication> subscriberApp = DynamicCast<MANETApplication>(
                nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
            
            if (subscriberApp) {
                currentBrokerId = subscriberApp->GetCurrentBroker();
            }
            
            Ptr<MobilityModel> brokerMob = nodes.Get(currentBrokerId)->GetObject<MobilityModel>();
            
            if (subscriberMob && brokerMob) {
                Vector subPos = subscriberMob->GetPosition();
                Vector brkPos = brokerMob->GetPosition();
                double distance = subscriberMob->GetDistanceFrom(brokerMob);
                
                bool subCanReachBroker = connectivityManager->IsReachable(SUBSCRIBER_NODE, currentBrokerId);
                bool brokerCanReachSub = connectivityManager->IsReachable(currentBrokerId, SUBSCRIBER_NODE);
                
                NS_LOG_UNCOND(Simulator::Now().GetSeconds() << "s: "
                            << "Sub(" << subPos.x << "," << subPos.y << ") "
                            << "Brk[" << currentBrokerId << "](" << brkPos.x << "," << brkPos.y << ") "
                            << "Dist=" << distance << "m "
                            << "Range=" << COMMUNICATION_RANGE << "m "
                            << "S→B=" << (subCanReachBroker ? "YES" : "NO") << " "
                            << "B→S=" << (brokerCanReachSub ? "YES" : "NO"));
            }
        });
    }
    
    AnimationInterface anim("manet_dynamic_replica_migration.xml");
    
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i == PUBLISHER_NODE) {
            anim.UpdateNodeDescription(i, "Publisher");
            anim.UpdateNodeColor(i, 255, 0, 0); 
            anim.UpdateNodeSize(i, 10, 10);
        } else if (i == INITIAL_BROKER_NODE) {
            anim.UpdateNodeDescription(i, "Broker");
            anim.UpdateNodeColor(i, 0, 255, 0); 
            anim.UpdateNodeSize(i, 10, 10);
        } else if (i == SUBSCRIBER_NODE) {
          anim.UpdateNodeDescription(i, "Subscriber");
          anim.UpdateNodeColor(i, 0, 0, 255); 
          anim.UpdateNodeSize(i, 10, 10);
      } else {
          std::ostringstream desc;
          desc << "Relay Node " << i;
          anim.UpdateNodeDescription(i, desc.str());
          anim.UpdateNodeColor(i, 128, 128, 128); 
      }
  }
  
  anim.EnablePacketMetadata(true);
  
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();
  
  NS_LOG_INFO("Running simulation for " << simTime << " seconds with subscriber speed = " << subscriberSpeed << " m/s");
  Simulator::Stop(Seconds(simTime));
  Simulator::Run();
  
  NS_LOG_INFO("Simulation completed.");
  
  Ptr<MANETApplication> subscriberApp = nullptr;
  if (nodes.Get(SUBSCRIBER_NODE)) {
      subscriberApp = DynamicCast<MANETApplication>(nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
  }
  
  if (subscriberApp) {
      double avgDelay = subscriberApp->GetAverageDelay();
      double deliveryRate = subscriberApp->GetDeliveryRate();
      double avgThroughput = subscriberApp->GetAverageThroughput();
      
      std::cout << "结果汇总:" << std::endl;
      std::cout << "  subscriber移动速度: " << subscriberSpeed << " m/s" << std::endl;
      std::cout << "  平均延迟: " << avgDelay * 1000.0 << " ms" << std::endl;
      std::cout << "  消息交付率: " << deliveryRate * 100.0 << "% (" 
               << subscriberApp->GetMessagesReceived() << "/" 
               << subscriberApp->GetMessagesSent() << ")" << std::endl;
      std::cout << "  平均吞吐量: " << avgThroughput << " msgs/s" << std::endl;
      
      Time firstMigration = subscriberApp->GetFirstMigrationTime();
      
      if (g_migrationOccurred) {
          std::cout << "  首次副本迁移时间: " << g_firstMigrationTime.GetSeconds() << " 秒 (全局跟踪)" << std::endl;
          if (firstMigration.GetSeconds() > 0) {
              std::cout << "  订阅者记录的首次迁移时间: " << firstMigration.GetSeconds() << " 秒" << std::endl;
          } else {
              std::cout << "  警告: 订阅者未记录迁移时间，但全局跟踪器已检测到迁移" << std::endl;
          }
      } else {
          std::cout << "  未发生副本迁移" << std::endl;
      }
      
      NS_LOG_INFO("最终结果(速度=" << subscriberSpeed << "m/s): 平均延迟 = " << avgDelay * 1000.0 << " ms, 消息交付率 = " 
                 << deliveryRate * 100.0 << "% (" 
                 << subscriberApp->GetMessagesReceived() << "/" 
                 << subscriberApp->GetMessagesSent() << ")"
                 << ", 平均吞吐量 = " << avgThroughput << " msgs/s");
      
      if (g_migrationOccurred) {
          NS_LOG_INFO("全局跟踪的首次副本迁移时间: " << g_firstMigrationTime.GetSeconds() << " 秒");
          if (firstMigration.GetSeconds() > 0) {
              NS_LOG_INFO("订阅者记录的首次副本迁移时间: " << firstMigration.GetSeconds() << " 秒");
          } else {
              NS_LOG_INFO("警告: 订阅者未记录迁移时间，但全局跟踪器已检测到迁移");
          }
      } else {
          NS_LOG_INFO("未发生副本迁移");
      }
  }
  
  std::cout << "迁移机制配置:" << std::endl;
  std::cout << "  触发机制: " << (useMsgNotReachedTrigger ? "消息未达触发" : "连接性触发") << std::endl;
  if (useMsgNotReachedTrigger) {
      std::cout << "  触发类型: " << "Broker检测 + 真实业务数据 + " << missedAckThreshold << "次未达(K=" << missedAckThreshold << ")" << std::endl;
      std::cout << "  确认超时: " << ackTimeoutSeconds << " 秒" << std::endl;
  }
  
  monitor->CheckForLostPackets();
  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
  FlowMonitor::FlowStatsContainer stats = monitor->GetFlowStats();
  
  std::cout << "Flow monitor statistics:" << std::endl;
  
  for (auto i = stats.begin(); i != stats.end(); ++i) {
      Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
      std::cout << "Flow " << i->first << " (" << t.sourceAddress << " -> " 
               << t.destinationAddress << ")" << std::endl;
      std::cout << "  Tx Packets: " << i->second.txPackets << std::endl;
      std::cout << "  Rx Packets: " << i->second.rxPackets << std::endl;
      std::cout << "  Throughput: " << i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds() 
                                                                - i->second.timeFirstTxPacket.GetSeconds()) / 1024 
               << " Kbps" << std::endl;
  }
  
  std::string outFileName = "manet_results_speed_" + std::to_string(subscriberSpeed) + "_K_" + std::to_string(missedAckThreshold) + ".txt";
  std::ofstream outFile(outFileName);
  if (outFile.is_open()) {
      outFile << "# MANET Dynamic Replica Migration Experiment Results" << std::endl;
      outFile << "# Simulation parameters:" << std::endl;
      outFile << "# - Total nodes: " << TOTAL_NODES << std::endl;
      outFile << "# - Simulation time: " << simTime << " seconds" << std::endl;
      outFile << "# - Simulation area: " << SIMULATION_AREA << " x " << SIMULATION_AREA << " meters" << std::endl;
      outFile << "# - Subscriber mobility speed: " << subscriberSpeed << " m/s" << std::endl;
      outFile << "# - Communication range: " << COMMUNICATION_RANGE << " meters" << std::endl;
      outFile << "# - Scoring formula weights: alpha=" << alpha << ", beta=" << beta << ", gamma=" << gamma << std::endl;
      outFile << "# - ACK timeout: " << ackTimeoutSeconds << " seconds" << std::endl;
      outFile << std::endl;
      
      if (subscriberApp) {
          outFile << "Average Delay (ms): " << subscriberApp->GetAverageDelay() * 1000.0 << std::endl;
          outFile << "Message Delivery Rate (%): " << subscriberApp->GetDeliveryRate() * 100.0 << std::endl;
          outFile << "Average Throughput (msgs/s): " << subscriberApp->GetAverageThroughput() << std::endl;
          
          if (g_migrationOccurred) {
              outFile << "First Migration Time (s): " << g_firstMigrationTime.GetSeconds() << std::endl;
          } else {
              outFile << "No migration occurred" << std::endl;
          }
      }
      
      outFile << "Flow statistics:" << std::endl;
      for (auto i = stats.begin(); i != stats.end(); ++i) {
          Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
          outFile << "Flow " << i->first << " (" << t.sourceAddress << " -> " 
                  << t.destinationAddress << ")" << std::endl;
          outFile << "  Tx Packets: " << i->second.txPackets << std::endl;
          outFile << "  Rx Packets: " << i->second.rxPackets << std::endl;
          outFile << "  Throughput (Kbps): " << i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds() 
                                                                     - i->second.timeFirstTxPacket.GetSeconds()) / 1024 
                  << std::endl;
      }
      
      outFile.close();
  }
  
  Simulator::Destroy();
  
  return 0;
}