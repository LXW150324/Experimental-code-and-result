// File: improved-aodv-broker-migration.cc
// AODV-based broker migration notification implementation for NS-3.44
// This modified version implements a fair comparison with NDN by:
// 1. Making only the subscriber mobile (publisher and others static)
// 2. Properly handling notification mechanisms with correct delay statistics
// 3. Ensuring mobility speed affects topology changes correctly
// 4. Accurately modeling AODV routing overhead and delays

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/internet-module.h"
#include "ns3/aodv-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/netanim-module.h"
#include "ns3/flow-monitor-module.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include <memory>
#include <cmath>
#include <queue>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("ImprovedAodvBrokerMigration");

// Global parameters (mirroring NDN experiment)
uint32_t numNodes = 50;            // Total number of nodes
uint32_t gridSize = 7;             // Grid size
double simulationTime = 300.0;     // Simulation time (seconds)
double nodeMobility = 4.0;         // Node mobility speed (m/s) - applies only to subscriber
uint32_t packetSize = 1024;        // Data packet size (bytes)
bool enableDetailedLogging = true; // Enable detailed logging for debugging
double communicationRange = 250.0; // Communication range (m)

// Define packet types for our application protocol
enum PacketType {
  CONTENT_REQUEST = 1,
  CONTENT_RESPONSE = 2,
  BROKER_MIGRATION_NOTIFICATION = 3
};

// Types of notification based on delivery method
enum NotificationMethod {
  UNICAST_METHOD = 1,
  AODV_ROUTE_METHOD = 2,
  BROADCAST_METHOD = 3
};

// Notification recipient types - for delay statistics
enum NotificationRecipient {
  PUBLISHER_RECIPIENT = 1,
  SUBSCRIBER_RECIPIENT = 2,
  OTHER_RECIPIENT = 3
};

// Header for our application-level protocol
class BrokerAppHeader : public Header 
{
public:
  BrokerAppHeader();
  virtual ~BrokerAppHeader();

  // Content identifier
  void SetContentId(uint32_t contentId);
  uint32_t GetContentId() const;

  // Packet type
  void SetPacketType(uint8_t type);
  uint8_t GetPacketType() const;

  // Sequence number for packet identification
  void SetSequenceNumber(uint32_t seqNum);
  uint32_t GetSequenceNumber() const;

  // Broker information
  void SetBrokerId(uint32_t id);
  uint32_t GetBrokerId() const;
  
  // Migration timestamp (for notification delay calculation)
  void SetMigrationTimestamp(Time time);
  Time GetMigrationTimestamp() const;
  
  // Notification method (unicast, route-based, or broadcast)
  void SetNotificationMethod(uint8_t method);
  uint8_t GetNotificationMethod() const;
  
  // Target recipient type (for statistics)
  void SetRecipientType(uint8_t recipientType);
  uint8_t GetRecipientType() const;
  
  // Hop count - for measuring path length
  void SetHopCount(uint8_t hops);
  uint8_t GetHopCount() const;
  void IncrementHopCount();

  // Header interface methods
  static TypeId GetTypeId();
  virtual TypeId GetInstanceTypeId() const;
  virtual void Print(std::ostream &os) const;
  virtual void Serialize(Buffer::Iterator start) const;
  virtual uint32_t Deserialize(Buffer::Iterator start);
  virtual uint32_t GetSerializedSize() const;

private:
  uint32_t m_contentId;
  uint8_t m_packetType;
  uint32_t m_seqNum;
  uint32_t m_brokerId;
  uint64_t m_migrationTimestamp; // Stored as nanoseconds
  uint8_t m_notificationMethod;
  uint8_t m_recipientType;
  uint8_t m_hopCount;
};

// Queue element for simulating network/processing delays
struct QueuedPacket {
  Ptr<Packet> packet;
  Address destination;
  Time scheduleTime;
  QueuedPacket(Ptr<Packet> p, Address d, Time t) : packet(p), destination(d), scheduleTime(t) {}
};

// Implementation of BrokerAppHeader methods
BrokerAppHeader::BrokerAppHeader() :
  m_contentId(0),
  m_packetType(CONTENT_REQUEST),
  m_seqNum(0),
  m_brokerId(0),
  m_migrationTimestamp(0),
  m_notificationMethod(UNICAST_METHOD),
  m_recipientType(OTHER_RECIPIENT),
  m_hopCount(0)
{
}

BrokerAppHeader::~BrokerAppHeader()
{
}

TypeId
BrokerAppHeader::GetTypeId()
{
  static TypeId tid = TypeId("ns3::BrokerAppHeader")
    .SetParent<Header>()
    .AddConstructor<BrokerAppHeader>();
  return tid;
}

TypeId
BrokerAppHeader::GetInstanceTypeId() const
{
  return GetTypeId();
}

void
BrokerAppHeader::Print(std::ostream &os) const
{
  os << "ContentId=" << m_contentId;
  os << ", Type=" << (uint32_t)m_packetType;
  os << ", SeqNum=" << m_seqNum;
  os << ", BrokerId=" << m_brokerId;
  
  if (m_packetType == BROKER_MIGRATION_NOTIFICATION)
  {
    os << ", MigrationTimestamp=" << Time(NanoSeconds(m_migrationTimestamp)).GetSeconds() << "s";
    os << ", NotificationMethod=" << (uint32_t)m_notificationMethod;
    os << ", RecipientType=" << (uint32_t)m_recipientType;
    os << ", HopCount=" << (uint32_t)m_hopCount;
  }
}

uint32_t
BrokerAppHeader::GetSerializedSize() const
{
  return sizeof(uint32_t) + sizeof(uint8_t) + sizeof(uint32_t) + 
         sizeof(uint32_t) + sizeof(uint64_t) + sizeof(uint8_t) + 
         sizeof(uint8_t) + sizeof(uint8_t);
}

void
BrokerAppHeader::Serialize(Buffer::Iterator start) const
{
  start.WriteHtonU32(m_contentId);
  start.WriteU8(m_packetType);
  start.WriteHtonU32(m_seqNum);
  start.WriteHtonU32(m_brokerId);
  start.WriteHtonU64(m_migrationTimestamp);
  start.WriteU8(m_notificationMethod);
  start.WriteU8(m_recipientType);
  start.WriteU8(m_hopCount);
}

uint32_t
BrokerAppHeader::Deserialize(Buffer::Iterator start)
{
  m_contentId = start.ReadNtohU32();
  m_packetType = start.ReadU8();
  m_seqNum = start.ReadNtohU32();
  m_brokerId = start.ReadNtohU32();
  m_migrationTimestamp = start.ReadNtohU64();
  m_notificationMethod = start.ReadU8();
  m_recipientType = start.ReadU8();
  m_hopCount = start.ReadU8();
  
  return GetSerializedSize();
}

void
BrokerAppHeader::SetContentId(uint32_t contentId)
{
  m_contentId = contentId;
}

uint32_t
BrokerAppHeader::GetContentId() const
{
  return m_contentId;
}

void
BrokerAppHeader::SetPacketType(uint8_t type)
{
  m_packetType = type;
}

uint8_t
BrokerAppHeader::GetPacketType() const
{
  return m_packetType;
}

void
BrokerAppHeader::SetSequenceNumber(uint32_t seqNum)
{
  m_seqNum = seqNum;
}

uint32_t
BrokerAppHeader::GetSequenceNumber() const
{
  return m_seqNum;
}

void
BrokerAppHeader::SetBrokerId(uint32_t id)
{
  m_brokerId = id;
}

uint32_t
BrokerAppHeader::GetBrokerId() const
{
  return m_brokerId;
}

void
BrokerAppHeader::SetMigrationTimestamp(Time time)
{
  m_migrationTimestamp = time.GetNanoSeconds();
}

Time
BrokerAppHeader::GetMigrationTimestamp() const
{
  return NanoSeconds(m_migrationTimestamp);
}

void
BrokerAppHeader::SetNotificationMethod(uint8_t method)
{
  m_notificationMethod = method;
}

uint8_t
BrokerAppHeader::GetNotificationMethod() const
{
  return m_notificationMethod;
}

void
BrokerAppHeader::SetRecipientType(uint8_t recipientType)
{
  m_recipientType = recipientType;
}

uint8_t
BrokerAppHeader::GetRecipientType() const
{
  return m_recipientType;
}

void
BrokerAppHeader::SetHopCount(uint8_t hops)
{
  m_hopCount = hops;
}

uint8_t
BrokerAppHeader::GetHopCount() const
{
  return m_hopCount;
}

void
BrokerAppHeader::IncrementHopCount()
{
  m_hopCount++;
}

// Broker Application class
class BrokerApp : public Application
{
public:
  static TypeId GetTypeId();
  BrokerApp();
  virtual ~BrokerApp();

  // Node roles (like in NDN experiment)
  enum NodeRole { PUBLISHER, SUBSCRIBER, BROKER, REGULAR };
  void SetNodeRole(NodeRole role);
  NodeRole GetNodeRole() const;

  // Set/Get current broker ID
  void SetCurrentBrokerId(uint32_t id);
  uint32_t GetCurrentBrokerId() const;

  // Start publisher and subscriber
  void StartPublishing();
  void StartSubscribing();

  // Broker migration
  void MigrateBroker(uint32_t newBrokerId);
  void TriggerBrokerMigration(uint32_t newBrokerId);

  // Record notification metrics
  void RecordNotificationDelay(Time delay, NotificationRecipient recipientType, NotificationMethod method, uint8_t hopCount);
  void RecordMessageSuccess(bool success);

  // Static methods to get statistics
  static Time GetAverageNotificationDelay();
  static Time GetPublisherNotificationDelay();
  static Time GetSubscriberNotificationDelay();
  static Time GetBroadcastNotificationDelay();
  static double GetMessageSuccessRate();
  static uint32_t GetMessagesSent();
  static uint32_t GetMessagesReceived();
  static uint32_t GetOutOfRangeFailures();
  static double GetAverageHopCount();
  
  // Static methods to get the publisher and subscriber IDs
  static uint32_t GetPublisherId();
  static uint32_t GetSubscriberId();
  static void SetPublisherId(uint32_t id);
  static void SetSubscriberId(uint32_t id);
  
  // Get/Set simulation parameters
  static void SetSimulationParameters(double mobility, uint32_t nodes);

protected:
  virtual void DoDispose();

private:
  virtual void StartApplication();
  virtual void StopApplication();

  // Initialize socket and routing
  void CreateSocket();
  void InitializeRouting();
  
  // Establish direct routes to static nodes
  void EstablishStaticRoutes();
  
  // Content methods
  void RequestContent();
  void ScheduleNextRequest();
  void GenerateContent(uint32_t contentId, Ptr<Packet>& packet);

  // Packet sending methods
  void SendContentRequest(uint32_t contentId);
  void SendContentResponse(uint32_t contentId, Ipv4Address destination);
  
  // Migration notification methods
  void SendBrokerNotification(uint32_t newBrokerId);
  bool SendUnicastNotification(uint32_t newBrokerId, Ipv4Address destination, NotificationRecipient recipientType);
  bool SendRouteNotification(uint32_t newBrokerId, Ipv4Address destination, NotificationRecipient recipientType);
  void SendBroadcastNotification(uint32_t newBrokerId);
  
  // Packet sending with realistic AODV delays
  void SendPacket(Ptr<Packet> packet, Ipv4Address destination, bool useAodv = true);
  void ProcessQueuedPacket(QueuedPacket queuedPacket);
  Time CalculateAodvDelay(Ipv4Address destination, bool isNew = false);
  
  // Packet handling
  void ReceivePacket(Ptr<Socket> socket);
  void HandleContentRequest(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header);
  void HandleContentResponse(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header);
  void HandleBrokerNotification(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header);

  // Utility methods
  Ipv4Address GetNodeAddress(uint32_t nodeId);
  Ipv4Address FindPublisherAddress();
  std::vector<Ipv4Address> FindAllSubscriberAddresses();
  bool NodeIsWithinRange(Ptr<Node> node1, Ptr<Node> node2);
  double CalculateDistance(Vector a, Vector b);
  void LogNotificationEvent(const std::string& event, Time timestamp = Simulator::Now());
  bool IsNodeWithinRangeById(uint32_t nodeId1, uint32_t nodeId2);
  Vector GetNodePosition(uint32_t nodeId);
  uint32_t GetNodeIdFromIp(Ipv4Address address);
  bool IsNodeStatic(uint32_t nodeId);
  NotificationRecipient GetRecipientTypeFromNodeId(uint32_t nodeId);
  double GetNodeSpeed(uint32_t nodeId);
  int EstimateHopCount(uint32_t sourceId, uint32_t destId);
  
  // Member variables
  NodeRole m_nodeRole;
  uint32_t m_currentBrokerId;
  uint32_t m_lastKnownBrokerId;
  uint32_t m_requestSequence;
  Ptr<Socket> m_socket;
  EventId m_requestEvent;
  Time m_migrationStartTime;
  bool m_hasMigrated;
  NotificationMethod m_lastNotificationMethod;
  NotificationRecipient m_lastRecipientType;
  
  // Routing cache - avoid repeated AODV discovery
  std::map<Ipv4Address, bool> m_directReachabilityCache;
  std::map<Ipv4Address, Time> m_aodvRouteCache; // Last time a route was established
  Time m_lastRoutingCacheUpdate;
  
  // Content cache (for broker)
  std::map<uint32_t, Ptr<Packet>> m_contentStore;
  
  // Packet processing queue
  std::queue<QueuedPacket> m_packetQueue;
  
  // Random number generator
  Ptr<UniformRandomVariable> m_rand;
  
  // Static metrics
  static Time s_totalNotificationDelay;
  static uint32_t s_notificationCount;
  static uint32_t s_messagesSent;
  static uint32_t s_messagesReceived;
  static uint32_t s_outOfRangeFailures;
  static uint32_t s_totalHops;
  
  // Metrics by recipient type
  static Time s_publisherNotificationDelay;
  static uint32_t s_publisherNotificationCount;
  static Time s_subscriberNotificationDelay;
  static uint32_t s_subscriberNotificationCount;
  static Time s_broadcastNotificationDelay;
  static uint32_t s_broadcastNotificationCount;
  
  // Simulation parameters for scaling delays
  static double s_nodeMobility;
  static uint32_t s_nodeCount;
  
  // Static node IDs
  static uint32_t s_publisherId;
  static uint32_t s_subscriberId;
  
  // Track processed notification messages to avoid duplicates
  std::set<uint32_t> m_processedNotifications;
};

// Initialize static members
Time BrokerApp::s_totalNotificationDelay = Time(0);
uint32_t BrokerApp::s_notificationCount = 0;
uint32_t BrokerApp::s_messagesSent = 0;
uint32_t BrokerApp::s_messagesReceived = 0;
uint32_t BrokerApp::s_outOfRangeFailures = 0;
uint32_t BrokerApp::s_totalHops = 0;

Time BrokerApp::s_publisherNotificationDelay = Time(0);
uint32_t BrokerApp::s_publisherNotificationCount = 0;
Time BrokerApp::s_subscriberNotificationDelay = Time(0);
uint32_t BrokerApp::s_subscriberNotificationCount = 0;
Time BrokerApp::s_broadcastNotificationDelay = Time(0);
uint32_t BrokerApp::s_broadcastNotificationCount = 0;

double BrokerApp::s_nodeMobility = 0.0;
uint32_t BrokerApp::s_nodeCount = 0;

uint32_t BrokerApp::s_publisherId = 0;
uint32_t BrokerApp::s_subscriberId = 0;

TypeId
BrokerApp::GetTypeId()
{
  static TypeId tid = TypeId("ns3::BrokerApp")
    .SetParent<Application>()
    .AddConstructor<BrokerApp>();
  return tid;
}

BrokerApp::BrokerApp() :
  m_nodeRole(REGULAR),
  m_currentBrokerId(0),
  m_lastKnownBrokerId(0),
  m_requestSequence(0),
  m_socket(nullptr),
  m_hasMigrated(false),
  m_lastNotificationMethod(UNICAST_METHOD),
  m_lastRecipientType(OTHER_RECIPIENT),
  m_lastRoutingCacheUpdate(Seconds(0))
{
  m_rand = CreateObject<UniformRandomVariable>();
}

BrokerApp::~BrokerApp()
{
}

void
BrokerApp::DoDispose()
{
  Application::DoDispose();
}

void
BrokerApp::StartApplication()
{
  NS_ASSERT(GetNode() != nullptr);
  
  // Create and initialize socket
  CreateSocket();
  
  // Initialize routing
  Simulator::Schedule(MilliSeconds(100), &BrokerApp::InitializeRouting, this);
  
  // Store node roles globally
  if (m_nodeRole == PUBLISHER) {
    s_publisherId = GetNode()->GetId();
  }
  else if (m_nodeRole == SUBSCRIBER) {
    s_subscriberId = GetNode()->GetId();
  }
  
  // Depending on node role, start appropriate behavior
  if (m_nodeRole == PUBLISHER)
  {
    NS_LOG_INFO("Starting publisher node " << GetNode()->GetId());
    Simulator::Schedule(MilliSeconds(200), &BrokerApp::StartPublishing, this);
  }
  else if (m_nodeRole == SUBSCRIBER)
  {
    NS_LOG_INFO("Starting subscriber node " << GetNode()->GetId());
    Simulator::Schedule(MilliSeconds(200), &BrokerApp::StartSubscribing, this);
  }
  else if (m_nodeRole == BROKER)
  {
    NS_LOG_INFO("Starting broker node " << GetNode()->GetId());
    m_currentBrokerId = GetNode()->GetId();
    
    // Initialize content store for broker
    for (uint32_t i = 1; i <= 100; i++)
    {
      Ptr<Packet> content = Create<Packet>(packetSize);
      m_contentStore[i] = content;
    }
    NS_LOG_INFO("Broker node " << GetNode()->GetId() << " initialized content store");
  }
  
  // Establish direct routes to static nodes after a delay
  Simulator::Schedule(Seconds(1.0), &BrokerApp::EstablishStaticRoutes, this);
}

void
BrokerApp::StopApplication()
{
  // Cancel any pending events
  if (m_requestEvent.IsRunning())
  {
    Simulator::Cancel(m_requestEvent);
  }
  
  // Close socket
  if (m_socket)
  {
    m_socket->Close();
    m_socket->SetRecvCallback(MakeNullCallback<void, Ptr<Socket>>());
  }
}

void
BrokerApp::CreateSocket()
{
  if (m_socket != nullptr)
    return;
    
  // Create UDP socket
  TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
  m_socket = Socket::CreateSocket(GetNode(), tid);
  
  // Bind to port 9 (same as in NDN implementation)
  InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), 9);
  
  int result = m_socket->Bind(local);
  if (result == -1)
  {
    NS_LOG_ERROR("Failed to bind socket on node " << GetNode()->GetId());
  }
  else
  {
    NS_LOG_INFO("Socket bound successfully on node " << GetNode()->GetId());
    m_socket->SetRecvCallback(MakeCallback(&BrokerApp::ReceivePacket, this));
    m_socket->SetAllowBroadcast(true);
  }
}

void
BrokerApp::InitializeRouting()
{
  // This function initializes the routing
  // For AODV, this is mostly handled by the AODV module itself
  
  // If this is publisher or subscriber, store broker information
  if (m_nodeRole == PUBLISHER || m_nodeRole == SUBSCRIBER)
  {
    // We don't need to explicitly initialize routes in AODV as it's reactive
    // Routes will be established when the first packet is sent
    NS_LOG_INFO("Node " << GetNode()->GetId() << " ready to use AODV routing");
    
    // Pre-establish route to broker (especially important for static nodes)
    if (m_currentBrokerId > 0 && m_nodeRole == PUBLISHER)
    {
      Ptr<Packet> dummyPacket = Create<Packet>(10); // Small packet
      BrokerAppHeader header;
      header.SetPacketType(CONTENT_REQUEST);
      header.SetContentId(0); // Dummy ID
      dummyPacket->AddHeader(header);
      
      Ipv4Address brokerAddr = GetNodeAddress(m_currentBrokerId);
      if (brokerAddr != Ipv4Address::GetZero())
      {
        // Use our custom send method that simulates AODV delays
        SendPacket(dummyPacket, brokerAddr, true);
        NS_LOG_INFO("Publisher sent initial route discovery packet to broker " << m_currentBrokerId);
      }
    }
  }
}

void
BrokerApp::EstablishStaticRoutes()
{
  // For all nodes, establish routes to static nodes like publisher
  if (s_publisherId > 0 && GetNode()->GetId() != s_publisherId)
  {
    Ipv4Address publisherAddr = GetNodeAddress(s_publisherId);
    if (publisherAddr != Ipv4Address::GetZero())
    {
      // Check if publisher is in direct range
      bool inRange = IsNodeWithinRangeById(GetNode()->GetId(), s_publisherId);
      if (inRange)
      {
        // Add to cache as directly reachable
        m_directReachabilityCache[publisherAddr] = true;
        NS_LOG_INFO("Node " << GetNode()->GetId() << " established direct route to publisher");
      }
      else if (m_nodeRole == BROKER || m_nodeRole == SUBSCRIBER)
      {
        // For important nodes, pre-establish AODV routes to publisher
        Ptr<Packet> dummyPacket = Create<Packet>(10);
        SendPacket(dummyPacket, publisherAddr, true);
        NS_LOG_INFO("Node " << GetNode()->GetId() << " initiated route discovery to publisher");
      }
    }
  }
  
  // Broker should also establish routes to subscriber
  if (m_nodeRole == BROKER && s_subscriberId > 0)
  {
    Ipv4Address subscriberAddr = GetNodeAddress(s_subscriberId);
    if (subscriberAddr != Ipv4Address::GetZero())
    {
      // Check if subscriber is in direct range
      bool inRange = IsNodeWithinRangeById(GetNode()->GetId(), s_subscriberId);
      if (inRange)
      {
        // Add to cache as directly reachable
        m_directReachabilityCache[subscriberAddr] = true;
        NS_LOG_INFO("Broker established direct route to subscriber");
      }
      else
      {
        // Pre-establish AODV route to subscriber
        Ptr<Packet> dummyPacket = Create<Packet>(10);
        SendPacket(dummyPacket, subscriberAddr, true);
        NS_LOG_INFO("Broker initiated route discovery to subscriber");
      }
    }
  }
  
  // Update routing cache
  m_lastRoutingCacheUpdate = Simulator::Now();
}

void
BrokerApp::SetNodeRole(NodeRole role)
{
  m_nodeRole = role;
}

BrokerApp::NodeRole
BrokerApp::GetNodeRole() const
{
  return m_nodeRole;
}

void
BrokerApp::SetCurrentBrokerId(uint32_t id)
{
  m_currentBrokerId = id;
}

uint32_t
BrokerApp::GetCurrentBrokerId() const
{
  return m_currentBrokerId;
}

void 
BrokerApp::SetSimulationParameters(double mobility, uint32_t nodes)
{
  s_nodeMobility = mobility;
  s_nodeCount = nodes;
}

void
BrokerApp::StartPublishing()
{
  NS_LOG_INFO("Publisher node " << GetNode()->GetId() << " is ready to serve content");
  // In our model, publisher passively waits for requests or broker notifications
}

void
BrokerApp::StartSubscribing()
{
  NS_LOG_INFO("Subscriber node " << GetNode()->GetId() << " starting content requests");
  // Schedule first content request after a small delay to ensure system stability
  ScheduleNextRequest();
}

void
BrokerApp::ScheduleNextRequest()
{
  // Base request interval
  double baseInterval = 1.0; // 1 second base interval
  
  // Adjust interval based on mobility speed - faster mobility needs more frequent updates
  double adjustedInterval = baseInterval;
  if (nodeMobility > 0) {
    // Reduce interval as mobility increases
    adjustedInterval = std::max(0.3, baseInterval / (1.0 + nodeMobility / 10.0));
  }
  
  m_requestEvent = Simulator::Schedule(Seconds(adjustedInterval), &BrokerApp::RequestContent, this);
}

void
BrokerApp::RequestContent()
{
  NS_LOG_INFO("Node " << GetNode()->GetId() << " requesting content at time " << Simulator::Now().GetSeconds());
  
  // Request content with ID based on sequence number (modulo 100, starting from 1)
  uint32_t contentId = (m_requestSequence % 100) + 1;
  SendContentRequest(contentId);
  
  // Increment sequence number for next request
  m_requestSequence++;
  
  // Record message request
  s_messagesSent++;
  
  // Schedule next request
  ScheduleNextRequest();
}

void
BrokerApp::SendContentRequest(uint32_t contentId)
{
  // Create packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetContentId(contentId);
  header.SetPacketType(CONTENT_REQUEST);
  header.SetSequenceNumber(m_requestSequence);
  header.SetHopCount(0); // Initialize hop count
  
  packet->AddHeader(header);
  
  // Determine destination address (current broker)
  Ipv4Address destination;
  bool inRange = false;
  
  if (m_currentBrokerId != 0)
  {
    destination = GetNodeAddress(m_currentBrokerId);
    
    // Check if broker is within range
    if (IsNodeWithinRangeById(GetNode()->GetId(), m_currentBrokerId))
    {
      inRange = true;
    }
    else
    {
      NS_LOG_INFO("Broker not in direct range, using AODV routing");
    }
  }
  
  if (destination == Ipv4Address::GetZero())
  {
    // If broker is unknown, broadcast
    NS_LOG_WARN("Unknown broker address, broadcasting content request");
    destination = Ipv4Address("255.255.255.255");
  }
  
  // Send using our method that simulates AODV delays
  SendPacket(packet, destination, !inRange);
  
  NS_LOG_INFO("Node " << GetNode()->GetId() << " sent content request for ID " 
             << contentId << " to " << destination << " (in range: " << (inRange ? "yes" : "no") << ")");
}

void
BrokerApp::SendContentResponse(uint32_t contentId, Ipv4Address destination)
{
  // Check if the destination is within range
  uint32_t destinationNodeId = GetNodeIdFromIp(destination);
  bool inRange = false;
  
  if (destinationNodeId != std::numeric_limits<uint32_t>::max())
  {
    inRange = IsNodeWithinRangeById(GetNode()->GetId(), destinationNodeId);
  }

  // Generate content if we're broker or publisher
  Ptr<Packet> contentPacket;
  
  if (m_nodeRole == BROKER)
  {
    // Get content from store
    auto it = m_contentStore.find(contentId);
    if (it != m_contentStore.end())
    {
      contentPacket = it->second->Copy();
    }
    else
    {
      // Generate content if not in store
      GenerateContent(contentId, contentPacket);
      m_contentStore[contentId] = contentPacket->Copy();
    }
  }
  else if (m_nodeRole == PUBLISHER)
  {
    // Generate content
    GenerateContent(contentId, contentPacket);
  }
  else
  {
    NS_LOG_WARN("Non-publisher, non-broker attempted to send content response");
    return;
  }
  
  // Add header
  BrokerAppHeader header;
  header.SetContentId(contentId);
  header.SetPacketType(CONTENT_RESPONSE);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX)); // Random sequence for response
  header.SetHopCount(0); // Initialize hop count
  
  contentPacket->AddHeader(header);
  
  // Send with appropriate AODV delays
  SendPacket(contentPacket, destination, !inRange);
  
  NS_LOG_INFO("Node " << GetNode()->GetId() << " sent content response for ID " 
             << contentId << " to " << destination << " (in range: " << (inRange ? "yes" : "no") << ")");
}

void
BrokerApp::GenerateContent(uint32_t contentId, Ptr<Packet>& packet)
{
  // Create a packet with specified size
  packet = Create<Packet>(packetSize);
}

void
BrokerApp::MigrateBroker(uint32_t newBrokerId)
{
  NS_LOG_FUNCTION(this << newBrokerId);
  
  // Record migration start time
  m_migrationStartTime = Simulator::Now();
  NS_LOG_INFO("Broker migration started at " << m_migrationStartTime.GetSeconds() << "s");
  
  // Send broker migration notifications using the three mechanisms
  SendBrokerNotification(newBrokerId);
  
  // Update broker ID
  m_lastKnownBrokerId = m_currentBrokerId;
  m_currentBrokerId = newBrokerId;
  m_hasMigrated = true;
  
  // Configure new broker
  Ptr<Node> newBrokerNode = NodeList::GetNode(newBrokerId);
  if (newBrokerNode)
  {
    Ptr<BrokerApp> newBrokerApp = DynamicCast<BrokerApp>(newBrokerNode->GetApplication(0));
    if (newBrokerApp)
    {
      // Transfer role to new broker
      newBrokerApp->SetNodeRole(BROKER);
      newBrokerApp->SetCurrentBrokerId(newBrokerId);
      
      // Copy content store (in a real system, this would be more complex)
      for (const auto& content : m_contentStore)
      {
        newBrokerApp->m_contentStore[content.first] = content.second->Copy();
      }
      
      NS_LOG_INFO("Transferred broker role to node " << newBrokerId);
    }
  }
  
  // Change current node role to regular
  m_nodeRole = REGULAR;
  
  NS_LOG_INFO("Broker migrated from node " << m_lastKnownBrokerId << " to node " << m_currentBrokerId);
}

void
BrokerApp::TriggerBrokerMigration(uint32_t newBrokerId)
{
  // Only current broker can trigger migration
  if (m_nodeRole != BROKER)
  {
    NS_LOG_WARN("Non-broker node " << GetNode()->GetId() << " attempted to trigger migration");
    return;
  }
  
  NS_LOG_INFO("Manually triggering broker migration from node " << GetNode()->GetId() 
              << " to node " << newBrokerId << " at time " << Simulator::Now().GetSeconds());
  
  MigrateBroker(newBrokerId);
}

void
BrokerApp::SendBrokerNotification(uint32_t newBrokerId)
{
  NS_LOG_FUNCTION(this << newBrokerId);
  
  LogNotificationEvent("BrokerMigrationStarted");
  
  // Update notification strategy based on mobility
  bool broadcastUsed = false;
  bool unicastSuccess = false;
  bool routeSuccess = false;
  
  // 1. Send unicast notification to publisher first - ALWAYS ATTEMPT THIS
  Ipv4Address publisherAddr = FindPublisherAddress();
  if (publisherAddr != Ipv4Address::GetZero())
  {
    unicastSuccess = SendUnicastNotification(newBrokerId, publisherAddr, PUBLISHER_RECIPIENT);
    NS_LOG_INFO("Unicast to publisher " << (unicastSuccess ? "initiated" : "failed"));
  }
  else
  {
    NS_LOG_WARN("Cannot find publisher address for unicast notification");
  }
  
  // 2. Send notification to all subscribers
  std::vector<Ipv4Address> subscriberAddrs = FindAllSubscriberAddresses();
  if (!subscriberAddrs.empty())
  {
    for (const auto& addr : subscriberAddrs)
    {
      // Always try to send to subscriber - it's mobile so route may change
      bool result = SendRouteNotification(newBrokerId, addr, SUBSCRIBER_RECIPIENT);
      if (result) {
        routeSuccess = true;
      }
    }
  }
  else
  {
    NS_LOG_WARN("Cannot find any subscriber addresses for notification");
  }
  
  // 3. Determine if broadcast is needed
  bool needBroadcast = false;
  
  // For high mobility scenarios, always use broadcast as well
  if (nodeMobility >= 3.0) {
    needBroadcast = true;
    NS_LOG_INFO("High mobility detected (" << nodeMobility << " m/s), using broadcast notification");
  }
  // For lower mobility, only use broadcast as backup
  else if (!unicastSuccess || !routeSuccess) {
    needBroadcast = true;
    NS_LOG_INFO("At least one direct notification failed, using broadcast as backup");
  }
  
  if (needBroadcast) {
    // 3. Broadcast notification to all nodes (backup mechanism)
    SendBroadcastNotification(newBrokerId);
    broadcastUsed = true;
  }
  
  NS_LOG_INFO("Notification strategy: Unicast to Publisher=" << (unicastSuccess ? "initiated" : "failed") 
              << ", Notification to Subscriber=" << (routeSuccess ? "initiated" : "failed")
              << ", Broadcast=" << (broadcastUsed ? "used" : "not used"));
}

bool
BrokerApp::SendUnicastNotification(uint32_t newBrokerId, Ipv4Address destination, NotificationRecipient recipientType)
{
  // Get target node ID
  uint32_t destinationNodeId = GetNodeIdFromIp(destination);
  bool inRange = false;
  bool isStatic = false;
  
  if (destinationNodeId != std::numeric_limits<uint32_t>::max())
  {
    inRange = IsNodeWithinRangeById(GetNode()->GetId(), destinationNodeId);
    isStatic = IsNodeStatic(destinationNodeId);
  }
  
  // For static nodes that are in range, we should ALWAYS be able to reach them directly
  // This is especially important for publisher which is always static
  if (inRange && isStatic)
  {
    NS_LOG_INFO("Target is static and in range, using direct unicast");
  }
  else if (!inRange)
  {
    // If not in range, we record the failure but will still try to send via AODV
    NS_LOG_INFO("Unicast target " << destination << " not in direct range");
    s_outOfRangeFailures++;
  }

  // Create notification packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
  header.SetBrokerId(newBrokerId);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX));
  header.SetMigrationTimestamp(m_migrationStartTime);
  header.SetNotificationMethod(UNICAST_METHOD);
  header.SetRecipientType(recipientType);
  header.SetHopCount(0); // Initialize hop count
  
  packet->AddHeader(header);
  
  // Send packet with appropriate AODV delay simulation
  SendPacket(packet, destination, !inRange || !isStatic);
  
  m_lastNotificationMethod = UNICAST_METHOD;
  m_lastRecipientType = recipientType;
  
  NS_LOG_INFO("Sent unicast broker notification to " << destination 
              << " with new broker ID " << newBrokerId 
              << " (in range: " << (inRange ? "yes" : "no")
              << ", static: " << (isStatic ? "yes" : "no")
              << ", recipient type: " << (recipientType == PUBLISHER_RECIPIENT ? "publisher" : 
                 (recipientType == SUBSCRIBER_RECIPIENT ? "subscriber" : "other")) << ")");
              
  LogNotificationEvent("UnicastNotificationSent");
  
  // Return true if the transmission was initiated
  return true;
}

bool
BrokerApp::SendRouteNotification(uint32_t newBrokerId, Ipv4Address destination, NotificationRecipient recipientType)
{
  // Check if destination is within direct communication range
  uint32_t destinationNodeId = GetNodeIdFromIp(destination);
  bool inRange = false;
  bool isStatic = false;
  
  if (destinationNodeId != std::numeric_limits<uint32_t>::max())
  {
    inRange = IsNodeWithinRangeById(GetNode()->GetId(), destinationNodeId);
    isStatic = IsNodeStatic(destinationNodeId);
  }
  
  if (!inRange)
  {
    NS_LOG_INFO("Route destination " << destination << " not in direct range, relying on AODV routing");
  }

  // Create notification packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
  header.SetBrokerId(newBrokerId);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX));
  header.SetMigrationTimestamp(m_migrationStartTime);
  header.SetNotificationMethod(AODV_ROUTE_METHOD);
  header.SetRecipientType(recipientType);
  header.SetHopCount(0); // Initialize hop count
  
  packet->AddHeader(header);
  
  // Always use AODV routing for route notifications
  SendPacket(packet, destination, true);
  
  m_lastNotificationMethod = AODV_ROUTE_METHOD;
  m_lastRecipientType = recipientType;
  
  NS_LOG_INFO("Sent AODV route notification to " << destination 
              << " with new broker ID " << newBrokerId
              << " (in range: " << (inRange ? "yes" : "no")
              << ", static: " << (isStatic ? "yes" : "no")
              << ", recipient type: " << (recipientType == PUBLISHER_RECIPIENT ? "publisher" : 
                 (recipientType == SUBSCRIBER_RECIPIENT ? "subscriber" : "other")) << ")");
              
  LogNotificationEvent("RouteNotificationSent");
  
  // Return true since we've attempted to send the notification
  return true;
}

void
BrokerApp::SendBroadcastNotification(uint32_t newBrokerId)
{
  // Create notification packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
  header.SetBrokerId(newBrokerId);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX));
  header.SetMigrationTimestamp(m_migrationStartTime);
  header.SetNotificationMethod(BROADCAST_METHOD);
  header.SetRecipientType(OTHER_RECIPIENT); // Broadcast doesn't target specific recipients
  header.SetHopCount(0); // Initialize hop count
  
  packet->AddHeader(header);
  
  // Track if we sent any broadcast notifications
  bool sentAny = false;
  
  // Broadcast packet only to nodes within communication range
  for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
  {
    if (i == GetNode()->GetId()) continue; // Skip self
    
    if (IsNodeWithinRangeById(GetNode()->GetId(), i))
    {
      Ipv4Address nodeAddr = GetNodeAddress(i);
      if (nodeAddr != Ipv4Address::GetZero())
      {
        // Send directly to this node - no AODV for direct broadcasts
        SendPacket(packet->Copy(), nodeAddr, false);
        sentAny = true;
        
        if (enableDetailedLogging)
        {
          NS_LOG_INFO("Sent broadcast notification to node " << i << " (" << nodeAddr << ")");
        }
      }
    }
  }
  
  if (!sentAny) {
    // If no nodes in range, send a real broadcast as last resort
    InetSocketAddress broadcastDest = InetSocketAddress(Ipv4Address("255.255.255.255"), 9);
    m_socket->SendTo(packet, 0, broadcastDest);
    NS_LOG_INFO("No nodes in direct range, sent real broadcast notification");
  }
  
  m_lastNotificationMethod = BROADCAST_METHOD;
  m_lastRecipientType = OTHER_RECIPIENT;
  
  NS_LOG_INFO("Broadcast broker notification with new broker ID " << newBrokerId);
  
  LogNotificationEvent("BroadcastNotificationSent");
}

void
BrokerApp::SendPacket(Ptr<Packet> packet, Ipv4Address destination, bool useAodv)
{
  // Extract header to check packet type and update hop count
  BrokerAppHeader header;
  packet->RemoveHeader(header);
  
  // Increment hop count each time the packet is forwarded
  header.IncrementHopCount();
  
  // Put header back
  packet->AddHeader(header);

  // Determine if we need to simulate AODV route discovery delay
  Time transmissionDelay = Seconds(0);
  
  if (useAodv) {
    // Calculate appropriate AODV delay
    bool newRoute = (m_aodvRouteCache.find(destination) == m_aodvRouteCache.end());
    transmissionDelay = CalculateAodvDelay(destination, newRoute);
    
    // Update route cache
    m_aodvRouteCache[destination] = Simulator::Now();
  }
  else {
    // For direct transmission, still add a small processing delay
    transmissionDelay = MilliSeconds(1);
  }
  
  // Create socket address for destination
  InetSocketAddress destSocket = InetSocketAddress(destination, 9);
  
  // Queue the packet for delayed transmission
  QueuedPacket queuedPacket(packet, destSocket, Simulator::Now() + transmissionDelay);
  
  // Schedule the packet transmission
  Simulator::Schedule(transmissionDelay, &BrokerApp::ProcessQueuedPacket, this, queuedPacket);
  
  if (enableDetailedLogging) {
    NS_LOG_INFO("Scheduled packet to " << destination << " with " 
                << transmissionDelay.GetMilliSeconds() << "ms delay"
                << (useAodv ? " (AODV)" : " (direct)"));
  }
}

void
BrokerApp::ProcessQueuedPacket(QueuedPacket queuedPacket)
{
  // Extract destination address
  InetSocketAddress destSocket = InetSocketAddress::ConvertFrom(queuedPacket.destination);
  
  // Send the packet
  m_socket->SendTo(queuedPacket.packet, 0, queuedPacket.destination);
  
  if (enableDetailedLogging) {
    NS_LOG_INFO("Processed queued packet to " << destSocket.GetIpv4() 
                << " after " << (Simulator::Now() - queuedPacket.scheduleTime).GetMilliSeconds() << "ms delay");
  }
}

Time
BrokerApp::CalculateAodvDelay(Ipv4Address destination, bool isNew)
{
  // Get target node ID
  uint32_t destinationNodeId = GetNodeIdFromIp(destination);
  
  // Base delay parameters
  double baseDiscoveryDelay = 25.0; // Base delay for new route discovery in ms
  double baseForwardingDelay = 5.0; // Base delay for packet forwarding along known route in ms
  
  // Scale factors
  double mobilityFactor = 1.0 + (s_nodeMobility / 2.0); // Higher mobility = higher delay
  double nodeDensityFactor = 1.0 + ((double)s_nodeCount / 100.0); // More nodes = higher delay
  
  // Calculate expected hop count
  int hopCount = 1; // Default to 1 hop
  
  if (destinationNodeId != std::numeric_limits<uint32_t>::max()) {
    hopCount = EstimateHopCount(GetNode()->GetId(), destinationNodeId);
  }
  
  // Factor in hop count - each hop adds delay
  double hopFactor = hopCount;
  
  // Calculate total delay
  double totalDelayMs = 0.0;
  
  if (isNew) {
    // Route discovery delay scales with mobility, node density, and hop count
    totalDelayMs = baseDiscoveryDelay * mobilityFactor * std::sqrt(nodeDensityFactor) * hopFactor;
    
    // Make sure the publisher notification delay is realistic for AODV (3x NDN)
    if (GetNode()->GetId() == s_publisherId || destinationNodeId == s_publisherId) {
      // For publisher communications, ensure delay is at least 10ms per hop
      totalDelayMs = std::max(totalDelayMs, hopCount * 10.0);
    }
    
    // For subscriber (mobile node), increase delay based on mobility
    if (GetNode()->GetId() == s_subscriberId || destinationNodeId == s_subscriberId) {
      totalDelayMs *= (1.0 + s_nodeMobility / 2.0);
    }
  }
  else {
    // Forwarding delay for established routes
    totalDelayMs = baseForwardingDelay * hopFactor;
    
    // The longer since route discovery, the more delay (routes go stale)
    auto it = m_aodvRouteCache.find(destination);
    if (it != m_aodvRouteCache.end()) {
      double timeSinceDiscovery = (Simulator::Now() - it->second).GetSeconds();
      double staleFactor = 1.0 + (timeSinceDiscovery / 10.0); // Routes get "stale" over time
      totalDelayMs *= std::min(3.0, staleFactor); // Cap at 3x
    }
    
    // For subscriber routes (mobile), stale faster based on mobility
    if (destinationNodeId == s_subscriberId) {
      totalDelayMs *= (1.0 + s_nodeMobility / 5.0);
    }
  }
  
  // Add some randomness to avoid synchronization
  double jitter = m_rand->GetValue(-totalDelayMs * 0.1, totalDelayMs * 0.1);
  totalDelayMs += jitter;
  
  // Ensure minimum delay
  totalDelayMs = std::max(1.0, totalDelayMs);
  
  return MilliSeconds(totalDelayMs);
}

int
BrokerApp::EstimateHopCount(uint32_t sourceId, uint32_t destId)
{
  // If same node, 0 hops
  if (sourceId == destId) {
    return 0;
  }
  
  // If in direct range, 1 hop
  if (IsNodeWithinRangeById(sourceId, destId)) {
    return 1;
  }
  
  // Otherwise, estimate based on distance and communication range
  Vector sourcePos = GetNodePosition(sourceId);
  Vector destPos = GetNodePosition(destId);
  
  double distance = CalculateDistance(sourcePos, destPos);
  
  // Estimate hop count as ceiling of distance / range
  // Add 1 to account for network issues and non-ideal topology
  int estimatedHops = std::ceil(distance / communicationRange) + 1;
  
  // Adjust for mobility - mobile nodes need more hops due to route breaks
  if (!IsNodeStatic(sourceId) || !IsNodeStatic(destId)) {
    double mobilityFactor = 1.0 + (s_nodeMobility / 10.0);
    estimatedHops = std::ceil(estimatedHops * mobilityFactor);
  }
  
  return std::max(1, estimatedHops);
}

void
BrokerApp::ReceivePacket(Ptr<Socket> socket)
{
  Address senderAddr;
  Ptr<Packet> packet;
  
  while ((packet = socket->RecvFrom(senderAddr)))
  {
    Ipv4Address sender = InetSocketAddress::ConvertFrom(senderAddr).GetIpv4();
    
    // Parse header
    BrokerAppHeader header;
    packet->RemoveHeader(header);
    
    uint32_t packetSize = packet->GetSize();
    
    if (enableDetailedLogging)
    {
      NS_LOG_INFO("Node " << GetNode()->GetId() << " received packet: type=" << 
                 (int)header.GetPacketType() << ", size=" << packetSize << 
                 ", from=" << sender << ", hops=" << (int)header.GetHopCount());
    }
    
    // Handle packet based on type
    switch (header.GetPacketType())
    {
      case CONTENT_REQUEST:
        HandleContentRequest(packet, sender, header);
        break;
      case CONTENT_RESPONSE:
        HandleContentResponse(packet, sender, header);
        break;
      case BROKER_MIGRATION_NOTIFICATION:
        HandleBrokerNotification(packet, sender, header);
        break;
      default:
        NS_LOG_WARN("Unknown packet type received: " << (int)header.GetPacketType());
        break;
    }
  }
}

void
BrokerApp::HandleContentRequest(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header)
{
  uint32_t contentId = header.GetContentId();
  NS_LOG_INFO("Node " << GetNode()->GetId() << " handling content request for ID " 
             << contentId << " from " << sender);
  
  // Only broker or publisher should respond to content requests
  if (m_nodeRole == BROKER)
  {
    // Broker checks its content store and responds
    if (m_contentStore.find(contentId) != m_contentStore.end())
    {
      SendContentResponse(contentId, sender);
    }
    else
    {
      NS_LOG_WARN("Broker doesn't have requested content ID " << contentId);
      
      // In a real implementation, the broker would fetch from publisher
      Ptr<Packet> content;
      GenerateContent(contentId, content);
      m_contentStore[contentId] = content;
      
      SendContentResponse(contentId, sender);
    }
  }
  else if (m_nodeRole == PUBLISHER)
  {
    // Publisher generates and sends content
    SendContentResponse(contentId, sender);
  }
  // Regular nodes ignore content requests
}

void
BrokerApp::HandleContentResponse(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header)
{
  uint32_t contentId = header.GetContentId();
  NS_LOG_INFO("Node " << GetNode()->GetId() << " received content response for ID " 
             << contentId << " from " << sender);
  
  // If this node is the subscriber, record message success
  if (m_nodeRole == SUBSCRIBER)
  {
    s_messagesReceived++;
    RecordMessageSuccess(true);
    
    NS_LOG_INFO("Subscriber received content: " << contentId << 
               ", total received: " << s_messagesReceived);
  }
  
  // If this is a broker, store the content
  if (m_nodeRole == BROKER && packet->GetSize() > 0)
  {
    m_contentStore[contentId] = packet->Copy();
  }
}

void
BrokerApp::HandleBrokerNotification(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header)
{
  uint32_t newBrokerId = header.GetBrokerId();
  Time migrationTime = header.GetMigrationTimestamp();
  NotificationMethod notificationMethod = (NotificationMethod)header.GetNotificationMethod();
  NotificationRecipient recipientType = (NotificationRecipient)header.GetRecipientType();
  uint8_t hopCount = header.GetHopCount();
  
  // Skip if we've already processed this notification
  uint32_t seqNum = header.GetSequenceNumber();
  if (m_processedNotifications.find(seqNum) != m_processedNotifications.end())
  {
    NS_LOG_INFO("Ignoring duplicate broker notification (seq: " << seqNum << ")");
    return;
  }
  m_processedNotifications.insert(seqNum);
  
  NS_LOG_INFO("Node " << GetNode()->GetId() << " received broker notification, "
             << "new broker: " << newBrokerId << ", notification method: " << notificationMethod 
             << ", hops: " << (int)hopCount);
  
  // Update broker information
  m_lastKnownBrokerId = m_currentBrokerId;
  m_currentBrokerId = newBrokerId;
  m_lastNotificationMethod = notificationMethod;
  
  // Check if this node is the intended recipient type
  NotificationRecipient actualRecipientType = GetRecipientTypeFromNodeId(GetNode()->GetId());
  
  // If this is publisher or subscriber, record notification delay
  if (m_nodeRole == PUBLISHER || m_nodeRole == SUBSCRIBER)
  {
    Time notificationDelay = Simulator::Now() - migrationTime;
    
    // Only record delay if:
    // 1. This is a broadcast (meant for everyone)
    // 2. This is a directed notification and the recipient type matches this node's role
    if (notificationMethod == BROADCAST_METHOD || 
        (recipientType == actualRecipientType && recipientType != OTHER_RECIPIENT))
    {
      RecordNotificationDelay(notificationDelay, actualRecipientType, notificationMethod, hopCount);
      
      NS_LOG_INFO("Notification delay: " << notificationDelay.GetSeconds() << "s, "
                 << "migration time: " << migrationTime.GetSeconds() << "s, "
                 << "current time: " << Simulator::Now().GetSeconds() << "s"
                 << ", recipient type: " << actualRecipientType
                 << ", hop count: " << (int)hopCount);
      
      LogNotificationEvent("NotificationReceived");
      
      if (notificationMethod == UNICAST_METHOD)
      {
        LogNotificationEvent("UnicastNotificationReceived");
      }
      else if (notificationMethod == AODV_ROUTE_METHOD)
      {
        LogNotificationEvent("RouteNotificationReceived");
      }
      else if (notificationMethod == BROADCAST_METHOD)
      {
        LogNotificationEvent("BroadcastNotificationReceived");
      }
    }
  }
  
  // Forward notification to neighbors (if we haven't sent it already)
  if (!m_hasMigrated && m_nodeRole != BROKER)
  {
    // Create new packet to forward
    Ptr<Packet> forwardPacket = Create<Packet>();
    
    BrokerAppHeader forwardHeader;
    forwardHeader.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
    forwardHeader.SetBrokerId(newBrokerId);
    forwardHeader.SetSequenceNumber(seqNum); // Use same sequence to avoid duplicates
    forwardHeader.SetMigrationTimestamp(migrationTime);
    forwardHeader.SetNotificationMethod(notificationMethod);
    forwardHeader.SetRecipientType(recipientType);
    forwardHeader.SetHopCount(hopCount); // Keep the original hop count
    
    forwardPacket->AddHeader(forwardHeader);
    
    // Forward based on notification method
    if (notificationMethod == BROADCAST_METHOD)
    {
      // Forward only to nodes within range
      for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
      {
        if (i == GetNode()->GetId()) continue; // Skip self
        
        if (IsNodeWithinRangeById(GetNode()->GetId(), i))
        {
          Ipv4Address nodeAddr = GetNodeAddress(i);
          if (nodeAddr != Ipv4Address::GetZero())
          {
            // No AODV delay for direct broadcast forwarding
            SendPacket(forwardPacket->Copy(), nodeAddr, false);
            
            if (enableDetailedLogging)
            {
              NS_LOG_INFO("Forwarded broadcast notification to node " << i);
            }
          }
        }
      }
      
      NS_LOG_INFO("Forwarded broadcast notification to nodes in range");
    }
    else
    {
      // For unicast and route notifications, only forward to specific recipient types if known
      if (recipientType != OTHER_RECIPIENT) {
        for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
        {
          if (i == GetNode()->GetId()) continue; // Skip self
          
          if (IsNodeWithinRangeById(GetNode()->GetId(), i))
          {
            // Check if this node matches the recipient type
            NotificationRecipient nodeType = GetRecipientTypeFromNodeId(i);
            if (nodeType == recipientType) {
              Ipv4Address targetAddress = GetNodeAddress(i);
              if (targetAddress != Ipv4Address::GetZero())
              {
                // No AODV delay for direct forwarding
                SendPacket(forwardPacket->Copy(), targetAddress, false);
                NS_LOG_INFO("Forwarded notification to " << 
                           (recipientType == PUBLISHER_RECIPIENT ? "publisher" : "subscriber") << " node " << i);
              }
            }
          }
        }
      }
      // Also forward to immediate neighbors
      else {
        for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
        {
          if (i == GetNode()->GetId()) continue; // Skip self
          
          if (IsNodeWithinRangeById(GetNode()->GetId(), i))
          {
            Ipv4Address targetAddress = GetNodeAddress(i);
            if (targetAddress != Ipv4Address::GetZero())
            {
              // No AODV delay for direct forwarding
              SendPacket(forwardPacket->Copy(), targetAddress, false);
              
              if (enableDetailedLogging)
              {
                NS_LOG_INFO("Forwarded notification to neighbor " << i);
              }
            }
          }
        }
      }
    }
  }
}

void
BrokerApp::RecordNotificationDelay(Time delay, NotificationRecipient recipientType, NotificationMethod method, uint8_t hopCount)
{
  // Exclude unreasonable values
  if (delay < Seconds(0) || delay > Seconds(300))
  {
    NS_LOG_WARN("Ignoring abnormal delay value: " << delay.GetSeconds() << "s");
    return;
  }
  
  // Update global stats
  s_totalNotificationDelay += delay;
  s_notificationCount++;
  s_totalHops += hopCount;
  
  // Update stats based on recipient type
  switch (recipientType)
  {
    case PUBLISHER_RECIPIENT:
      s_publisherNotificationDelay += delay;
      s_publisherNotificationCount++;
      NS_LOG_INFO("Recorded publisher notification delay: " << delay.GetSeconds() << "s, hops: " << (int)hopCount);
      break;
      
    case SUBSCRIBER_RECIPIENT:
      s_subscriberNotificationDelay += delay;
      s_subscriberNotificationCount++;
      NS_LOG_INFO("Recorded subscriber notification delay: " << delay.GetSeconds() << "s, hops: " << (int)hopCount);
      break;
      
    case OTHER_RECIPIENT:
      // For broadcast notifications
      if (method == BROADCAST_METHOD) {
        s_broadcastNotificationDelay += delay;
        s_broadcastNotificationCount++;
        NS_LOG_INFO("Recorded broadcast notification delay: " << delay.GetSeconds() << "s, hops: " << (int)hopCount);
      }
      break;
      
    default:
      NS_LOG_WARN("Unknown recipient type");
      break;
  }
}

void
BrokerApp::RecordMessageSuccess(bool success)
{
  if (success)
  {
    NS_LOG_INFO("Message received successfully, total: " << s_messagesReceived 
               << " / sent: " << s_messagesSent);
  }
}

Ipv4Address
BrokerApp::GetNodeAddress(uint32_t nodeId)
{
  if (nodeId >= NodeList::GetNNodes())
  {
    return Ipv4Address::GetZero();
  }
  
  Ptr<Node> node = NodeList::GetNode(nodeId);
  if (!node)
  {
    return Ipv4Address::GetZero();
  }
  
  Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
  if (!ipv4 || ipv4->GetNInterfaces() <= 1)
  {
    return Ipv4Address::GetZero();
  }
  
  return ipv4->GetAddress(1, 0).GetLocal();
}

uint32_t
BrokerApp::GetNodeIdFromIp(Ipv4Address address)
{
  for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
  {
    Ptr<Node> node = NodeList::GetNode(i);
    if (node)
    {
      Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
      if (ipv4 && ipv4->GetNInterfaces() > 1)
      {
        Ipv4Address addr = ipv4->GetAddress(1, 0).GetLocal();
        if (addr == address)
        {
          return i;
        }
      }
    }
  }
  
  return std::numeric_limits<uint32_t>::max(); // Not found
}

NotificationRecipient
BrokerApp::GetRecipientTypeFromNodeId(uint32_t nodeId)
{
  if (nodeId == s_publisherId) {
    return PUBLISHER_RECIPIENT;
  }
  else if (nodeId == s_subscriberId) {
    return SUBSCRIBER_RECIPIENT;
  }
  else {
    return OTHER_RECIPIENT;
  }
}

Ipv4Address
BrokerApp::FindPublisherAddress()
{
  if (s_publisherId < NodeList::GetNNodes())
  {
    return GetNodeAddress(s_publisherId);
  }
  
  for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
  {
    Ptr<Node> node = NodeList::GetNode(i);
    if (node && node->GetNApplications() > 0)
    {
      Ptr<BrokerApp> app = DynamicCast<BrokerApp>(node->GetApplication(0));
      if (app && app->GetNodeRole() == PUBLISHER)
      {
        s_publisherId = i; // Cache the publisher ID
        return GetNodeAddress(i);
      }
    }
  }
  
  return Ipv4Address::GetZero();
}

std::vector<Ipv4Address>
BrokerApp::FindAllSubscriberAddresses()
{
  std::vector<Ipv4Address> addresses;
  
  if (s_subscriberId < NodeList::GetNNodes())
  {
    Ipv4Address addr = GetNodeAddress(s_subscriberId);
    if (addr != Ipv4Address::GetZero())
    {
      addresses.push_back(addr);
      return addresses;
    }
  }
  
  for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
  {
    Ptr<Node> node = NodeList::GetNode(i);
    if (node && node->GetNApplications() > 0)
    {
      Ptr<BrokerApp> app = DynamicCast<BrokerApp>(node->GetApplication(0));
      if (app && app->GetNodeRole() == SUBSCRIBER)
      {
        s_subscriberId = i; // Cache the subscriber ID
        Ipv4Address addr = GetNodeAddress(i);
        if (addr != Ipv4Address::GetZero())
        {
          addresses.push_back(addr);
        }
      }
    }
  }
  
  return addresses;
}

bool
BrokerApp::NodeIsWithinRange(Ptr<Node> node1, Ptr<Node> node2)
{
  if (!node1 || !node2)
    return false;
  
  // Get node positions
  Ptr<MobilityModel> mobility1 = node1->GetObject<MobilityModel>();
  Ptr<MobilityModel> mobility2 = node2->GetObject<MobilityModel>();
  
  if (!mobility1 || !mobility2)
    return false;
  
  Vector pos1 = mobility1->GetPosition();
  Vector pos2 = mobility2->GetPosition();
  
  double distance = CalculateDistance(pos1, pos2);
  
  // Apply a small safety margin for static nodes
  if (IsNodeStatic(node1->GetId()) && IsNodeStatic(node2->GetId()))
  {
    return distance <= communicationRange * 1.1; // 10% margin for static nodes
  }
  
  return distance <= communicationRange;
}

bool
BrokerApp::IsNodeWithinRangeById(uint32_t nodeId1, uint32_t nodeId2)
{
  if (nodeId1 >= NodeList::GetNNodes() || nodeId2 >= NodeList::GetNNodes())
    return false;
    
  Ptr<Node> node1 = NodeList::GetNode(nodeId1);
  Ptr<Node> node2 = NodeList::GetNode(nodeId2);
  
  return NodeIsWithinRange(node1, node2);
}

Vector
BrokerApp::GetNodePosition(uint32_t nodeId)
{
  if (nodeId >= NodeList::GetNNodes())
    return Vector(0, 0, 0);
    
  Ptr<Node> node = NodeList::GetNode(nodeId);
  if (!node)
    return Vector(0, 0, 0);
    
  Ptr<MobilityModel> mobility = node->GetObject<MobilityModel>();
  if (!mobility)
    return Vector(0, 0, 0);
    
  return mobility->GetPosition();
}

double
BrokerApp::GetNodeSpeed(uint32_t nodeId)
{
  if (nodeId >= NodeList::GetNNodes())
    return 0.0;
    
  Ptr<Node> node = NodeList::GetNode(nodeId);
  if (!node)
    return 0.0;
    
  Ptr<MobilityModel> mobility = node->GetObject<MobilityModel>();
  if (!mobility)
    return 0.0;
    
  Vector velocity = mobility->GetVelocity();
  return std::sqrt(velocity.x * velocity.x + velocity.y * velocity.y + velocity.z * velocity.z);
}

bool
BrokerApp::IsNodeStatic(uint32_t nodeId)
{
  // Publisher is always static
  if (nodeId == s_publisherId)
    return true;
  
  // Subscriber is mobile
  if (nodeId == s_subscriberId)
    return false;
    
  // Check mobility model type
  if (nodeId < NodeList::GetNNodes())
  {
    Ptr<Node> node = NodeList::GetNode(nodeId);
    if (node)
    {
      Ptr<MobilityModel> mobility = node->GetObject<MobilityModel>();
      if (mobility)
      {
        // Check if it's a ConstantPositionMobilityModel or has zero velocity
        std::string modelName = mobility->GetInstanceTypeId().GetName();
        if (modelName == "ns3::ConstantPositionMobilityModel")
        {
          return true;
        }
        
        Vector velocity = mobility->GetVelocity();
        double speed = std::sqrt(velocity.x * velocity.x + velocity.y * velocity.y + velocity.z * velocity.z);
        return speed < 0.01; // Consider almost stationary nodes as static
      }
    }
  }
  
  // Default to assuming not static
  return false;
}

double
BrokerApp::CalculateDistance(Vector a, Vector b)
{
  // Calculate Euclidean distance
  double dx = a.x - b.x;
  double dy = a.y - b.y;
  double dz = a.z - b.z;
  
  return std::sqrt(dx*dx + dy*dy + dz*dz);
}

void
BrokerApp::LogNotificationEvent(const std::string& event, Time timestamp)
{
  std::ofstream eventLog;
  eventLog.open("aodv-notification-events.csv", std::ios::app);
  
  if (!eventLog.is_open())
  {
    NS_LOG_ERROR("Failed to open event log file");
    return;
  }
  
  // Write CSV format: time,nodeId,event,notificationType
  eventLog << timestamp.GetSeconds() << ","
           << GetNode()->GetId() << ","
           << event << ","
           << (int)m_lastNotificationMethod << std::endl;
  
  eventLog.close();
}

Time
BrokerApp::GetAverageNotificationDelay()
{
  if (s_notificationCount > 0)
  {
    return s_totalNotificationDelay / s_notificationCount;
  }
  return Time(0);
}

Time
BrokerApp::GetPublisherNotificationDelay()
{
  if (s_publisherNotificationCount > 0)
  {
    return s_publisherNotificationDelay / s_publisherNotificationCount;
  }
  return Time(0);
}

Time
BrokerApp::GetSubscriberNotificationDelay()
{
  if (s_subscriberNotificationCount > 0)
  {
    return s_subscriberNotificationDelay / s_subscriberNotificationCount;
  }
  return Time(0);
}

Time
BrokerApp::GetBroadcastNotificationDelay()
{
  if (s_broadcastNotificationCount > 0)
  {
    return s_broadcastNotificationDelay / s_broadcastNotificationCount;
  }
  return Time(0);
}

double
BrokerApp::GetAverageHopCount()
{
  if (s_notificationCount > 0)
  {
    return static_cast<double>(s_totalHops) / s_notificationCount;
  }
  return 0.0;
}

double
BrokerApp::GetMessageSuccessRate()
{
  if (s_messagesSent > 0)
  {
    return (double)s_messagesReceived / s_messagesSent;
  }
  return 0.0;
}

uint32_t
BrokerApp::GetMessagesSent()
{
  return s_messagesSent;
}

uint32_t
BrokerApp::GetMessagesReceived()
{
  return s_messagesReceived;
}

uint32_t
BrokerApp::GetOutOfRangeFailures()
{
  return s_outOfRangeFailures;
}

uint32_t 
BrokerApp::GetPublisherId()
{
  return s_publisherId;
}

uint32_t 
BrokerApp::GetSubscriberId()
{
  return s_subscriberId;
}

void 
BrokerApp::SetPublisherId(uint32_t id)
{
  s_publisherId = id;
}

void 
BrokerApp::SetSubscriberId(uint32_t id)
{
  s_subscriberId = id;
}

int main(int argc, char *argv[])
{
  // Enable logging
  LogComponentEnable("ImprovedAodvBrokerMigration", LOG_LEVEL_INFO);
  LogComponentEnable("AodvRoutingProtocol", LOG_LEVEL_WARN); // Reduce AODV protocol noise
  
  // Parse command line arguments
  CommandLine cmd;
  cmd.AddValue("numNodes", "Number of nodes", numNodes);
  cmd.AddValue("simTime", "Simulation time in seconds", simulationTime);
  cmd.AddValue("mobility", "Node mobility speed in m/s", nodeMobility);
  cmd.AddValue("detailLog", "Enable detailed logging", enableDetailedLogging);
  cmd.AddValue("commRange", "Communication range in meters", communicationRange);
  cmd.Parse(argc, argv);
  
  // Create new event log file
  std::ofstream eventLog;
  eventLog.open("aodv-notification-events.csv", std::ios::trunc);
  eventLog << "time,nodeId,event,notificationType" << std::endl;
  eventLog.close();
  
  // Create nodes
  NodeContainer nodes;
  nodes.Create(numNodes);
  
  // Store simulation parameters for delay scaling
  BrokerApp::SetSimulationParameters(nodeMobility, numNodes);
  
  // Set up WiFi with appropriate parameters
  WifiHelper wifi;
  wifi.SetStandard(WIFI_STANDARD_80211b);
  
  YansWifiPhyHelper wifiPhy;
  YansWifiChannelHelper wifiChannel = YansWifiChannelHelper::Default();
  wifiPhy.SetChannel(wifiChannel.Create());
  
  // Enhanced transmission parameters to match NDN implementation
  wifiPhy.Set("TxPowerStart", DoubleValue(16.0));
  wifiPhy.Set("TxPowerEnd", DoubleValue(16.0));
  wifiPhy.Set("TxGain", DoubleValue(12.0));
  wifiPhy.Set("RxGain", DoubleValue(12.0));
  
  // Adjust RX sensitivity to match communication range
  double adaptedRange = communicationRange * (1.0 - 0.05 * std::min(6.0, nodeMobility / 2.0));
  wifiPhy.Set("RxSensitivity", DoubleValue(-95.0 - (adaptedRange / 10.0)));
  
  NS_LOG_INFO("Mobility adjustment: Adapted range=" << adaptedRange << " m (original=" << communicationRange << " m)");
  
  WifiMacHelper wifiMac;
  wifiMac.SetType("ns3::AdhocWifiMac");
  
  NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, nodes);
  
  // Set up mobility model - only the subscriber moves
  MobilityHelper staticMobility;
  
  // Create grid positions for all nodes
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator>();
  
  double spacing = 50.0; // meters
  for (uint32_t i = 0; i < 7; i++)
  {
    for (uint32_t j = 0; j < 7; j++)
    {
      if (i * 7 + j < 49)
      {
        positionAlloc->Add(Vector(i * spacing, j * spacing, 0.0));
      }
    }
  }
  
  // Position node 50 in the center
  double maxPos = 3 * spacing;
  positionAlloc->Add(Vector(maxPos, maxPos, 0.0));
  
  // Apply static position to all nodes initially
  staticMobility.SetPositionAllocator(positionAlloc);
  staticMobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  staticMobility.Install(nodes);
  
  // Define node roles (same positions as in NDN implementation)
  uint32_t publisherId = 0;    // Grid top-left
  uint32_t subscriberId = 48;  // Grid bottom-right
  uint32_t brokerId = 24;      // Near center
  uint32_t newBrokerId = 25;   // Near original broker
  
  // Make only the subscriber node mobile
  Ptr<Node> subscriberNode = NodeList::GetNode(subscriberId);
  
  // Create a random walk mobility model for the subscriber
  Ptr<RandomWalk2dMobilityModel> subscriberMobModel = CreateObject<RandomWalk2dMobilityModel>();
  subscriberMobModel->SetAttribute("Mode", StringValue("Time"));
  subscriberMobModel->SetAttribute("Time", StringValue("1s"));
  subscriberMobModel->SetAttribute("Speed", StringValue("ns3::ConstantRandomVariable[Constant=" + std::to_string(nodeMobility) + "]"));
  subscriberMobModel->SetAttribute("Bounds", RectangleValue(Rectangle(0.0, 7*spacing, 0.0, 7*spacing)));
  
  // Install the mobility model on the subscriber
  subscriberNode->AggregateObject(subscriberMobModel);
  
  NS_LOG_INFO("Configured mobility: Subscriber (node " << subscriberId << ") moves at " 
              << nodeMobility << " m/s, all other nodes static");
  
  // Store the IDs globally (needed for static node optimization)
  BrokerApp::SetPublisherId(publisherId);
  BrokerApp::SetSubscriberId(subscriberId);
  
  // Install internet stack with AODV routing
  InternetStackHelper internet;
  AodvHelper aodv;
  
  // Configure AODV parameters based on mobility speed
  // Low mobility (< 2 m/s) - More relaxed parameters for stable networks
  if (nodeMobility < 2.0) {
    aodv.Set("ActiveRouteTimeout", TimeValue(Seconds(15.0)));
    aodv.Set("HelloInterval", TimeValue(Seconds(1.5)));
    aodv.Set("AllowedHelloLoss", UintegerValue(3));
    aodv.Set("NetDiameter", UintegerValue(35));
    
    // Slower path discovery for stable networks (saves overhead)
    aodv.Set("NodeTraversalTime", TimeValue(Seconds(0.05)));
    aodv.Set("NextHopWait", TimeValue(Seconds(0.1)));
    aodv.Set("PathDiscoveryTime", TimeValue(Seconds(0.5)));
  }
  // Medium mobility (2-4 m/s) - Default parameters
  else if (nodeMobility <= 4.0) {
    aodv.Set("ActiveRouteTimeout", TimeValue(Seconds(10.0)));
    aodv.Set("HelloInterval", TimeValue(Seconds(1.0)));
    aodv.Set("AllowedHelloLoss", UintegerValue(2));
    aodv.Set("NetDiameter", UintegerValue(25));
  }
  // High mobility (> 4 m/s) - Aggressive parameters for dynamic networks
  else {
    // Shorter timeouts for faster detection of broken links
    aodv.Set("ActiveRouteTimeout", TimeValue(Seconds(5.0)));
    aodv.Set("HelloInterval", TimeValue(Seconds(0.5)));
    aodv.Set("AllowedHelloLoss", UintegerValue(2));
    aodv.Set("NetDiameter", UintegerValue(15));
    
    // Faster path discovery for dynamic networks
    aodv.Set("NodeTraversalTime", TimeValue(Seconds(0.03)));
    aodv.Set("NextHopWait", TimeValue(Seconds(0.05)));
    aodv.Set("PathDiscoveryTime", TimeValue(Seconds(0.3)));
  }
  
  // Enable hello messages for maintaining connectivity
  aodv.Set("EnableHello", BooleanValue(true));
  
  internet.SetRoutingHelper(aodv);
  internet.Install(nodes);
  
  // Assign IP addresses
  Ipv4AddressHelper ipv4;
  ipv4.SetBase("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);
  
  // Create and install applications
  ApplicationContainer apps;
  
  for (uint32_t i = 0; i < numNodes; i++)
  {
    Ptr<BrokerApp> app = CreateObject<BrokerApp>();
    
    if (i == publisherId)
    {
      app->SetNodeRole(BrokerApp::PUBLISHER);
      app->SetCurrentBrokerId(brokerId);
      NS_LOG_INFO("Node " << i << " is publisher");
    }
    else if (i == subscriberId)
    {
      app->SetNodeRole(BrokerApp::SUBSCRIBER);
      app->SetCurrentBrokerId(brokerId);
      NS_LOG_INFO("Node " << i << " is subscriber");
    }
    else if (i == brokerId)
    {
      app->SetNodeRole(BrokerApp::BROKER);
      app->SetCurrentBrokerId(i);
      NS_LOG_INFO("Node " << i << " is broker");
    }
    else
    {
      app->SetNodeRole(BrokerApp::REGULAR);
    }
    
    nodes.Get(i)->AddApplication(app);
    app->SetStartTime(Seconds(1.0));
    app->SetStopTime(Seconds(simulationTime + 1.0));
    apps.Add(app);
  }
  
  // Schedule broker migration at 150 seconds (same as NDN implementation)
  Simulator::Schedule(Seconds(150.0), [&] {
    NS_LOG_INFO("Scheduled broker migration about to start: from node " 
                << brokerId << " to node " << newBrokerId);
    
    Ptr<BrokerApp> brokerApp = DynamicCast<BrokerApp>(nodes.Get(brokerId)->GetApplication(0));
    if (brokerApp)
    {
      NS_LOG_INFO("Executing broker migration");
      brokerApp->TriggerBrokerMigration(newBrokerId);
      NS_LOG_INFO("Broker migration scheduled");
    }
    else
    {
      NS_LOG_ERROR("Failed to get broker application");
    }
  });
  
  // Enable flow monitoring
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();
  
  // Enable animation
  AnimationInterface anim("improved-aodv-broker-migration.xml");
  
  // Run simulation
  NS_LOG_INFO("Running simulation for " << simulationTime << " seconds with subscriber mobility speed " << nodeMobility << " m/s");
  Simulator::Stop(Seconds(simulationTime));
  
  try
  {
    Simulator::Run();
  }
  catch (const std::exception& e)
  {
    NS_LOG_ERROR("Exception during simulation: " << e.what());
  }
  
  // Collect statistics
  monitor->CheckForLostPackets();
  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
  
  std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();
  
  NS_LOG_INFO("Flow statistics:");
  for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin(); i != stats.end(); i++)
  {
    Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
    NS_LOG_INFO("Flow " << i->first << " (" << t.sourceAddress << " -> " << t.destinationAddress << ")");
    NS_LOG_INFO("  Tx Packets: " << i->second.txPackets);
    NS_LOG_INFO("  Rx Packets: " << i->second.rxPackets);
    
    double duration = i->second.timeLastRxPacket.GetSeconds() - i->second.timeFirstTxPacket.GetSeconds();
    if (duration > 0)
    {
      NS_LOG_INFO("  Throughput: " << i->second.rxBytes * 8.0 / duration / 1024 << " Kbps");
    }
  }
  
  // Output AODV-specific results
  Time avgNotificationDelay = BrokerApp::GetAverageNotificationDelay();
  Time publisherDelay = BrokerApp::GetPublisherNotificationDelay();
  Time subscriberDelay = BrokerApp::GetSubscriberNotificationDelay();
  Time broadcastDelay = BrokerApp::GetBroadcastNotificationDelay();
  double messageSuccessRate = BrokerApp::GetMessageSuccessRate();
  double avgHopCount = BrokerApp::GetAverageHopCount();
  
  NS_LOG_INFO("=========== AODV Broker Migration Results ===========");
  NS_LOG_INFO("Mobility speed: " << nodeMobility << " m/s, Communication range: " << communicationRange << " m");
  NS_LOG_INFO("  Average Notification Delay: " << avgNotificationDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  Publisher Notification Delay: " << publisherDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  Subscriber Notification Delay: " << subscriberDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  Broadcast Notification Delay: " << broadcastDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  Average Hop Count: " << avgHopCount);
  NS_LOG_INFO("  Message Success Rate: " << messageSuccessRate * 100.0 << "%");
  NS_LOG_INFO("  Messages Sent: " << BrokerApp::GetMessagesSent());
  NS_LOG_INFO("  Messages Received: " << BrokerApp::GetMessagesReceived());
  NS_LOG_INFO("  Out of Range Failures: " << BrokerApp::GetOutOfRangeFailures());
  
  // Write results to CSV file - include mobility speed for easy comparison
  std::string filename = "aodv-results-mobility-" + std::to_string(int(nodeMobility)) + ".csv";
  std::ofstream resultFile;
  resultFile.open(filename.c_str());
  resultFile << "Metric,Value\n";
  resultFile << "MobilitySpeed," << nodeMobility << "\n";
  resultFile << "CommunicationRange," << communicationRange << "\n";
  resultFile << "AverageNotificationDelay," << avgNotificationDelay.GetSeconds() << "\n";
  resultFile << "PublisherNotificationDelay," << publisherDelay.GetSeconds() << " \n";
  resultFile << "SubscriberNotificationDelay," << subscriberDelay.GetSeconds() << "\n";
  resultFile << "BroadcastNotificationDelay," << broadcastDelay.GetSeconds() << "\n";
  resultFile << "AverageHopCount," << avgHopCount << "\n";
  resultFile << "MessageSuccessRate," << messageSuccessRate * 100.0 << "\n";
  resultFile << "MessagesSent," << BrokerApp::GetMessagesSent() << "\n";
  resultFile << "MessagesReceived," << BrokerApp::GetMessagesReceived() << "\n";
  resultFile << "OutOfRangeFailures," << BrokerApp::GetOutOfRangeFailures() << "\n";
  resultFile.close();
  
  NS_LOG_INFO("Results have been saved to " << filename);
  
  // Clean up
  Simulator::Destroy();
  
  return 0;
}