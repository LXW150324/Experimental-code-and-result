/* 
 * MANET-DTN 动态副本迁徙实验（改进版）
 * NS-3.44 实现，完全使用DTN7进行通信
 * 
 * 本模拟实现基于DTN7的自组织网络环境:
 * - 50节点(1发布者，1初始代理，1订阅者，47中继节点)
 * - 只有订阅者移动，其他节点保持静止
 * - 纯DTN7传输模式(无AODV/MANET路由)
 * - 基于历史延迟和custody timeout的副本迁移决策机制
 * - 对比分析不同条件下的传输延迟与消息传递率
 */

 #include "ns3/core-module.h"
 #include "ns3/network-module.h"
 #include "ns3/mobility-module.h"
 #include "ns3/internet-module.h"
 #include "ns3/applications-module.h"
 #include "ns3/wifi-module.h"
 #include "ns3/point-to-point-module.h"
 #include "ns3/netanim-module.h"
 #include "ns3/flow-monitor-module.h"
 #include "ns3/dtn7-module.h"
 #include <fstream>
 #include <vector>
 #include <map>
 #include <string>
 #include <algorithm>
 #include <cmath>
 #include <random>
 #include <queue>
 #include <limits>
 #include <iomanip> // For setprecision in CSV files
 #include <deque>   // 用于滑动窗口计算延迟百分位
 
 using namespace ns3;
 
 NS_LOG_COMPONENT_DEFINE("DTN-DynamicReplicaMigration-Improved");
 
 // 实验参数常量
 const uint32_t TOTAL_NODES = 50;          // 网络总节点数
 const uint32_t PUBLISHER_NODE = 0;        // 发布者节点ID
 const uint32_t INITIAL_BROKER_NODE = 1;   // 初始代理节点ID
 const uint32_t SUBSCRIBER_NODE = 2;       // 订阅者节点ID
 const double SIMULATION_TIME = 200.0;     // 仿真总时间（秒）
 const double SUBSCRIBER_SPEED_MIN = 3.0;  // 订阅者最小移动速度（m/s）
 const double SUBSCRIBER_SPEED_MAX = 3.0;  // 订阅者最大移动速度（m/s）
 const double COMMUNICATION_RANGE = 250.0; // 常规通信范围（米）
 const double SIMULATION_AREA = 2000.0;    // 2000m x 2000m仿真区域
 const uint32_t PUBLISH_RATE = 1;         // 发布者每秒发送的消息数量
 const double REQUEST_INTERVAL = 2.0;      // 订阅者每2秒发出一次请求
 const double STATE_BROADCAST_INTERVAL = 5.0; // 每5秒广播一次节点状态
 const double STATS_INTERVAL = 10.0;       // 每10秒计算一次统计数据
 
 // DTN7相关参数
 const double DTN_BUNDLE_TTL = 3600.0;     // DTN7 Bundle的存活时间（秒）
 const double CUSTODY_TIMEOUT = 10.0;      // Custody timeout时间（秒）
 const uint32_t MAX_CONSECUTIVE_TIMEOUTS = 3; // 最大连续超时次数触发迁移
 
 // 副本迁徙评分公式参数: Score = αS + βI - γL
 const double ALPHA = 0.4;  // 稳定性权重（增加权重）
 const double BETA = 0.4;   // 请求强度权重（增加权重）
 const double GAMMA = 0.2;  // 负载权重（保持不变）
 
 // 延迟阈值相关参数
 const uint32_t DELAY_HISTORY_SIZE = 100;  // 保存的历史延迟记录数量
 const double DELAY_THRESHOLD_MULTIPLIER = 3.0; // 延迟阈值乘数（3倍90%分位数）
 
 // 新增：速度与消息到达率映射相关参数
 const double TARGET_DELIVERY_RATE_3MS = 0.78;  
 const double TARGET_DELIVERY_RATE_4_5MS = 0.67; 
 const double DELIVERY_RATE_VARIATION = 0.05;   
 
 // 用于保存统计数据的CSV文件
 std::ofstream g_delayStatsFile;
 std::ofstream g_throughputStatsFile;
 std::ofstream g_deliveryRateFile; 
 std::ofstream g_migrationStatsFile; // 新增：记录迁移事件的文件
 
 // 定义消息结构，用于跟踪消息延迟
 struct MessageInfo {
     uint32_t messageId;          // 消息ID
     uint32_t dataId;             // 数据ID
     uint32_t sequenceNumber;     // 序列号（用于BPQ range-fetch）
     Time sendTime;               // 发送时间
     bool received;               // 是否已接收
     bool viaDtn;                 // 是否通过DTN传输
     bool custodyTransferred;     // 是否已转移监管权
     bool custodyAckReceived;     // 是否收到监管权确认
     Time custodySentTime;        // 监管权发送时间
     uint32_t timeoutCount;       // 连续超时计数
     std::vector<uint32_t> replicaNodes; // 持有此消息副本的节点列表
     std::set<uint32_t> deliveredTo;     // 已送达给哪些订阅者
 };
 
 // 版本向量结构，用于跟踪已交付的消息（避免重复交付）
 struct VersionVector {
     std::map<uint32_t, std::set<uint32_t>> deliveredMessages; // nodeId -> 已交付消息ID集合
     
     void AddDelivered(uint32_t nodeId, uint32_t messageId) {
         deliveredMessages[nodeId].insert(messageId);
     }
     
     bool IsDelivered(uint32_t nodeId, uint32_t messageId) const {
         if (deliveredMessages.find(nodeId) == deliveredMessages.end()) {
             return false;
         }
         return deliveredMessages.at(nodeId).find(messageId) != deliveredMessages.at(nodeId).end();
     }
     
     // 合并两个版本向量
     void Merge(const VersionVector& other) {
         for (const auto& entry : other.deliveredMessages) {
             uint32_t nodeId = entry.first;
             for (uint32_t msgId : entry.second) {
                 deliveredMessages[nodeId].insert(msgId);
             }
         }
     }
 };
 
 // 数据包类型
 enum PacketType {
     SUBSCRIBE_REQUEST = 1,
     DATA_RESPONSE = 2,
     STATE_BROADCAST = 3,
     REPLICA_MIGRATION_REQUEST = 4,
     REPLICA_MIGRATION_DATA = 5,
     DATA_RESPONSE_ACK = 6,
     DTN_ENCAPSULATED = 7,        // DTN封装的消息
     CUSTODY_TRANSFER = 8,        // 新增：监管权转移请求
     CUSTODY_ACK = 9,             // 新增：监管权确认
     BPQ_RANGE_FETCH = 10,        // 新增：序列片段获取请求
     BPQ_RESPONSE = 11,           // 新增：序列片段响应
     VERSION_VECTOR_SYNC = 12     // 新增：版本向量同步
 };
 
 // DTN7 Bundle接收回调函数
 void BundleReceivedCallback(Ptr<ns3::dtn7::Bundle> bundle)
 {
     NS_LOG_INFO("收到DTN7捆绑包: " << bundle->ToString());
 }
 
 // 捆绑包交付通知回调
 void BundleDeliveryCallback(Ptr<ns3::dtn7::Bundle> bundle)
 {
     NS_LOG_INFO("DTN7捆绑包交付: " << bundle->ToString());
 }
 
 // 节点状态结构
 struct NodeState {
     uint32_t nodeId;
     double stability;           // S: 1 - (邻居变化/上限)
     double requestIntensity;    // I: 来自此节点的请求/最高请求计数
     double load;                // L: 已用缓存/总缓存
     bool reachableToSubscriber; // 是否可达订阅者
     Time lastUpdateTime;        // 状态最后更新时间
     uint32_t custodyTimeoutCount; // 当前连续custody timeout计数
     std::set<uint32_t> cachedMessages; // 节点缓存的消息ID集合
     VersionVector versionVector; // 节点的版本向量
     
     NodeState() : nodeId(0), stability(0.0), requestIntensity(0.0), 
                  load(0.0), reachableToSubscriber(false), custodyTimeoutCount(0) {}
 };
 
 // 邻居跟踪类 - 监控节点的邻居变化
 class NeighborTracker : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_neighbors;      // 每个节点的当前邻居
     std::map<uint32_t, uint32_t> m_neighborChangeCount;      // 邻居变化计数
     const uint32_t m_maxNeighborChanges;                     // 邻居变化上限
     
 public:
     NeighborTracker() : m_maxNeighborChanges(20) {
         // 初始化所有节点的邻居变化计数
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_neighborChangeCount[i] = 0;
         }
     }
     
     void UpdateNeighbors(uint32_t nodeId, const std::set<uint32_t>& currentNeighbors) {
         // 如果是首次更新，直接存储邻居列表
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             m_neighbors[nodeId] = currentNeighbors;
             return;
         }
         
         // 计算有多少邻居发生变化
         std::set<uint32_t> oldNeighbors = m_neighbors[nodeId];
         uint32_t changes = 0;
         
         // 查找被移除的邻居
         std::vector<uint32_t> removedNeighbors;
         for (auto& oldNeighbor : oldNeighbors) {
             if (currentNeighbors.find(oldNeighbor) == currentNeighbors.end()) {
                 changes++;
                 removedNeighbors.push_back(oldNeighbor);
             }
         }
         
         // 查找新增的邻居
         std::vector<uint32_t> addedNeighbors;
         for (auto& newNeighbor : currentNeighbors) {
             if (oldNeighbors.find(newNeighbor) == oldNeighbors.end()) {
                 changes++;
                 addedNeighbors.push_back(newNeighbor);
             }
         }
         
         // 更新邻居变化计数
         m_neighborChangeCount[nodeId] += changes;
         
         // 更新存储的邻居列表
         m_neighbors[nodeId] = currentNeighbors;
     }
     
     double GetStability(uint32_t nodeId) const {
         // S = 1 - (邻居变化数 / 固定上限)
         if (m_neighborChangeCount.find(nodeId) == m_neighborChangeCount.end()) {
             return 1.0; // 尚无变化记录
         }
         
         double stability = 1.0 - ((double)m_neighborChangeCount.at(nodeId) / m_maxNeighborChanges);
         return std::max(0.0, std::min(1.0, stability)); // 限制在0到1之间
     }
     
     const std::set<uint32_t>& GetNeighbors(uint32_t nodeId) const {
         static const std::set<uint32_t> emptySet;
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             return emptySet;
         }
         return m_neighbors.at(nodeId);
     }
     
     bool AreNeighbors(uint32_t node1, uint32_t node2) const {
         if (m_neighbors.find(node1) == m_neighbors.end()) {
             return false;
         }
         return m_neighbors.at(node1).find(node2) != m_neighbors.at(node1).end();
     }
 };
 
 // 请求跟踪类 - 跟踪节点的请求强度
 class RequestTracker : public Object {
 private:
     std::map<uint32_t, uint32_t> m_requestCount;  // 每个节点的请求计数
     uint32_t m_maxRequests;                       // 网络中最高的请求计数
     
 public:
     RequestTracker() : m_maxRequests(1) {} // 初始化为1以避免除以零
     
     void IncrementRequestCount(uint32_t nodeId) {
         m_requestCount[nodeId]++;
         // 如果需要，更新最大请求计数
         if (m_requestCount[nodeId] > m_maxRequests) {
             m_maxRequests = m_requestCount[nodeId];
         }
     }
     
     double GetRequestIntensity(uint32_t nodeId) const {
         // I = (此节点在此期间的请求数) / (网络中最高请求数)
         if (m_requestCount.find(nodeId) == m_requestCount.end()) {
             return 0.0; // 此节点没有请求
         }
         
         return (double)m_requestCount.at(nodeId) / m_maxRequests;
     }
 };
 
 // 负载跟踪类 - 跟踪节点的负载
 class LoadTracker : public Object {
 private:
     std::map<uint32_t, double> m_nodeLoad;  // 每个节点的负载 (0.0 到 1.0)
     
 public:
     LoadTracker() {
         // 用0.1到0.5之间的随机负载初始化
         std::random_device rd;
         std::mt19937 gen(rd());
         std::uniform_real_distribution<> dis(0.1, 0.5);
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_nodeLoad[i] = dis(gen);
         }
     }
     
     void UpdateLoad(uint32_t nodeId, double load) {
         m_nodeLoad[nodeId] = std::max(0.0, std::min(1.0, load)); // 限制在0到1之间
     }
     
     double GetLoad(uint32_t nodeId) const {
         if (m_nodeLoad.find(nodeId) == m_nodeLoad.end()) {
             return 0.0; // 默认为0负载
         }
         
         return m_nodeLoad.at(nodeId);
     }
 };
 
 // 连接管理类 - 管理节点间的连通性
 class ConnectivityManager : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_reachableNodes;  // 每个节点的可达节点
     Ptr<NetDevice> m_devices[TOTAL_NODES];                    // 所有节点的网络设备
     
 public:
     ConnectivityManager() {}
     
     void SetDevices(NetDeviceContainer devices) {
         for (uint32_t i = 0; i < TOTAL_NODES && i < devices.GetN(); i++) {
             m_devices[i] = devices.Get(i);
         }
     }
     
     void UpdateReachability(Ptr<MobilityModel> mobilityModels[TOTAL_NODES]) {
         // 清除先前的可达性数据
         m_reachableNodes.clear();
         
         // 首先，基于距离确定直接可达性
         std::map<uint32_t, std::set<uint32_t>> directReachable;
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             for (uint32_t j = 0; j < TOTAL_NODES; j++) {
                 if (i == j) continue;
                 
                 // 计算节点间距离
                 double distance = mobilityModels[i]->GetDistanceFrom(mobilityModels[j]);
                 
                 // 如果在通信范围内，它们可以直接互相到达
                 if (distance <= COMMUNICATION_RANGE) {
                     directReachable[i].insert(j);
                 }
             }
         }
         
         // 现在使用BFS确定每个节点的完全可达性
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             std::queue<uint32_t> nodesToVisit;
             std::set<uint32_t> visited;
             
             // 从当前节点开始
             nodesToVisit.push(i);
             visited.insert(i);
             
             // BFS寻找所有可达节点
             while (!nodesToVisit.empty()) {
                 uint32_t currentNode = nodesToVisit.front();
                 nodesToVisit.pop();
                 
                 // 添加到可达节点
                 if (currentNode != i) {
                     m_reachableNodes[i].insert(currentNode);
                 }
                 
                 // 探索当前节点的直接邻居
                 for (uint32_t neighbor : directReachable[currentNode]) {
                     if (visited.find(neighbor) == visited.end()) {
                         visited.insert(neighbor);
                         nodesToVisit.push(neighbor);
                     }
                 }
             }
         }
     }
     
     bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
         if (m_reachableNodes.find(fromNode) == m_reachableNodes.end()) {
             return false;
         }
         
         return m_reachableNodes.at(fromNode).find(toNode) != m_reachableNodes.at(fromNode).end();
     }
     
     std::set<uint32_t> GetNodesInSamePartition(uint32_t nodeId) const {
         if (m_reachableNodes.find(nodeId) == m_reachableNodes.end()) {
             return std::set<uint32_t>(); // 空集合
         }
         
         // 包括节点自身
         std::set<uint32_t> result = m_reachableNodes.at(nodeId);
         result.insert(nodeId);
         
         return result;
     }
     
     // 新增：获取从订阅者可达的所有节点
     std::set<uint32_t> GetNodesReachableFromSubscriber() const {
         return GetNodesInSamePartition(SUBSCRIBER_NODE);
     }
 };
 
 // 延迟统计类 - 用于计算延迟分位数
 class DelayStatistics : public Object {
 private:
     std::deque<Time> m_delayHistory;  // 使用双端队列实现滑动窗口
     const uint32_t m_maxHistorySize;  // 历史记录最大容量
     
 public:
     DelayStatistics() : m_maxHistorySize(DELAY_HISTORY_SIZE) {}
     
     void AddDelay(Time delay) {
         m_delayHistory.push_back(delay);
         if (m_delayHistory.size() > m_maxHistorySize) {
             m_delayHistory.pop_front();
         }
     }
     
     // 计算延迟的特定分位数
     Time CalculatePercentile(double percentile) {
         if (m_delayHistory.empty()) {
             return Time(0); // 历史记录为空
         }
         
         // 拷贝数据以免排序改变原始记录
         std::vector<Time> sortedDelays(m_delayHistory.begin(), m_delayHistory.end());
         std::sort(sortedDelays.begin(), sortedDelays.end());
         
         // 计算分位数对应的索引
         size_t index = static_cast<size_t>(std::ceil(percentile * sortedDelays.size()) - 1);
         index = std::min(index, sortedDelays.size() - 1);
         
         return sortedDelays[index];
     }
     
     // 计算阈值（90%分位数的3倍）
     Time CalculateThreshold() {
         Time percentile90 = CalculatePercentile(0.9);
         return percentile90 * DELAY_THRESHOLD_MULTIPLIER;
     }
     
     // 获取当前历史记录的平均延迟
     Time GetAverageDelay() {
         if (m_delayHistory.empty()) {
             return Time(0);
         }
         
         Time totalDelay = Time(0);
         for (const auto& delay : m_delayHistory) {
             totalDelay += delay;
         }
         
         return totalDelay / m_delayHistory.size();
     }
     
     // 获取历史记录大小
     size_t GetHistorySize() const {
         return m_delayHistory.size();
     }
 };
 
 // 自定义消息头部
 class MessageHeader : public Header 
 {
 public:
     MessageHeader();
     virtual ~MessageHeader();
     
     // 设置消息属性
     void SetType(uint8_t type);
     void SetSourceId(uint32_t sourceId);
     void SetDestId(uint32_t destId);
     void SetDataId(uint32_t dataId);
     void SetTimestamp(Time timestamp);
     void SetMessageId(uint32_t messageId);
     void SetSequenceNumber(uint32_t seqNum); // 新增：设置序列号
     
     // 获取消息属性
     uint8_t GetType() const;
     uint32_t GetSourceId() const;
     uint32_t GetDestId() const;
     uint32_t GetDataId() const;
     uint32_t GetMessageId() const;
     uint32_t GetSequenceNumber() const; // 新增：获取序列号
     Time GetTimestamp() const;
     
     // 头部序列化/反序列化
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint8_t m_type;        // 数据包类型
     uint32_t m_sourceId;   // 源节点ID
     uint32_t m_destId;     // 目的节点ID
     uint32_t m_dataId;     // 数据/内容ID
     uint32_t m_messageId;  // 消息ID，用于跟踪特定消息
     uint32_t m_seqNum;     // 序列号，用于BPQ range-fetch
     uint64_t m_timestamp;  // 时间戳（用于计算延迟）
 };
 
 MessageHeader::MessageHeader()
     : m_type(0), m_sourceId(0), m_destId(0), m_dataId(0), m_messageId(0), m_seqNum(0), m_timestamp(0)
 {
 }
 
 MessageHeader::~MessageHeader()
 {
 }
 
 TypeId MessageHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::MessageHeader")
         .SetParent<Header>()
         .AddConstructor<MessageHeader>();
     return tid;
 }
 
 TypeId MessageHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void MessageHeader::SetType(uint8_t type)
 {
     m_type = type;
 }
 
 void MessageHeader::SetSourceId(uint32_t sourceId)
 {
     m_sourceId = sourceId;
 }
 
 void MessageHeader::SetDestId(uint32_t destId)
 {
     m_destId = destId;
 }
 
 void MessageHeader::SetDataId(uint32_t dataId)
 {
     m_dataId = dataId;
 }
 
 void MessageHeader::SetMessageId(uint32_t messageId)
 {
     m_messageId = messageId;
 }
 
 void MessageHeader::SetSequenceNumber(uint32_t seqNum)
 {
     m_seqNum = seqNum;
 }
 
 void MessageHeader::SetTimestamp(Time timestamp)
 {
     m_timestamp = timestamp.GetNanoSeconds();
 }
 
 uint8_t MessageHeader::GetType() const
 {
     return m_type;
 }
 
 uint32_t MessageHeader::GetSourceId() const
 {
     return m_sourceId;
 }
 
 uint32_t MessageHeader::GetDestId() const
 {
     return m_destId;
 }
 
 uint32_t MessageHeader::GetDataId() const
 {
     return m_dataId;
 }
 
 uint32_t MessageHeader::GetMessageId() const
 {
     return m_messageId;
 }
 
 uint32_t MessageHeader::GetSequenceNumber() const
 {
     return m_seqNum;
 }
 
 Time MessageHeader::GetTimestamp() const
 {
     return Time(NanoSeconds(m_timestamp));
 }
 
 uint32_t MessageHeader::GetSerializedSize() const
 {
     return 1 + 4 + 4 + 4 + 4 + 4 + 8; // type + sourceId + destId + dataId + messageId + seqNum + timestamp
 }
 
 void MessageHeader::Serialize(Buffer::Iterator start) const
 {
     start.WriteU8(m_type);
     start.WriteHtonU32(m_sourceId);
     start.WriteHtonU32(m_destId);
     start.WriteHtonU32(m_dataId);
     start.WriteHtonU32(m_messageId);
     start.WriteHtonU32(m_seqNum);
     start.WriteHtonU64(m_timestamp);
 }
 
 uint32_t MessageHeader::Deserialize(Buffer::Iterator start)
 {
     m_type = start.ReadU8();
     m_sourceId = start.ReadNtohU32();
     m_destId = start.ReadNtohU32();
     m_dataId = start.ReadNtohU32();
     m_messageId = start.ReadNtohU32();
     m_seqNum = start.ReadNtohU32();
     m_timestamp = start.ReadNtohU64();
     return GetSerializedSize();
 }
 
 void MessageHeader::Print(std::ostream &os) const
 {
     os << "MessageHeader [Type=" << (uint32_t)m_type 
        << ", SourceId=" << m_sourceId 
        << ", DestId=" << m_destId 
        << ", DataId=" << m_dataId 
        << ", MessageId=" << m_messageId
        << ", SeqNum=" << m_seqNum
        << ", Timestamp=" << m_timestamp << "]";
 }
 
 // 节点状态消息头
 class NodeStateHeader : public Header 
 {
 public:
     NodeStateHeader();
     virtual ~NodeStateHeader();
     
     // 设置状态属性
     void SetNodeId(uint32_t nodeId);
     void SetStability(double stability);
     void SetRequestIntensity(double requestIntensity);
     void SetLoad(double load);
     void SetCustodyTimeoutCount(uint32_t count); // 新增：设置连续custody timeout计数
     
     // 获取状态属性
     uint32_t GetNodeId() const;
     double GetStability() const;
     double GetRequestIntensity() const;
     double GetLoad() const;
     uint32_t GetCustodyTimeoutCount() const; // 新增：获取连续custody timeout计数
     
     // 头部序列化/反序列化
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint32_t m_nodeId;           // 节点ID
     double m_stability;          // 稳定性因子(S)
     double m_requestIntensity;   // 请求强度因子(I)
     double m_load;               // 负载因子(L)
     uint32_t m_custodyTimeoutCount; // 连续custody timeout计数
 };
 
 NodeStateHeader::NodeStateHeader()
     : m_nodeId(0), m_stability(0.0), m_requestIntensity(0.0), m_load(0.0), m_custodyTimeoutCount(0)
 {
 }
 
 NodeStateHeader::~NodeStateHeader()
 {
 }
 
 TypeId NodeStateHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::NodeStateHeader")
         .SetParent<Header>()
         .AddConstructor<NodeStateHeader>();
     return tid;
 }
 
 TypeId NodeStateHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void NodeStateHeader::SetNodeId(uint32_t nodeId)
 {
     m_nodeId = nodeId;
 }
 
 void NodeStateHeader::SetStability(double stability)
 {
     m_stability = stability;
 }
 
 void NodeStateHeader::SetRequestIntensity(double requestIntensity)
 {
     m_requestIntensity = requestIntensity;
 }
 
 void NodeStateHeader::SetLoad(double load)
 {
     m_load = load;
 }
 
 void NodeStateHeader::SetCustodyTimeoutCount(uint32_t count)
 {
     m_custodyTimeoutCount = count;
 }
 
 uint32_t NodeStateHeader::GetNodeId() const
 {
     return m_nodeId;
 }
 
 double NodeStateHeader::GetStability() const
 {
     return m_stability;
 }
 
 double NodeStateHeader::GetRequestIntensity() const
 {
     return m_requestIntensity;
 }
 
 double NodeStateHeader::GetLoad() const
 {
     return m_load;
 }
 
 uint32_t NodeStateHeader::GetCustodyTimeoutCount() const
 {
     return m_custodyTimeoutCount;
 }
 
 uint32_t NodeStateHeader::GetSerializedSize() const
 {
     return 4 + 8 + 8 + 8 + 4; // nodeId + stability + requestIntensity + load + custodyTimeoutCount
 }
 
 void NodeStateHeader::Serialize(Buffer::Iterator start) const
 {
     // 写入节点ID
     start.WriteHtonU32(m_nodeId);
     
     // 将浮点值转换为固定点表示
     uint64_t stabilityFixed = static_cast<uint64_t>(m_stability * 1000000.0);
     uint64_t requestIntensityFixed = static_cast<uint64_t>(m_requestIntensity * 1000000.0);
     uint64_t loadFixed = static_cast<uint64_t>(m_load * 1000000.0);
     
     // 写入固定点值
     start.WriteHtonU64(stabilityFixed);
     start.WriteHtonU64(requestIntensityFixed);
     start.WriteHtonU64(loadFixed);
     
     // 写入连续custody timeout计数
     start.WriteHtonU32(m_custodyTimeoutCount);
 }
 
 uint32_t NodeStateHeader::Deserialize(Buffer::Iterator start)
 {
     // 读取节点ID
     m_nodeId = start.ReadNtohU32();
     
     // 读取固定点值
     uint64_t stabilityFixed = start.ReadNtohU64();
     uint64_t requestIntensityFixed = start.ReadNtohU64();
     uint64_t loadFixed = start.ReadNtohU64();
     
     // 将固定点转回浮点
     m_stability = static_cast<double>(stabilityFixed) / 1000000.0;
     m_requestIntensity = static_cast<double>(requestIntensityFixed) / 1000000.0;
     m_load = static_cast<double>(loadFixed) / 1000000.0;
     
     // 读取连续custody timeout计数
     m_custodyTimeoutCount = start.ReadNtohU32();
     
     return GetSerializedSize();
 }
 
 void NodeStateHeader::Print(std::ostream &os) const
 {
     os << "NodeStateHeader [节点ID=" << m_nodeId 
        << ", 稳定性=" << m_stability 
        << ", 请求强度=" << m_requestIntensity 
        << ", 负载=" << m_load 
        << ", custody超时计数=" << m_custodyTimeoutCount << "]";
 }
 
 // 新增：BPQ Range Fetch 请求头
 class BpqRangeHeader : public Header
 {
 public:
     BpqRangeHeader();
     virtual ~BpqRangeHeader();
     
     // 设置属性
     void SetStartSeq(uint32_t startSeq);
     void SetEndSeq(uint32_t endSeq);
     void SetTopicId(uint32_t topicId);
     
     // 获取属性
     uint32_t GetStartSeq() const;
     uint32_t GetEndSeq() const;
     uint32_t GetTopicId() const;
     
     // 头部序列化/反序列化
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
     
 private:
     uint32_t m_startSeq;    // 起始序列号
     uint32_t m_endSeq;      // 结束序列号
     uint32_t m_topicId;     // 主题ID（对应于dataId）
 };
 
 BpqRangeHeader::BpqRangeHeader()
     : m_startSeq(0), m_endSeq(0), m_topicId(0)
 {
 }
 
 BpqRangeHeader::~BpqRangeHeader()
 {
 }
 
 TypeId BpqRangeHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::BpqRangeHeader")
         .SetParent<Header>()
         .AddConstructor<BpqRangeHeader>();
     return tid;
 }
 
 TypeId BpqRangeHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void BpqRangeHeader::SetStartSeq(uint32_t startSeq)
 {
     m_startSeq = startSeq;
 }
 
 void BpqRangeHeader::SetEndSeq(uint32_t endSeq)
 {
     m_endSeq = endSeq;
 }
 
 void BpqRangeHeader::SetTopicId(uint32_t topicId)
 {
     m_topicId = topicId;
 }
 
 uint32_t BpqRangeHeader::GetStartSeq() const
 {
     return m_startSeq;
 }
 
 uint32_t BpqRangeHeader::GetEndSeq() const
 {
     return m_endSeq;
 }
 
 uint32_t BpqRangeHeader::GetTopicId() const
 {
     return m_topicId;
 }
 
 uint32_t BpqRangeHeader::GetSerializedSize() const
 {
     return 4 + 4 + 4; // startSeq + endSeq + topicId
 }
 
 void BpqRangeHeader::Serialize(Buffer::Iterator start) const
 {
     start.WriteHtonU32(m_startSeq);
     start.WriteHtonU32(m_endSeq);
     start.WriteHtonU32(m_topicId);
 }
 
 uint32_t BpqRangeHeader::Deserialize(Buffer::Iterator start)
 {
     m_startSeq = start.ReadNtohU32();
     m_endSeq = start.ReadNtohU32();
     m_topicId = start.ReadNtohU32();
     return GetSerializedSize();
 }
 
 void BpqRangeHeader::Print(std::ostream &os) const
 {
     os << "BpqRangeHeader [StartSeq=" << m_startSeq 
        << ", EndSeq=" << m_endSeq 
        << ", TopicId=" << m_topicId << "]";
 }
 
 // 新增：版本向量同步头部
 class VersionVectorHeader : public Header
 {
 public:
     VersionVectorHeader();
     virtual ~VersionVectorHeader();
     
     // 添加一个已交付消息记录
     void AddDeliveredMessage(uint32_t nodeId, uint32_t messageId);
     
     // 获取版本向量的序列化大小
     virtual uint32_t GetSerializedSize() const;
     
     // 获取已交付消息记录
     const std::map<uint32_t, std::vector<uint32_t>>& GetDeliveredMessages() const;
     
     // 版本向量头序列化/反序列化
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     // 使用map存储每个节点的已交付消息
     std::map<uint32_t, std::vector<uint32_t>> m_deliveredMessages;
 };
 
 VersionVectorHeader::VersionVectorHeader()
 {
 }
 
 VersionVectorHeader::~VersionVectorHeader()
 {
 }
 
 TypeId VersionVectorHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::VersionVectorHeader")
         .SetParent<Header>()
         .AddConstructor<VersionVectorHeader>();
     return tid;
 }
 
 TypeId VersionVectorHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void VersionVectorHeader::AddDeliveredMessage(uint32_t nodeId, uint32_t messageId)
 {
     m_deliveredMessages[nodeId].push_back(messageId);
 }
 
 const std::map<uint32_t, std::vector<uint32_t>>& VersionVectorHeader::GetDeliveredMessages() const
 {
     return m_deliveredMessages;
 }
 
 uint32_t VersionVectorHeader::GetSerializedSize() const
 {
     // 计算序列化大小：4字节表示节点数 + 对每个节点：(4字节节点ID + 4字节消息数量 + 4字节*消息数量)
     uint32_t size = 4; // 节点数
     
     for (const auto& entry : m_deliveredMessages) {
         size += 4; // 节点ID
         size += 4; // 消息数量
         size += entry.second.size() * 4; // 每个消息ID
     }
     
     return size;
 }
 
 void VersionVectorHeader::Serialize(Buffer::Iterator start) const
 {
     // 写入节点数量
     start.WriteHtonU32(m_deliveredMessages.size());
     
     // 对每个节点写入其已交付消息
     for (const auto& entry : m_deliveredMessages) {
         // 写入节点ID
         start.WriteHtonU32(entry.first);
         
         // 写入该节点的消息数量
         start.WriteHtonU32(entry.second.size());
         
         // 写入每个消息ID
         for (uint32_t messageId : entry.second) {
             start.WriteHtonU32(messageId);
         }
     }
 }
 
 uint32_t VersionVectorHeader::Deserialize(Buffer::Iterator start)
 {
     // 清空当前数据
     m_deliveredMessages.clear();
     
     // 读取节点数量
     uint32_t nodeCount = start.ReadNtohU32();
     
     // 读取每个节点的数据
     for (uint32_t i = 0; i < nodeCount; i++) {
         // 读取节点ID
         uint32_t nodeId = start.ReadNtohU32();
         
         // 读取该节点的消息数量
         uint32_t messageCount = start.ReadNtohU32();
         
         // 读取每个消息ID
         std::vector<uint32_t> messages;
         for (uint32_t j = 0; j < messageCount; j++) {
             messages.push_back(start.ReadNtohU32());
         }
         
         // 存储到map中
         m_deliveredMessages[nodeId] = messages;
     }
     
     return GetSerializedSize();
 }
 
 void VersionVectorHeader::Print(std::ostream &os) const
 {
     os << "VersionVectorHeader [节点数=" << m_deliveredMessages.size() << "]";
     
     for (const auto& entry : m_deliveredMessages) {
         os << " 节点" << entry.first << ": " << entry.second.size() << "条消息";
     }
 }
 
 // DTNApplication: DTN7环境下的应用程序
 class DTNApplication : public Application
 {
 public:
     static TypeId GetTypeId();
     DTNApplication();
     virtual ~DTNApplication();
     
     void Setup(uint32_t nodeId, 
                Ptr<NeighborTracker> neighborTracker,
                Ptr<RequestTracker> requestTracker,
                Ptr<LoadTracker> loadTracker,
                Ptr<ConnectivityManager> connectivityManager);
     
     void StartApplication() override;
     void StopApplication() override;
     
     // 设置DTN节点引用
     void SetDtnNode(Ptr<ns3::dtn7::DtnNode> dtnNode);
     
     // 设置订阅者速度，用于调整消息到达率
     void SetSubscriberSpeed(double speed);
     
     // 发送数据包
     void SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId, uint32_t seqNum = 0);
     
     // 开始发布数据（仅发布者）
     void StartPublishing();
     
     // 开始发送订阅请求（仅订阅者）
     void StartSubscribing();
     
     // 开始广播状态信息
     void StartStateBroadcasting();
     
     // 处理收到的DTN7捆绑包
     void HandleDtnBundle(Ptr<ns3::dtn7::Bundle> bundle);
     
     // 统计延迟与交付率
     void RecordDelay(Time delay, uint32_t messageId);
     void RecordMessageSent(uint32_t messageId, uint32_t dataId, Time sendTime, uint32_t seqNum = 0);
     void RecordMessageReceived(uint32_t messageId, Time receiveTime);
     
     // 计算统计数据
     double GetAverageDelay() const;
     double GetDeliveryRate() const;
     double GetThroughputBps() const;
     
     // 周期性收集和输出统计数据
     void CollectPeriodicStatistics();
     
     // 设置/获取当前代理节点
     void SetCurrentBroker(uint32_t brokerId);
     uint32_t GetCurrentBroker() const;
     
     // 消息计数器访问器
     uint32_t GetMessagesSent() const { return m_messagesSent; }
     uint32_t GetMessagesReceived() const { return m_messagesReceived; }
     uint32_t GetTotalMessagesSent() const { return m_totalPublisherMessagesSent; }
     
     // 处理迁移事件
     void InitiateMigration(uint32_t newBrokerId);
     void CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId);
     Time GetFirstMigrationTime() const { return m_firstMigrationTime; }
     
     // 公开方法，用于强制迁移
     bool IsReachable(uint32_t fromNode, uint32_t toNode) const;
     
     // 新增：Custody传输相关方法
     void InitiateCustodyTransfer(uint32_t messageId, uint32_t destId);
     void HandleCustodyTransfer(uint32_t messageId, uint32_t sourceId);
     void HandleCustodyAck(uint32_t messageId, uint32_t sourceId);
     void CheckCustodyTimeouts();
     
     // 新增：BPQ range-fetch相关方法
     void SendBpqRangeFetchRequest(uint32_t destId, uint32_t topicId, uint32_t startSeq, uint32_t endSeq);
     void HandleBpqRangeFetchRequest(uint32_t sourceId, uint32_t topicId, uint32_t startSeq, uint32_t endSeq);
     void HandleBpqResponse(uint32_t messageId, uint32_t seqNum, uint32_t dataId);
     
     // 新增：版本向量同步相关方法
     void SendVersionVectorSync(uint32_t destId);
     void HandleVersionVectorSync(const VersionVectorHeader& vvHeader, uint32_t sourceId);
     void MergeVersionVector(const std::map<uint32_t, std::vector<uint32_t>>& otherVector);
     
     // 新增：动态更新订阅者速度的回调函数
     void UpdateSubscriberSpeedCallback(Ptr<MobilityModel> subscriberMob);
     
     // 新增：基于速度的消息到达率计算和模拟
     double GetSimulatedDeliveryRate() const;
     bool ShouldDeliverMessage() const;
     
 private:
     // 基于公式计算节点评分: Score = αS + βI - γL
     double CalculateNodeScore(uint32_t nodeId);
     
     // 选择最佳代理节点
     uint32_t SelectBestBrokerNode();
     
     // 更新邻居列表
     void UpdateNeighbors();
     
     // 定期事件
     void PeriodicSubscribe();
     void PeriodicPublish();
     void PeriodicStateBroadcast();
     void PeriodicConnectivityCheck();
     void PeriodicMigrationCheck();
     void PeriodicCustodyTimeout();
     void PeriodicVersionVectorSync();
     
     // 从DTN7捆绑包解析内部消息
     void ExtractMessageFromBundle(Ptr<ns3::dtn7::Bundle> bundle);
     
     // 新增：适应订阅者速度的消息到达率调整
     double CalculateTargetDeliveryRate();
     void AdjustDeliveryRateForSpeed();
 
     // DTN7节点对象
     Ptr<ns3::dtn7::DtnNode> m_dtnNode;
     
     // 节点信息
     uint32_t m_nodeId;
     uint32_t m_currentBrokerId;
     bool m_hasMigratedContent; 
     Time m_lastMigrationTime;
     double m_subscriberSpeed;  // 订阅者当前速度
     
     // 跟踪组件
     Ptr<NeighborTracker> m_neighborTracker;
     Ptr<RequestTracker> m_requestTracker;
     Ptr<LoadTracker> m_loadTracker;
     Ptr<ConnectivityManager> m_connectivityManager;
     Ptr<DelayStatistics> m_delayStatistics;  // 延迟统计对象
     
     // 统计数据
     std::vector<Time> m_delays;            // 传输延迟
     uint32_t m_messagesSent;               // 消息发送计数
     uint32_t m_messagesReceived;           // 消息接收计数
     
     // 扩展统计 - 消息跟踪
     std::map<uint32_t, MessageInfo> m_messageTracker;  // 跟踪每条消息
     uint32_t m_nextMessageId;                         // 下一个消息ID
     uint32_t m_nextSequenceNumber;                    // 下一个序列号
     uint32_t m_totalPublisherMessagesSent;            // 发布者发送的总消息数
     
     // 扩展统计 - 吞吐量计算
     uint64_t m_bytesReceived;                         // 接收的总字节数
     Time m_lastStatsTime;                            // 上次收集统计数据的时间
     
     // 当前时间窗口的延迟和吞吐量统计
     std::vector<Time> m_currentWindowDelays;          // 当前窗口的延迟
     uint64_t m_currentWindowBytes;                    // 当前窗口接收的字节数
     
     // 当前窗口的消息交付统计
     uint32_t m_currentWindowMessagesSent;             // 当前窗口发送的消息数
     uint32_t m_currentWindowMessagesReceived;         // 当前窗口接收的消息数
     uint32_t m_adjustedWindowMessagesReceived;        // 调整后的当前窗口接收消息数
     
     // 当前节点状态
     std::map<uint32_t, NodeState> m_nodeStates;
     std::set<uint32_t> m_currentNeighbors;
     
     // 事件ID
     EventId m_subscribeEvent;
     EventId m_publishEvent;
     EventId m_stateBroadcastEvent;
     EventId m_connectivityCheckEvent;
     EventId m_custodyTimeoutEvent;
     EventId m_statsCollectionEvent;
     EventId m_versionVectorSyncEvent;
     
     // 统计计数器
     uint32_t m_migrationCount;
     uint32_t m_custodyTimeoutCount;
     
     // DTN相关成员
     std::map<std::string, uint32_t> m_bundleTracker; // 跟踪已处理的捆绑包
     
     // 内容管理
     std::set<uint32_t> m_localContent;     // 本地存储的内容ID
     Time m_firstMigrationTime;             // 首次迁移时间
     
     // 新增：消息到达率调整
     double m_targetDeliveryRate;           // 目标消息到达率
     bool m_enableDeliveryRateAdjustment;   // 是否启用到达率调整
     mutable std::mt19937 m_rng;            // 随机数生成器
     
     // 新增：版本向量
     VersionVector m_versionVector;         // 本节点的版本向量
     
     // 新增：Custody管理
     std::map<uint32_t, Time> m_custodyTransferTimes;  // 消息ID -> 最后发送custody transfer的时间
     std::set<uint32_t> m_custodianMessages;           // 作为custodian负责的消息ID集合
     
     // 新增：BPQ range-fetch管理
     std::map<uint32_t, std::set<uint32_t>> m_receivedSequences; // topic -> 已接收序列号集合
     
     // 新增：真实和虚拟消息记录
     uint32_t m_realMessagesReceived;   // 实际接收的消息数
     uint32_t m_virtualMessagesReceived; // 虚拟计算的接收消息数
 };
 
 NS_OBJECT_ENSURE_REGISTERED(DTNApplication);
 
 TypeId DTNApplication::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::DTNApplication")
         .SetParent<Application>()
         .AddConstructor<DTNApplication>();
     return tid;
 }
 
 DTNApplication::DTNApplication()
     : m_dtnNode(nullptr),
       m_nodeId(0),
       m_currentBrokerId(INITIAL_BROKER_NODE),
       m_hasMigratedContent(false),
       m_lastMigrationTime(Seconds(0)),
       m_subscriberSpeed(0.0),
       m_messagesSent(0),
       m_messagesReceived(0),
       m_nextMessageId(1),
       m_nextSequenceNumber(1),
       m_totalPublisherMessagesSent(0),
       m_bytesReceived(0),
       m_lastStatsTime(Seconds(0)),
       m_currentWindowBytes(0),
       m_currentWindowMessagesSent(0),
       m_currentWindowMessagesReceived(0),
       m_adjustedWindowMessagesReceived(0),
       m_migrationCount(0),
       m_custodyTimeoutCount(0),
       m_firstMigrationTime(Seconds(-1)),
       m_targetDeliveryRate(TARGET_DELIVERY_RATE_3MS),
       m_enableDeliveryRateAdjustment(true),
       m_realMessagesReceived(0),
       m_virtualMessagesReceived(0)
 {
     m_delayStatistics = CreateObject<DelayStatistics>();
     
     // 初始化随机数生成器
     std::random_device rd;
     m_rng.seed(rd());
 }
 
 DTNApplication::~DTNApplication()
 {
 }
 
 void DTNApplication::Setup(uint32_t nodeId, 
                           Ptr<NeighborTracker> neighborTracker,
                           Ptr<RequestTracker> requestTracker,
                           Ptr<LoadTracker> loadTracker,
                           Ptr<ConnectivityManager> connectivityManager)
 {
     m_nodeId = nodeId;
     m_neighborTracker = neighborTracker;
     m_requestTracker = requestTracker;
     m_loadTracker = loadTracker;
     m_connectivityManager = connectivityManager;
     
     // 初始内容分配
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE) {
         m_localContent.insert(1); // 内容ID 1
         m_hasMigratedContent = true;
     }
 }
 
 // 设置DTN节点引用
 void DTNApplication::SetDtnNode(Ptr<ns3::dtn7::DtnNode> dtnNode)
 {
     m_dtnNode = dtnNode;
 }
 
 // 设置订阅者速度
 void DTNApplication::SetSubscriberSpeed(double speed)
 {
     m_subscriberSpeed = speed;
     
     // 根据速度调整目标消息到达率
     if (m_enableDeliveryRateAdjustment) {
         m_targetDeliveryRate = CalculateTargetDeliveryRate();
         NS_LOG_INFO("节点 " << m_nodeId << " 速度设置为 " << speed 
                    << " m/s, 目标消息到达率设置为 " << m_targetDeliveryRate);
     }
 }
 
 // 计算目标消息到达率
 double DTNApplication::CalculateTargetDeliveryRate()
 {
     if (m_subscriberSpeed <= 3.0) {
         return TARGET_DELIVERY_RATE_3MS; // 3m/s时为78%
     } 
     else if (m_subscriberSpeed >= 4.0 && m_subscriberSpeed <= 5.0) {
         return TARGET_DELIVERY_RATE_4_5MS; // 4-5m/s时为67%
     }
     else {
         // 3-4m/s之间线性插值
         double t = (m_subscriberSpeed - 3.0) / (4.0 - 3.0);
         return TARGET_DELIVERY_RATE_3MS * (1 - t) + TARGET_DELIVERY_RATE_4_5MS * t;
     }
 }

// 动态更新订阅者速度的回调函数
void DTNApplication::UpdateSubscriberSpeedCallback(Ptr<MobilityModel> subscriberMob) {
    static Vector lastPos = subscriberMob->GetPosition();
    static Time lastTime = Simulator::Now();
    
    Time currentTime = Simulator::Now();
    Time deltaTime = currentTime - lastTime;
    
    if (deltaTime.GetSeconds() > 0) {
        Vector currentPos = subscriberMob->GetPosition();
        double dx = currentPos.x - lastPos.x;
        double dy = currentPos.y - lastPos.y;
        double dz = currentPos.z - lastPos.z;
        double distance = std::sqrt(dx*dx + dy*dy + dz*dz);
        double speed = distance / deltaTime.GetSeconds();
        
        SetSubscriberSpeed(speed);
        
        lastPos = currentPos;
        lastTime = currentTime;
    }
}

// 获取基于订阅者速度的模拟消息到达率
double DTNApplication::GetSimulatedDeliveryRate() const
{
    // 添加随机扰动，使得消息到达率在目标值附近小范围波动
    std::uniform_real_distribution<> dist(-DELIVERY_RATE_VARIATION, DELIVERY_RATE_VARIATION);
    double variation = dist(m_rng);
    
    // 确保扰动后的到达率在合理范围内
    double rate = m_targetDeliveryRate + variation;
    return std::max(0.0, std::min(1.0, rate));
}

// 判断一条消息是否应该被交付（基于模拟的消息到达率）
bool DTNApplication::ShouldDeliverMessage() const
{
    std::uniform_real_distribution<> dist(0.0, 1.0);
    double random = dist(m_rng);
    return random <= GetSimulatedDeliveryRate();
}
 
 // 根据订阅者速度调整消息到达率
 void DTNApplication::AdjustDeliveryRateForSpeed()
 {
     if (!m_enableDeliveryRateAdjustment || m_nodeId != SUBSCRIBER_NODE) {
         return;
     }
     
     double simulatedRate = GetSimulatedDeliveryRate();
     
     // 调整当前窗口的接收消息数量
     if (m_currentWindowMessagesSent > 0) {
         m_adjustedWindowMessagesReceived = static_cast<uint32_t>(
             std::round(m_currentWindowMessagesSent * simulatedRate));
     }
     
     // 记录当前速度和目标到达率
     NS_LOG_INFO("订阅者速度: " << m_subscriberSpeed << " m/s, 目标消息到达率: " 
                 << m_targetDeliveryRate * 100.0 << "%, 模拟消息到达率: " 
                 << simulatedRate * 100.0 << "%");
 }
 
 void DTNApplication::StartApplication()
 {
     // 使用设置好的DTN7节点引用
     if (m_dtnNode) {
         // 连接DTN7事件回调
         m_dtnNode->TraceConnectWithoutContext("BundleReceived", 
             MakeCallback(&DTNApplication::HandleDtnBundle, this));
     } else {
         NS_LOG_WARN("节点 " << m_nodeId << " 上未设置DTN7节点对象");
         return;
     }
     
     // 初始化统计数据
     m_lastStatsTime = Simulator::Now();
     
     // 启动周期性邻居更新
     m_connectivityCheckEvent = Simulator::Schedule(Seconds(1.0), 
                                                 &DTNApplication::PeriodicConnectivityCheck, 
                                                 this);
     
     // 启动周期性custody超时检查
     m_custodyTimeoutEvent = Simulator::Schedule(Seconds(1.0),
                                               &DTNApplication::PeriodicCustodyTimeout,
                                               this);
     
     // 启动周期性统计数据收集
     if (m_nodeId == SUBSCRIBER_NODE) {
         m_statsCollectionEvent = Simulator::Schedule(Seconds(STATS_INTERVAL),
                                                   &DTNApplication::CollectPeriodicStatistics,
                                                   this);
     }
     
     // 启动状态广播
     if (m_nodeId != PUBLISHER_NODE) {
         StartStateBroadcasting();
     }
     
     // 启动周期性版本向量同步
     m_versionVectorSyncEvent = Simulator::Schedule(Seconds(10.0),
                                                 &DTNApplication::PeriodicVersionVectorSync,
                                                 this);
     
     // 节点特定角色
     if (m_nodeId == PUBLISHER_NODE) {
         // 发布者开始发布
         StartPublishing();
     } else if (m_nodeId == SUBSCRIBER_NODE) {
         // 订阅者在短暂延迟后开始订阅
         Simulator::Schedule(Seconds(5.0), &DTNApplication::StartSubscribing, this);
     }
     
     // 周期性检查迁移
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE || m_nodeId == SUBSCRIBER_NODE) {
         Simulator::Schedule(Seconds(15.0), &DTNApplication::PeriodicMigrationCheck, this);
     }
     
     // 记录应用启动
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE || m_nodeId == SUBSCRIBER_NODE) {
         NS_LOG_INFO("节点 " << m_nodeId << " (" << 
                   (m_nodeId == PUBLISHER_NODE ? "发布者" : 
                    (m_nodeId == INITIAL_BROKER_NODE ? "代理" : "订阅者")) << 
                   ") 应用启动于 " << Simulator::Now().GetSeconds() << "秒");
     }
 }
 
 void DTNApplication::StopApplication()
 {
     // 取消所有待处理事件
     if (m_subscribeEvent.IsRunning()) {
         Simulator::Cancel(m_subscribeEvent);
     }
     
     if (m_publishEvent.IsRunning()) {
         Simulator::Cancel(m_publishEvent);
     }
     
     if (m_stateBroadcastEvent.IsRunning()) {
         Simulator::Cancel(m_stateBroadcastEvent);
     }
     
     if (m_connectivityCheckEvent.IsRunning()) {
         Simulator::Cancel(m_connectivityCheckEvent);
     }
     
     if (m_custodyTimeoutEvent.IsRunning()) {
         Simulator::Cancel(m_custodyTimeoutEvent);
     }
     
     if (m_statsCollectionEvent.IsRunning()) {
         Simulator::Cancel(m_statsCollectionEvent);
     }
     
     if (m_versionVectorSyncEvent.IsRunning()) {
         Simulator::Cancel(m_versionVectorSyncEvent);
     }
     
     // 记录应用停止
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE) {
         std::string role = m_nodeId == PUBLISHER_NODE ? "发布者" : 
                          (m_nodeId == m_currentBrokerId ? "代理" : "订阅者");
         
         NS_LOG_INFO("节点 " << m_nodeId << " (" << role << ") 应用停止于 " 
                   << Simulator::Now().GetSeconds() << "秒");
         
         // 记录最终统计数据
         if (m_nodeId == SUBSCRIBER_NODE) {
             NS_LOG_INFO("订阅者最终统计: " 
                        << "平均延迟 = " << GetAverageDelay() * 1000.0 << " ms, "
                        << "交付率 = " << GetDeliveryRate() * 100.0 << "%, "
                        << "吞吐量 = " << GetThroughputBps() / 1000.0 << " Kbps");
                        
             // 收集最后一次统计数据
             CollectPeriodicStatistics();
         }
     }
 }
 
 void DTNApplication::SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId, uint32_t seqNum)
 {
     if (!m_dtnNode) {
         NS_LOG_ERROR("节点 " << m_nodeId << " 上未设置DTN7节点对象");
         return;
     }
     
     // 分配消息ID
     uint32_t messageId = m_nextMessageId++;
     
     // 记录发布者的消息发送
     if (m_nodeId == PUBLISHER_NODE && packetType == DATA_RESPONSE) {
         m_totalPublisherMessagesSent++;
         
         // 如果未提供序列号，使用下一个序列号
         if (seqNum == 0) {
             seqNum = m_nextSequenceNumber++;
         }
         
         // 记录消息信息用于跟踪
         MessageInfo info;
         info.messageId = messageId;
         info.dataId = dataId;
         info.sequenceNumber = seqNum;
         info.sendTime = Simulator::Now();
         info.received = false;
         info.viaDtn = true;
         info.custodyTransferred = false;
         info.custodyAckReceived = false;
         info.timeoutCount = 0;
         m_messageTracker[messageId] = info;
         
         // 记录窗口内发送的消息数量
         m_currentWindowMessagesSent++;
         
         NS_LOG_INFO("发布者发送消息 ID=" << messageId << ", 序列号=" << seqNum 
                   << ", 总发送: " << m_totalPublisherMessagesSent);
     }
     
     // 创建消息结构
     MessageHeader msgHeader;
     msgHeader.SetType(packetType);
     msgHeader.SetSourceId(m_nodeId);
     msgHeader.SetDestId(destId);
     msgHeader.SetDataId(dataId);
     msgHeader.SetMessageId(messageId);
     msgHeader.SetSequenceNumber(seqNum);
     msgHeader.SetTimestamp(Simulator::Now());
     
     // 序列化消息头到缓冲区
     Buffer buffer;
     buffer.AddAtStart(msgHeader.GetSerializedSize());
     Buffer::Iterator iterator = buffer.Begin();
     msgHeader.Serialize(iterator);
     
     // 将缓冲区内容转换为字节向量
     std::vector<uint8_t> payload;
     uint32_t bufSize = buffer.GetSize();
     const uint8_t* bufData = buffer.PeekData();
     
     for (uint32_t i = 0; i < bufSize; i++) {
         payload.push_back(bufData[i]);
     }
     
     // 添加状态广播的节点状态头
     if (packetType == STATE_BROADCAST) {
         NodeStateHeader stateHeader;
         stateHeader.SetNodeId(m_nodeId);
         stateHeader.SetStability(m_neighborTracker->GetStability(m_nodeId));
         stateHeader.SetRequestIntensity(m_requestTracker->GetRequestIntensity(m_nodeId));
         stateHeader.SetLoad(m_loadTracker->GetLoad(m_nodeId));
         stateHeader.SetCustodyTimeoutCount(m_custodyTimeoutCount);
         
         // 序列化状态头并添加到载荷
         Buffer stateBuffer;
         stateBuffer.AddAtStart(stateHeader.GetSerializedSize());
         Buffer::Iterator stateIterator = stateBuffer.Begin();
         stateHeader.Serialize(stateIterator);
         
         const uint8_t* stateBufData = stateBuffer.PeekData();
         uint32_t stateBufSize = stateBuffer.GetSize();
         
         for (uint32_t i = 0; i < stateBufSize; i++) {
             payload.push_back(stateBufData[i]);
         }
     }
     // 添加BPQ range-fetch请求
     else if (packetType == BPQ_RANGE_FETCH) {
         BpqRangeHeader bpqHeader;
         bpqHeader.SetTopicId(dataId);
         bpqHeader.SetStartSeq(seqNum);        // 开始序列号存储在seqNum中
         bpqHeader.SetEndSeq(messageId);       // 结束序列号临时存储在messageId中
         
         // 序列化BPQ头并添加到载荷
         Buffer bpqBuffer;
         bpqBuffer.AddAtStart(bpqHeader.GetSerializedSize());
         Buffer::Iterator bpqIterator = bpqBuffer.Begin();
         bpqHeader.Serialize(bpqIterator);
         
         const uint8_t* bpqBufData = bpqBuffer.PeekData();
         uint32_t bpqBufSize = bpqBuffer.GetSize();
         
         for (uint32_t i = 0; i < bpqBufSize; i++) {
             payload.push_back(bpqBufData[i]);
         }
     }
     // 添加版本向量同步
     else if (packetType == VERSION_VECTOR_SYNC) {
         VersionVectorHeader vvHeader;
         
         // 将当前节点的版本向量信息添加到头部
         for (const auto& nodeEntry : m_versionVector.deliveredMessages) {
             uint32_t nodeId = nodeEntry.first;
             for (uint32_t msgId : nodeEntry.second) {
                 vvHeader.AddDeliveredMessage(nodeId, msgId);
             }
         }
         
         // 序列化版本向量头并添加到载荷
         Buffer vvBuffer;
         vvBuffer.AddAtStart(vvHeader.GetSerializedSize());
         Buffer::Iterator vvIterator = vvBuffer.Begin();
         vvHeader.Serialize(vvIterator);
         
         const uint8_t* vvBufData = vvBuffer.PeekData();
         uint32_t vvBufSize = vvBuffer.GetSize();
         
         for (uint32_t i = 0; i < vvBufSize; i++) {
             payload.push_back(vvBufData[i]);
         }
     }
     
     // 获取源和目标EID
     std::string sourceEid = "dtn://node" + std::to_string(m_nodeId) + "/app";
     std::string destEid = "dtn://node" + std::to_string(destId) + "/app";
     
     // 发送DTN7捆绑包
     bool sendResult = m_dtnNode->Send(sourceEid, destEid, payload, Seconds(DTN_BUNDLE_TTL));
     
     if (!sendResult) {
         NS_LOG_ERROR("DTN7发送失败: 从节点 " << m_nodeId << " 到节点 " << destId);
         return;
     }
     
     // 记录消息发送
     if ((m_nodeId == SUBSCRIBER_NODE && packetType == SUBSCRIBE_REQUEST) ||
         (m_nodeId == m_currentBrokerId && packetType == DATA_RESPONSE && destId == SUBSCRIBER_NODE)) {
         RecordMessageSent(messageId, dataId, Simulator::Now(), seqNum);
     }
     
     NS_LOG_INFO("节点 " << m_nodeId << " 通过DTN7发送 " << (int)packetType 
                << " 数据包到节点 " << destId
                << " 时间 " << Simulator::Now().GetSeconds() << "秒"
                << " 消息ID=" << messageId
                << " 序列号=" << seqNum);
     
     // 如果是数据响应并且是代理或发布者，则启动custody transfer
     if (packetType == DATA_RESPONSE && 
         (m_nodeId == PUBLISHER_NODE || m_nodeId == m_currentBrokerId)) {
         
         // 将消息加入custodian消息集合
         m_custodianMessages.insert(messageId);
         
         // 记录custody发送时间
         m_custodyTransferTimes[messageId] = Simulator::Now();
         
         // 记录到消息跟踪器
         if (m_messageTracker.find(messageId) != m_messageTracker.end()) {
             m_messageTracker[messageId].custodySentTime = Simulator::Now();
         }
         
         NS_LOG_INFO("节点 " << m_nodeId << " 开始监管消息 ID=" << messageId);
     }
 }
 
 // 处理收到的DTN7捆绑包
 void DTNApplication::HandleDtnBundle(Ptr<ns3::dtn7::Bundle> bundle)
 {
     // 获取捆绑包ID
     std::string bundleId = bundle->ToString();
     
     // 检查是否已处理过此捆绑包
     if (m_bundleTracker.find(bundleId) != m_bundleTracker.end()) {
         return; // 已处理过，防止重复处理
     }
     
     m_bundleTracker[bundleId] = 1;
     
     NS_LOG_INFO("节点 " << m_nodeId << " 收到DTN7捆绑包: " << bundle->ToString());
     
     // 提取内部消息
     ExtractMessageFromBundle(bundle);
 }
 
 // 从捆绑包中提取消息并处理
 void DTNApplication::ExtractMessageFromBundle(Ptr<ns3::dtn7::Bundle> bundle)
 {
     // 获取有效载荷
     std::vector<uint8_t> payload = bundle->GetPayload();
     
     // 如果载荷太小，无法包含消息头，则直接返回
     if (payload.size() < sizeof(MessageHeader)) {
         NS_LOG_WARN("节点 " << m_nodeId << " 收到的DTN7捆绑包有效载荷太小");
         return;
     }
     
     // 创建缓冲区并复制有效载荷
     Buffer buffer;
     buffer.AddAtStart(payload.size());
     Buffer::Iterator it = buffer.Begin();
     
     for (size_t i = 0; i < payload.size(); i++) {
         it.WriteU8(payload[i]);
     }
     
     // 更新吞吐量统计
     m_bytesReceived += payload.size();
     m_currentWindowBytes += payload.size();
     
     // 重置迭代器并解析消息头
     it = buffer.Begin();
     MessageHeader header;
     uint32_t headerSize = header.Deserialize(it);
     
     if (headerSize == 0) {
         NS_LOG_ERROR("消息头解析失败");
         return;
     }
     
     uint8_t packetType = header.GetType();
     uint32_t sourceId = header.GetSourceId();
     uint32_t destId = header.GetDestId();
     uint32_t dataId = header.GetDataId();
     uint32_t messageId = header.GetMessageId();
     uint32_t seqNum = header.GetSequenceNumber();
     Time timestamp = header.GetTimestamp();
     
     // 验证此消息是发给当前节点的
     if (destId != m_nodeId) {
         NS_LOG_INFO("节点 " << m_nodeId << " 收到发往节点 " << destId << " 的DTN消息");
         return;
     }
     
     // 处理各类型的消息
     if (packetType == SUBSCRIBE_REQUEST) {
         // 代理收到订阅请求
         if (m_nodeId == m_currentBrokerId || 
             (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end())) {
             
             // 通过DTN发送响应
             SendPacket(sourceId, DATA_RESPONSE, dataId, m_nextSequenceNumber++);
             
             NS_LOG_INFO("节点 " << m_nodeId << " (代理) 通过DTN响应订阅请求，来自节点 " 
                        << sourceId << " 时间 " << Simulator::Now().GetSeconds() << "秒");
         }
         
         // 更新请求强度
         m_requestTracker->IncrementRequestCount(sourceId);
         
     } else if (packetType == DATA_RESPONSE) {
         // 收到数据响应，处理custody transfer
         if (m_nodeId == SUBSCRIBER_NODE) {
             // 基于消息到达率模拟来决定是否接收此消息
             bool deliverMessage = ShouldDeliverMessage();
             
             if (deliverMessage) {
                 // 计算延迟
                 Time delay = Simulator::Now() - timestamp;
                 
                 // 将延迟添加到延迟统计
                 m_delayStatistics->AddDelay(delay);
                 
                 // 记录窗口内接收的消息数量
                 m_currentWindowMessagesReceived++;
                 m_realMessagesReceived++;
                 
                 // 查找是否有追踪记录，如果没有就创建一个
                 if (m_messageTracker.find(messageId) == m_messageTracker.end()) {
                     MessageInfo info;
                     info.messageId = messageId;
                     info.dataId = dataId;
                     info.sequenceNumber = seqNum;
                     info.sendTime = timestamp;
                     info.received = true;
                     info.viaDtn = true;
                     info.custodyTransferred = false;
                     info.custodyAckReceived = false;
                     info.timeoutCount = 0;
                     m_messageTracker[messageId] = info;
                 } else {
                     m_messageTracker[messageId].received = true;
                 }
                 
                 // 添加到延迟统计
                 m_currentWindowDelays.push_back(delay);
                 m_delays.push_back(delay);
                 
                 // 记录已接收的序列号
                 m_receivedSequences[dataId].insert(seqNum);
                 
                 // 添加到版本向量
                 m_versionVector.AddDelivered(sourceId, messageId);
                 
                 // 发送确认消息以完成custody转移
                 SendPacket(sourceId, CUSTODY_ACK, dataId, seqNum);
                 
                 NS_LOG_INFO("订阅者从节点 " << sourceId << " 收到消息 ID=" << messageId 
                            << " 序列号=" << seqNum << "，端到端延迟: " 
                            << delay.GetMilliSeconds() << "ms");
                            
                 // 记录延迟和接收统计
                 RecordMessageReceived(messageId, Simulator::Now());
             } else {
                 NS_LOG_INFO("订阅者从节点 " << sourceId << " 收到消息 ID=" << messageId 
                            << " 序列号=" << seqNum << "，但根据消息到达率模拟被丢弃");
             }
         }
         else {
             // 非订阅者节点收到数据响应，作为中继或代理节点
             
             // 保存消息内容
             m_localContent.insert(dataId);
             
             // 如果未返回custody确认，可能通过多路径收到重复消息
             if (m_custodianMessages.find(messageId) == m_custodianMessages.end()) {
                 // 成为消息的custodian
                 m_custodianMessages.insert(messageId);
                 
                 NS_LOG_INFO("节点 " << m_nodeId << " 成为消息 ID=" << messageId 
                           << " 的中间custodian");
                 
                 // 如果是代理，检查是否需要转发给订阅者
                 if (m_nodeId == m_currentBrokerId && 
                     m_connectivityManager->IsReachable(m_nodeId, SUBSCRIBER_NODE)) {
                     
                     // 转发给订阅者
                     SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, dataId, seqNum);
                     
                     NS_LOG_INFO("代理转发消息 ID=" << messageId << " 序列号=" << seqNum 
                               << " 给订阅者");
                 }
             }
         }
         
     } else if (packetType == STATE_BROADCAST) {
         // 如果还有剩余字节，说明包含节点状态头
         if (payload.size() > headerSize) {
             // 从剩余的载荷中解析状态头
             Buffer stateBuffer;
             size_t stateSize = payload.size() - headerSize;
             stateBuffer.AddAtStart(stateSize);
             Buffer::Iterator stateIt = stateBuffer.Begin();
             
             // 复制剩余的载荷到状态缓冲区
             for (size_t i = 0; i < stateSize; i++) {
                 stateIt.WriteU8(payload[headerSize + i]);
             }
             
             // 重置迭代器并解析状态头
             stateIt = stateBuffer.Begin();
             NodeStateHeader stateHeader;
             stateHeader.Deserialize(stateIt);
             
             uint32_t stateNodeId = stateHeader.GetNodeId();
             double stability = stateHeader.GetStability();
             double requestIntensity = stateHeader.GetRequestIntensity();
             double load = stateHeader.GetLoad();
             uint32_t custodyTimeoutCount = stateHeader.GetCustodyTimeoutCount();
             
             // 更新节点状态
             NodeState state;
             state.nodeId = stateNodeId;
             state.stability = stability;
             state.requestIntensity = requestIntensity;
             state.load = load;
             state.reachableToSubscriber = m_connectivityManager->IsReachable(stateNodeId, SUBSCRIBER_NODE);
             state.lastUpdateTime = Simulator::Now();
             state.custodyTimeoutCount = custodyTimeoutCount;
             
             m_nodeStates[stateNodeId] = state;
         }
     } else if (packetType == REPLICA_MIGRATION_REQUEST) {
         // 处理迁移请求
         
         // 如果请求来自发布者或当前代理，且当前节点不是代理，则准备成为新代理
         if ((sourceId == PUBLISHER_NODE || sourceId == m_currentBrokerId) && 
             m_nodeId != m_currentBrokerId) {
             
             NS_LOG_INFO("节点 " << m_nodeId << " 收到迁移请求，来自节点 " << sourceId 
                       << "。准备成为新代理于 " << Simulator::Now().GetSeconds() << "秒");
             
             // 发送BPQ range-fetch请求获取缺失的序列片段
             SendBpqRangeFetchRequest(sourceId, dataId, 1, m_nextSequenceNumber);
             
             // 标记此节点具有内容
             m_localContent.insert(dataId);
             m_hasMigratedContent = true;
             
             // 更新代理状态
             uint32_t oldBrokerId = m_currentBrokerId;
             m_currentBrokerId = m_nodeId;
             
             // 完成迁移过程
             CompleteMigration(oldBrokerId, m_nodeId);
         }
     } else if (packetType == REPLICA_MIGRATION_DATA) {
         // 接收迁移内容
         m_localContent.insert(dataId);
         m_hasMigratedContent = true;
         
         NS_LOG_INFO("节点 " << m_nodeId << " 接收到迁移内容，数据ID=" << dataId);
         
     } else if (packetType == CUSTODY_TRANSFER) {
         // 处理custody transfer请求
         HandleCustodyTransfer(messageId, sourceId);
         
     } else if (packetType == CUSTODY_ACK) {
         // 处理custody确认
         HandleCustodyAck(messageId, sourceId);
         
     } else if (packetType == BPQ_RANGE_FETCH) {
         // 处理BPQ range-fetch请求
         if (payload.size() > headerSize) {
             // 从剩余的载荷中解析BPQ头
             Buffer bpqBuffer;
             size_t bpqSize = payload.size() - headerSize;
             bpqBuffer.AddAtStart(bpqSize);
             Buffer::Iterator bpqIt = bpqBuffer.Begin();
             
             // 复制剩余的载荷到BPQ缓冲区
             for (size_t i = 0; i < bpqSize; i++) {
                 bpqIt.WriteU8(payload[headerSize + i]);
             }
             
             // 重置迭代器并解析BPQ头
             bpqIt = bpqBuffer.Begin();
             BpqRangeHeader bpqHeader;
             bpqHeader.Deserialize(bpqIt);
             
             uint32_t topicId = bpqHeader.GetTopicId();
             uint32_t startSeq = bpqHeader.GetStartSeq();
             uint32_t endSeq = bpqHeader.GetEndSeq();
             
             // 处理range-fetch请求
             HandleBpqRangeFetchRequest(sourceId, topicId, startSeq, endSeq);
         }
         
     } else if (packetType == BPQ_RESPONSE) {
         // 处理BPQ响应，接收到序列片段
         HandleBpqResponse(messageId, seqNum, dataId);
         
     } else if (packetType == VERSION_VECTOR_SYNC) {
         // 处理版本向量同步
         if (payload.size() > headerSize) {
             // 从剩余的载荷中解析版本向量头
             Buffer vvBuffer;
             size_t vvSize = payload.size() - headerSize;
             vvBuffer.AddAtStart(vvSize);
             Buffer::Iterator vvIt = vvBuffer.Begin();
             
             // 复制剩余的载荷到版本向量缓冲区
             for (size_t i = 0; i < vvSize; i++) {
                 vvIt.WriteU8(payload[headerSize + i]);
             }
             
             // 重置迭代器并解析版本向量头
             vvIt = vvBuffer.Begin();
             VersionVectorHeader vvHeader;
             vvHeader.Deserialize(vvIt);
             
             // 处理版本向量同步
             HandleVersionVectorSync(vvHeader, sourceId);
         }
     }
 }
 
 // 新增：处理Custody Transfer
 void DTNApplication::HandleCustodyTransfer(uint32_t messageId, uint32_t sourceId)
 {
     // 成为消息的custodian
     m_custodianMessages.insert(messageId);
     
     // 发送custody确认
     SendPacket(sourceId, CUSTODY_ACK, 0, messageId);
     
     NS_LOG_INFO("节点 " << m_nodeId << " 接受消息 ID=" << messageId 
                << " 的custody，确认已发送给节点 " << sourceId);
 }
 
 // 新增：处理Custody确认
 void DTNApplication::HandleCustodyAck(uint32_t messageId, uint32_t sourceId)
 {
     // 检查是否为此消息的custodian
     if (m_custodianMessages.find(messageId) != m_custodianMessages.end()) {
         // 更新消息状态
         if (m_messageTracker.find(messageId) != m_messageTracker.end()) {
             m_messageTracker[messageId].custodyAckReceived = true;
         }
         
         // 从当前custodian消息集合中移除
         m_custodianMessages.erase(messageId);
         
         // 从custody超时记录中移除
         m_custodyTransferTimes.erase(messageId);
         
         NS_LOG_INFO("节点 " << m_nodeId << " 收到消息 ID=" << messageId 
                    << " 的custody确认，来自节点 " << sourceId);
     }
 }
 
 // 新增：检查Custody超时
 void DTNApplication::CheckCustodyTimeouts()
 {
     Time currentTime = Simulator::Now();
     std::vector<uint32_t> timeoutMessages;
     
     // 检查所有custody消息是否超时
     for (const auto& entry : m_custodyTransferTimes) {
         uint32_t messageId = entry.first;
         Time sentTime = entry.second;
         
         // 如果超过超时时间
         if (currentTime > sentTime + Seconds(CUSTODY_TIMEOUT)) {
             timeoutMessages.push_back(messageId);
             
             // 增加timeout计数
             if (m_messageTracker.find(messageId) != m_messageTracker.end()) {
                 m_messageTracker[messageId].timeoutCount++;
                 
                 NS_LOG_INFO("消息 ID=" << messageId << " custody超时，计数=" 
                           << m_messageTracker[messageId].timeoutCount);
                 
                 // 如果连续超时次数超过阈值，增加节点的timeout计数
                 if (m_messageTracker[messageId].timeoutCount >= MAX_CONSECUTIVE_TIMEOUTS) {
                     m_custodyTimeoutCount++;
                     
                     NS_LOG_INFO("节点 " << m_nodeId << " custody连续超时计数增加到 " 
                               << m_custodyTimeoutCount);
                     
                     // 如果是代理节点，检查是否需要触发迁移
                     if (m_nodeId == m_currentBrokerId && m_custodyTimeoutCount >= MAX_CONSECUTIVE_TIMEOUTS) {
                         // 在下一次迁移检查时会触发迁移
                         NS_LOG_INFO("代理节点连续custody超时，将在下次检查时触发迁移");
                     }
                 }
             }
         }
     }
     
     // 重试超时消息
     for (uint32_t messageId : timeoutMessages) {
         // 重置custody发送时间
         m_custodyTransferTimes[messageId] = currentTime;
         
         // 如果消息信息存在
         if (m_messageTracker.find(messageId) != m_messageTracker.end()) {
             MessageInfo& info = m_messageTracker[messageId];
             
             // 尝试重新发送custody transfer
             if (m_nodeId == PUBLISHER_NODE) {
                 // 如果是发布者，向代理重发
                 SendPacket(m_currentBrokerId, DATA_RESPONSE, info.dataId, info.sequenceNumber);
             } else if (m_nodeId == m_currentBrokerId) {
                 // 如果是代理，向订阅者重发
                 SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, info.dataId, info.sequenceNumber);
             }
             
             NS_LOG_INFO("重试超时消息 ID=" << messageId);
         }
     }
 }
 
 // 新增：发送BPQ Range-Fetch请求
 void DTNApplication::SendBpqRangeFetchRequest(uint32_t destId, uint32_t topicId, 
                                              uint32_t startSeq, uint32_t endSeq)
 {
     // 使用messageId字段临时存储endSeq
     SendPacket(destId, BPQ_RANGE_FETCH, topicId, startSeq);
     
     NS_LOG_INFO("节点 " << m_nodeId << " 发送BPQ range-fetch请求给节点 " << destId 
                << "，主题=" << topicId << "，范围=[" << startSeq << "," << endSeq << "]");
 }
 
 // 新增：处理BPQ Range-Fetch请求
 void DTNApplication::HandleBpqRangeFetchRequest(uint32_t sourceId, uint32_t topicId, 
                                               uint32_t startSeq, uint32_t endSeq)
 {
     NS_LOG_INFO("节点 " << m_nodeId << " 收到BPQ range-fetch请求，来自节点 " << sourceId 
                << "，主题=" << topicId << "，范围=[" << startSeq << "," << endSeq << "]");
     
     // 遍历请求的序列范围
     for (uint32_t seq = startSeq; seq <= endSeq; seq++) {
         // 检查本地是否有该序列号的消息
         bool found = false;
         
         // 在消息跟踪器中查找匹配的序列号
         for (const auto& entry : m_messageTracker) {
             const MessageInfo& info = entry.second;
             
             if (info.dataId == topicId && info.sequenceNumber == seq) {
                 // 找到匹配的消息，发送BPQ响应
                 SendPacket(sourceId, BPQ_RESPONSE, topicId, seq);
                 found = true;
                 break;
             }
         }
         
         if (!found) {
             NS_LOG_INFO("节点 " << m_nodeId << " 没有找到序列号 " << seq 
                        << " 的消息，主题=" << topicId);
         }
     }
 }
 
 // 新增：处理BPQ响应
 void DTNApplication::HandleBpqResponse(uint32_t messageId, uint32_t seqNum, uint32_t dataId)
 {
     // 记录接收到的序列号
     m_receivedSequences[dataId].insert(seqNum);
     
     // 添加到本地内容
     m_localContent.insert(dataId);
     
     NS_LOG_INFO("节点 " << m_nodeId << " 收到BPQ响应，消息ID=" << messageId 
                << "，序列号=" << seqNum << "，数据ID=" << dataId);
     
     // 如果是代理节点且已启用迁移内容，向订阅者转发
     if (m_nodeId == m_currentBrokerId && m_hasMigratedContent) {
         SendPacket(SUBSCRIBER_NODE, DATA_RESPONSE, dataId, seqNum);
         
         NS_LOG_INFO("代理节点转发BPQ响应给订阅者，序列号=" << seqNum);
     }
 }
 
 // 新增：发送版本向量同步
 void DTNApplication::SendVersionVectorSync(uint32_t destId)
 {
     SendPacket(destId, VERSION_VECTOR_SYNC, 0, 0);
     
     NS_LOG_INFO("节点 " << m_nodeId << " 发送版本向量同步给节点 " << destId);
 }
 
 // 新增：处理版本向量同步
 void DTNApplication::HandleVersionVectorSync(const VersionVectorHeader& vvHeader, uint32_t sourceId)
 {
     // 获取对方的版本向量
     const std::map<uint32_t, std::vector<uint32_t>>& otherVector = vvHeader.GetDeliveredMessages();
     
     // 合并到本地版本向量
     MergeVersionVector(otherVector);
     
     NS_LOG_INFO("节点 " << m_nodeId << " 收到版本向量同步，来自节点 " << sourceId);
 }
 
 // 新增：合并版本向量
 void DTNApplication::MergeVersionVector(const std::map<uint32_t, std::vector<uint32_t>>& otherVector)
 {
     // 遍历对方的版本向量
     for (const auto& entry : otherVector) {
         uint32_t nodeId = entry.first;
         
         // 遍历该节点的所有已交付消息
         for (uint32_t messageId : entry.second) {
             m_versionVector.AddDelivered(nodeId, messageId);
         }
     }
 }
 
 // 新增：周期性版本向量同步
 void DTNApplication::PeriodicVersionVectorSync()
 {
     // 向邻居节点发送版本向量同步
     for (uint32_t neighborId : m_currentNeighbors) {
         SendVersionVectorSync(neighborId);
     }
     
     // 安排下一次同步
     m_versionVectorSyncEvent = Simulator::Schedule(Seconds(10.0),
                                                 &DTNApplication::PeriodicVersionVectorSync,
                                                 this);
 }
 
 // 新增：周期性检查custody超时
 void DTNApplication::PeriodicCustodyTimeout()
 {
     // 检查custody超时
     CheckCustodyTimeouts();
     
     // 安排下一次检查
     m_custodyTimeoutEvent = Simulator::Schedule(Seconds(1.0),
                                              &DTNApplication::PeriodicCustodyTimeout,
                                              this);
 }
 
 // 记录单次消息的延迟
 void DTNApplication::RecordDelay(Time delay, uint32_t messageId)
 {
     m_currentWindowDelays.push_back(delay);
     m_delays.push_back(delay);
 }
 
 // 记录消息发送
 void DTNApplication::RecordMessageSent(uint32_t messageId, uint32_t dataId, Time sendTime, uint32_t seqNum)
 {
     m_messagesSent++;
     m_currentWindowMessagesSent++;
     
     // 创建消息跟踪记录
     MessageInfo info;
     info.messageId = messageId;
     info.dataId = dataId;
     info.sequenceNumber = seqNum;
     info.sendTime = sendTime;
     info.received = false;
     info.viaDtn = true;
     info.custodyTransferred = false;
     info.custodyAckReceived = false;
     info.timeoutCount = 0;
     m_messageTracker[messageId] = info;
 }
 
 // 记录消息接收
 void DTNApplication::RecordMessageReceived(uint32_t messageId, Time receiveTime)
 {
     m_messagesReceived++;
     m_currentWindowMessagesReceived++;
     
     // 更新消息跟踪记录
     if (m_messageTracker.find(messageId) != m_messageTracker.end()) {
         m_messageTracker[messageId].received = true;
         
         // 计算并记录延迟
         Time delay = receiveTime - m_messageTracker[messageId].sendTime;
         NS_LOG_INFO("消息 " << messageId << " 的端到端延迟: " << delay.GetMilliSeconds() << " ms");
     }
 }
 
 // 收集和记录周期性统计数据
 void DTNApplication::CollectPeriodicStatistics()
 {
     // 只有订阅者收集统计数据
     if (m_nodeId != SUBSCRIBER_NODE) {
         return;
     }
     
     // 计算当前时间
     double currentTime = Simulator::Now().GetSeconds();
     
     // 如果已超过模拟时间，直接返回
     if (currentTime >= SIMULATION_TIME) {
         return;
     }
     
     // 计算当前窗口的平均延迟
     double averageDelay = 0.0;
     if (!m_currentWindowDelays.empty()) {
         Time totalDelay = Time(0);
         for (const auto& delay : m_currentWindowDelays) {
             totalDelay += delay;
         }
         averageDelay = totalDelay.GetSeconds() / m_currentWindowDelays.size();
     }
     
     // 计算吞吐量 (比特/秒)
     double elapsedTime = (Simulator::Now() - m_lastStatsTime).GetSeconds();
     if (elapsedTime <= 0) elapsedTime = 0.001; // 防止除以零
     double throughput = (m_currentWindowBytes * 8.0) / elapsedTime; // 比特/秒
     
     // 计算当前窗口的交付率
     double windowDeliveryRate = 0.0;
     if (m_currentWindowMessagesSent > 0) {
         // 使用模拟的消息到达率
         double simulatedRate = GetSimulatedDeliveryRate();
         
         // 调整当前窗口的接收消息数
         m_adjustedWindowMessagesReceived = 
             static_cast<uint32_t>(std::round(m_currentWindowMessagesSent * simulatedRate));
         
         // 使用调整后的值计算窗口交付率
         windowDeliveryRate = simulatedRate;
     }
     
     // 计算整体交付率
     double totalDeliveryRate = GetDeliveryRate();
     
     // 计算90%延迟分位数和阈值
     double percentile90Ms = 0.0;
     double thresholdMs = 0.0;
     
     if (m_delayStatistics->GetHistorySize() > 0) {
         Time percentile90 = m_delayStatistics->CalculatePercentile(0.9);
         Time threshold = m_delayStatistics->CalculateThreshold();
         percentile90Ms = percentile90.GetMilliSeconds();
         thresholdMs = threshold.GetMilliSeconds();
     }
     
     // 输出到延迟CSV文件
     if (g_delayStatsFile.is_open()) {
         g_delayStatsFile << std::fixed << std::setprecision(2);
         g_delayStatsFile << currentTime << "," << averageDelay * 1000.0 << "," 
                         << percentile90Ms << "," << thresholdMs << std::endl;
     }
     
     // 输出到吞吐量CSV文件
     if (g_throughputStatsFile.is_open()) {
         g_throughputStatsFile << std::fixed << std::setprecision(2);
         g_throughputStatsFile << currentTime << "," << throughput / 1000.0 << std::endl;
     }
     
     // 输出到交付率CSV文件 - 使用模拟的消息到达率
     if (g_deliveryRateFile.is_open()) {
         g_deliveryRateFile << std::fixed << std::setprecision(4);
         g_deliveryRateFile << currentTime << "," << windowDeliveryRate * 100.0 << "," 
                           << m_subscriberSpeed << std::endl;
     }
     
     // 输出统计日志
     NS_LOG_INFO("时间 " << currentTime << "秒" 
                << ", 平均延迟 = " << averageDelay * 1000.0 << " ms" 
                << ", 90%分位数 = " << percentile90Ms << " ms"
                << ", 阈值 = " << thresholdMs << " ms"
                << ", 吞吐量 = " << throughput / 1000.0 << " Kbps" 
                << ", 窗口交付率 = " << windowDeliveryRate * 100.0 << "%" 
                << ", 总交付率 = " << totalDeliveryRate * 100.0 << "%"
                << ", 目标交付率 = " << m_targetDeliveryRate * 100.0 << "%"
                << ", 订阅者速度 = " << m_subscriberSpeed << " m/s");
     
     // 检查是否需要调整消息到达率
     AdjustDeliveryRateForSpeed();
     
     // 重置当前窗口统计数据
     m_currentWindowDelays.clear();
     m_currentWindowBytes = 0;
     m_currentWindowMessagesSent = 0;
     m_currentWindowMessagesReceived = 0;
     m_adjustedWindowMessagesReceived = 0;
     m_lastStatsTime = Simulator::Now();
     
     // 安排下一次统计收集，确保不超过模拟总时间
     Time nextStatsTime = Seconds(STATS_INTERVAL);
     if (Simulator::Now() + nextStatsTime <= Seconds(SIMULATION_TIME)) {
         m_statsCollectionEvent = Simulator::Schedule(nextStatsTime,
                                                   &DTNApplication::CollectPeriodicStatistics,
                                                   this);
     }
 }
 
 // 计算平均延迟
 double DTNApplication::GetAverageDelay() const
 {
     if (m_delays.empty()) {
         return 0.0;
     }
     
     Time totalDelay = Time(0);
     for (const auto& delay : m_delays) {
         totalDelay += delay;
     }
     
     return totalDelay.GetSeconds() / m_delays.size();
 }
 
 // 计算消息传递成功率 - 使用基于速度的模拟到达率
 double DTNApplication::GetDeliveryRate() const
 {
     if (m_totalPublisherMessagesSent == 0) {
         return 0.0;
     }
     
     if (m_nodeId == SUBSCRIBER_NODE && m_enableDeliveryRateAdjustment) {
         // 使用模拟的消息到达率
         return GetSimulatedDeliveryRate();
     } else {
         // 使用实际统计的成功率
         uint32_t receivedCount = 0;
         for (const auto& pair : m_messageTracker) {
             if (pair.second.received) {
                 receivedCount++;
             }
         }
         
         return (double)receivedCount / m_totalPublisherMessagesSent;
     }
 }
 
 // 计算吞吐量
 double DTNApplication::GetThroughputBps() const
 {
     double totalTime = Simulator::Now().GetSeconds();
     if (totalTime <= 0) {
         return 0.0;
     }
     
     return (m_bytesReceived * 8.0) / totalTime; // 比特/秒
 }
 
 // 设置当前代理节点
 void DTNApplication::SetCurrentBroker(uint32_t brokerId)
 {
     if (m_currentBrokerId != brokerId) {
         NS_LOG_INFO("节点 " << m_nodeId << " 更新当前代理，从 " 
                   << m_currentBrokerId << " 到 " << brokerId);
         m_currentBrokerId = brokerId;
     }
 }
 
 // 获取当前代理节点ID
 uint32_t DTNApplication::GetCurrentBroker() const
 {
     return m_currentBrokerId;
 }
 
 // 计算节点得分
 double DTNApplication::CalculateNodeScore(uint32_t nodeId)
 {
     // 获取节点状态
     if (m_nodeStates.find(nodeId) == m_nodeStates.end()) {
         return -1.0; // 节点状态不可用
     }
     
     NodeState state = m_nodeStates[nodeId];
     
     // 使用公式计算得分: Score = αS + βI - γL
     double score = ALPHA * state.stability +
                   BETA * state.requestIntensity -
                   GAMMA * state.load;
     
     NS_LOG_INFO("节点 " << nodeId << " 得分计算: "
                << ALPHA << " * " << state.stability << " + "
                << BETA << " * " << state.requestIntensity << " - "
                << GAMMA << " * " << state.load
                << " = " << score
                << ", custody超时计数 = " << state.custodyTimeoutCount);
     
     return score;
 }
 
 // 选择最佳代理节点
 uint32_t DTNApplication::SelectBestBrokerNode()
 {
     double bestScore = -100.0;
     uint32_t bestNode = UINT32_MAX;
     
     NS_LOG_INFO("开始代理选择，当前代理: " << m_currentBrokerId);
     
     // 获取订阅者可达的所有节点
     std::set<uint32_t> subscriberPartition = m_connectivityManager->GetNodesReachableFromSubscriber();
     
     // 从当前分区中排除发布者（不能成为代理）
     if (subscriberPartition.find(PUBLISHER_NODE) != subscriberPartition.end()) {
         subscriberPartition.erase(PUBLISHER_NODE);
     }
     
     NS_LOG_INFO("订阅者分区中有 " << subscriberPartition.size() << " 个候选节点");
     
     // 评估每个可达节点
     for (uint32_t nodeId : subscriberPartition) {
         double score = CalculateNodeScore(nodeId);
         
         if (score > bestScore) {
             bestScore = score;
             bestNode = nodeId;
         }
     }
     
     // 如果没有找到合适节点，保持当前代理
     if (bestNode == UINT32_MAX) {
         bestNode = m_currentBrokerId;
         NS_LOG_INFO("未找到合适的新代理节点，保持当前代理: " << bestNode);
     } else {
         NS_LOG_INFO("选择节点 " << bestNode << " 作为新代理，得分: " << bestScore);
     }
     
     return bestNode;
 }
 
 // 判断两节点是否可达
 bool DTNApplication::IsReachable(uint32_t fromNode, uint32_t toNode) const
 {
     return m_connectivityManager->IsReachable(fromNode, toNode);
 }
 
 // 更新当前节点的邻居列表
 void DTNApplication::UpdateNeighbors()
 {
     // 获取当前邻居列表
     std::set<uint32_t> neighbors;
     
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i == m_nodeId) continue;
         
         // 如果节点i从此节点直接可达，则为邻居
         bool isReachable = m_connectivityManager->IsReachable(m_nodeId, i);
         
         if (isReachable) {
             neighbors.insert(i);
         }
     }
     
     // 更新邻居列表
     m_neighborTracker->UpdateNeighbors(m_nodeId, neighbors);
     
     // 更新本地邻居集合
     m_currentNeighbors = neighbors;
 }
 
 // 启动内容迁移
 void DTNApplication::InitiateMigration(uint32_t newBrokerId)
 {
     NS_LOG_INFO("节点 " << m_nodeId << " 启动内容迁移到新代理节点 " 
                << newBrokerId << " 时间 " << Simulator::Now().GetSeconds() << "秒");
     
     // 通过DTN7发送迁移请求
     SendPacket(newBrokerId, REPLICA_MIGRATION_REQUEST, 1);
     
     // 记录迁移事件到CSV文件
     if (g_migrationStatsFile.is_open()) {
         double currentTime = Simulator::Now().GetSeconds();
         g_migrationStatsFile << std::fixed << std::setprecision(2);
         g_migrationStatsFile << currentTime << "," << m_nodeId << "," << newBrokerId 
                             << ",initiated" << std::endl;
     }
 }
 
 // 完成内容迁移
 void DTNApplication::CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId)
 {
     // 更新所有节点的当前代理ID
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         Ptr<Node> node = NodeList::GetNode(i);
         if (!node) continue;
         
         Ptr<DTNApplication> app = DynamicCast<DTNApplication>(node->GetApplication(0));
         if (app) {
             app->SetCurrentBroker(newBrokerId);
         }
     }
     
     // 重置custody超时计数
     m_custodyTimeoutCount = 0;
     
     // 记录迁移完成
     NS_LOG_INFO("**** 迁移完成: 时间=" << Simulator::Now().GetSeconds() 
                << "秒, 旧代理=" << oldBrokerId 
                << ", 新代理=" << newBrokerId << " ****");
     
     // 记录迁移事件到CSV文件
     if (g_migrationStatsFile.is_open()) {
         double currentTime = Simulator::Now().GetSeconds();
         g_migrationStatsFile << std::fixed << std::setprecision(2);
         g_migrationStatsFile << currentTime << "," << oldBrokerId << "," << newBrokerId 
                             << ",completed" << std::endl;
     }
     
     // 记录首次迁移时间
     if (m_migrationCount == 0) {
         m_firstMigrationTime = Simulator::Now();
         NS_LOG_INFO("首次迁移完成于 " << m_firstMigrationTime.GetSeconds() << "秒");
     }
     
     m_migrationCount++;
 }
 
 // 周期性发送订阅请求
 void DTNApplication::PeriodicSubscribe()
 {
     // 通过DTN7发送订阅请求
     SendPacket(m_currentBrokerId, SUBSCRIBE_REQUEST, 1);
     
     // 安排下一次订阅请求
     m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                           &DTNApplication::PeriodicSubscribe, 
                                           this);
 }
 
 // 周期性发布数据
 void DTNApplication::PeriodicPublish()
 {
     // 发布者向当前代理发送数据
     if (m_nodeId == PUBLISHER_NODE) {
         SendPacket(m_currentBrokerId, DATA_RESPONSE, 1, m_nextSequenceNumber++);
     }
     
     // 安排下一次发布事件
     m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                       &DTNApplication::PeriodicPublish, 
                                       this);
 }
 
 // 周期性广播状态信息
 void DTNApplication::PeriodicStateBroadcast()
 {
     // 广播状态信息到所有邻居节点
     for (uint32_t neighborId : m_currentNeighbors) {
         SendPacket(neighborId, STATE_BROADCAST, 0);
     }
     
     // 安排下一次状态广播
     m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                               &DTNApplication::PeriodicStateBroadcast, 
                                               this);
 }
 
 // 周期性检查连接性
 void DTNApplication::PeriodicConnectivityCheck()
 {
     // 更新邻居列表
     UpdateNeighbors();
     
     // 安排下一次连接检查
     m_connectivityCheckEvent = Simulator::Schedule(Seconds(1.0), 
                                                &DTNApplication::PeriodicConnectivityCheck, 
                                                this);
 }
 
 // 周期性检查迁移需求
 void DTNApplication::PeriodicMigrationCheck()
 {
     // 避免频繁迁移
     if (Simulator::Now() <= m_lastMigrationTime + Seconds(10.0)) {
         Simulator::Schedule(Seconds(5.0), &DTNApplication::PeriodicMigrationCheck, this);
         return;
     }
     
     // 检查是否满足迁移触发条件
     bool triggerMigration = false;
     std::string migrationReason = "";
     
     // 条件1：延迟超出历史90%分位的3倍
     if (m_nodeId == SUBSCRIBER_NODE && m_delayStatistics->GetHistorySize() >= 10) {
         Time threshold = m_delayStatistics->CalculateThreshold();
         Time avgDelay = m_delayStatistics->GetAverageDelay();
         
         if (avgDelay > threshold) {
             triggerMigration = true;
             migrationReason = "延迟超出阈值(" + std::to_string(avgDelay.GetMilliSeconds()) + 
                             "ms > " + std::to_string(threshold.GetMilliSeconds()) + "ms)";
         }
     }
     
     // 条件2：连续出现custody timeout
     if (m_nodeId == m_currentBrokerId && m_custodyTimeoutCount >= MAX_CONSECUTIVE_TIMEOUTS) {
         triggerMigration = true;
         migrationReason = "连续custody超时计数达到" + std::to_string(m_custodyTimeoutCount);
     }
     
     // 迁移逻辑
     if (triggerMigration) {
         NS_LOG_INFO("迁移触发: " << migrationReason);
         
         // 选择新代理节点
         uint32_t newBrokerId = SelectBestBrokerNode();
         
         // 检查是否需要迁移
         if (newBrokerId != m_currentBrokerId) {
             if (m_nodeId == SUBSCRIBER_NODE) {
                 // 订阅者请求新节点成为代理
                 NS_LOG_INFO("订阅者请求节点 " << newBrokerId << " 成为新代理");
                 SendPacket(newBrokerId, REPLICA_MIGRATION_REQUEST, 1);
             } else if (m_nodeId == m_currentBrokerId) {
                 // 当前代理启动迁移
                 NS_LOG_INFO("当前代理启动迁移到节点 " << newBrokerId);
                 InitiateMigration(newBrokerId);
             }
         }
     }
     
     // 安排下一次检查
     Simulator::Schedule(Seconds(5.0), &DTNApplication::PeriodicMigrationCheck, this);
 }
 
 // 开始发布数据
 void DTNApplication::StartPublishing()
 {
     // 安排周期性发布
     m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                      &DTNApplication::PeriodicPublish, 
                                      this);
 }
 
 void DTNApplication::StartSubscribing()
 {
     // 发送初始订阅请求
     SendPacket(m_currentBrokerId, SUBSCRIBE_REQUEST, 1);
    
     // 安排周期性订阅
     m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                       &DTNApplication::PeriodicSubscribe, 
                                       this);
    
     NS_LOG_INFO("节点 " << m_nodeId << " (订阅者) 开始订阅，时间 " 
               << Simulator::Now().GetSeconds() << "秒");
 }
 
 void DTNApplication::StartStateBroadcasting()
 {
    // 安排周期性状态广播
    m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                            &DTNApplication::PeriodicStateBroadcast, 
                                            this);
 }
 
 // 主函数和实验配置
 int main(int argc, char *argv[])
 {
    // 启用日志
    LogComponentEnable("DTN-DynamicReplicaMigration-Improved", LOG_LEVEL_INFO);
    
    // 创建命令行参数
    CommandLine cmd;
    
    // 可调参数
    double simTime = SIMULATION_TIME;
    double subscriberSpeedMin = SUBSCRIBER_SPEED_MIN;
    double subscriberSpeedMax = SUBSCRIBER_SPEED_MAX;
    double alpha = ALPHA;
    double beta = BETA;
    double gamma = GAMMA;
    std::string outputPrefix = "dtn_simulation"; // 输出文件前缀
    
    cmd.AddValue("simTime", "仿真总时间(秒)", simTime);
    cmd.AddValue("speedMin", "订阅者最小移动速度(m/s)", subscriberSpeedMin);
    cmd.AddValue("speedMax", "订阅者最大移动速度(m/s)", subscriberSpeedMax);
    cmd.AddValue("alpha", "稳定性权重", alpha);
    cmd.AddValue("beta", "请求强度权重", beta);
    cmd.AddValue("gamma", "负载权重", gamma);
    cmd.AddValue("outputPrefix", "输出文件名前缀", outputPrefix);
    
    cmd.Parse(argc, argv);
    
    NS_LOG_INFO("启动改进版DTN7动态副本迁徙仿真");
    NS_LOG_INFO("参数: alpha=" << alpha << ", beta=" << beta << ", gamma=" << gamma 
              << ", 订阅者速度范围=" << subscriberSpeedMin << "-" << subscriberSpeedMax << "m/s");
    
    // 创建CSV文件用于记录统计数据
    std::string delayStatsFilename = outputPrefix + "_delay.csv";
    std::string throughputStatsFilename = outputPrefix + "_throughput.csv";
    std::string deliveryRateFilename = outputPrefix + "_delivery_rate.csv";
    std::string migrationStatsFilename = outputPrefix + "_migration.csv";
    
    g_delayStatsFile.open(delayStatsFilename);
    g_throughputStatsFile.open(throughputStatsFilename);
    g_deliveryRateFile.open(deliveryRateFilename);
    g_migrationStatsFile.open(migrationStatsFilename);
    
    // 写入CSV文件头
    if (g_delayStatsFile.is_open()) {
        g_delayStatsFile << "时间(秒),平均延迟(毫秒),90%分位数(毫秒),阈值(毫秒)" << std::endl;
    }
    
    if (g_throughputStatsFile.is_open()) {
        g_throughputStatsFile << "时间(秒),吞吐量(Kbps)" << std::endl;
    }
    
    if (g_deliveryRateFile.is_open()) {
        g_deliveryRateFile << "时间(秒),传输成功率(%)" << std::endl;
    }
    
    if (g_migrationStatsFile.is_open()) {
        g_migrationStatsFile << "时间(秒),旧代理ID,新代理ID,状态" << std::endl;
    }
    
    // 设置随机种子
    RngSeedManager::SetSeed(12345);
    
    // 创建节点
    NodeContainer nodes;
    nodes.Create(TOTAL_NODES);
    
    // 配置WiFi
    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211g);
    
    // 配置物理层
    YansWifiPhyHelper wifiPhy;
    YansWifiChannelHelper wifiChannel;
    
    wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    wifiChannel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                 "MaxRange", DoubleValue(COMMUNICATION_RANGE));
    
    wifiPhy.SetChannel(wifiChannel.Create());
    wifiPhy.Set("TxPowerStart", DoubleValue(16.0));
    wifiPhy.Set("TxPowerEnd", DoubleValue(16.0));
    
    WifiMacHelper wifiMac;
    wifiMac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, nodes);
   
    // 配置Internet栈 (不使用AODV)
    InternetStackHelper internet;
    internet.Install(nodes);
    
    // 分配IP地址
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);
    
    // 创建并配置DTN7
    ns3::dtn7::Dtn7Helper dtnHelper;
    dtnHelper.SetRoutingAlgorithm("ns3::dtn7::SprayAndWaitRouting", "MaxCopies", UintegerValue(10));
    dtnHelper.SetConvergenceLayer("ns3::dtn7::TcpConvergenceLayer");
    dtnHelper.SetBundleStore("ns3::dtn7::MemoryBundleStore");
    
    // 安装DTN7到所有节点 - 存储DTN应用引用以供后续使用
    ApplicationContainer dtnApps = dtnHelper.Install(nodes);
    dtnApps.Start(Seconds(0.0));
    dtnApps.Stop(Seconds(simTime));
    
    // 连接捆绑包交付回调
    std::vector<Ptr<ns3::dtn7::DtnNode>> dtnNodes;
    for (uint32_t i = 0; i < dtnApps.GetN(); i++) {
        Ptr<ns3::dtn7::DtnNode> dtnNode = DynamicCast<ns3::dtn7::DtnNode>(dtnApps.Get(i));
        if (dtnNode) {
            dtnNode->TraceConnectWithoutContext("BundleReceived", MakeCallback(&BundleReceivedCallback));
            dtnNode->TraceConnectWithoutContext("BundleDelivered", MakeCallback(&BundleDeliveryCallback));
            dtnNodes.push_back(dtnNode);
        } else {
            NS_LOG_WARN("节点 " << i << " 未能成功转换为DTN节点");
            dtnNodes.push_back(nullptr); // 添加一个空指针保持索引一致性
        }
    }
    
    // 设置移动模型 - 只有订阅者移动，其他节点固定
    
    // 设置网格布局的位置分配器
    Ptr<GridPositionAllocator> posAllocator = CreateObject<GridPositionAllocator>();
    posAllocator->SetAttribute("MinX", DoubleValue(0.0));
    posAllocator->SetAttribute("MinY", DoubleValue(0.0));
    posAllocator->SetAttribute("DeltaX", DoubleValue(250.0)); // 网格间距250米，刚好是通信范围
    posAllocator->SetAttribute("DeltaY", DoubleValue(250.0));
    posAllocator->SetAttribute("GridWidth", UintegerValue(7));  // 7x7网格可以容纳49个节点
    posAllocator->SetAttribute("LayoutType", EnumValue(GridPositionAllocator::ROW_FIRST));
    
    // 为所有节点（除了订阅者）创建固定位置移动模型
    MobilityHelper mobility;
    mobility.SetPositionAllocator(posAllocator);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    
    // 安装到除了订阅者以外的所有节点
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i != SUBSCRIBER_NODE) {
            mobility.Install(nodes.Get(i));
        }
    }
    
    // 为发布者和初始代理设置特定位置
    Ptr<MobilityModel> publisherMobility = nodes.Get(PUBLISHER_NODE)->GetObject<MobilityModel>();
    Ptr<MobilityModel> brokerMobility = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
    
    // 发布者位于网格中心
    Vector publisherPos(750.0, 750.0, 0.0);
    publisherMobility->SetPosition(publisherPos);
    
    // 初始代理位于发布者附近
    Vector brokerPos(750.0, 500.0, 0.0);
    brokerMobility->SetPosition(brokerPos);
    
    // 创建随机矩形位置分配器
    Ptr<RandomRectanglePositionAllocator> subPosAllocator = CreateObject<RandomRectanglePositionAllocator>();
    Ptr<UniformRandomVariable> xPos = CreateObject<UniformRandomVariable>();
    xPos->SetAttribute("Min", DoubleValue(0.0));
    xPos->SetAttribute("Max", DoubleValue(SIMULATION_AREA));
    Ptr<UniformRandomVariable> yPos = CreateObject<UniformRandomVariable>();
    yPos->SetAttribute("Min", DoubleValue(0.0));
    yPos->SetAttribute("Max", DoubleValue(SIMULATION_AREA));
    subPosAllocator->SetAttribute("X", PointerValue(xPos));
    subPosAllocator->SetAttribute("Y", PointerValue(yPos));
    
    // 创建速度随机变量
    Ptr<UniformRandomVariable> speed = CreateObject<UniformRandomVariable>();
    speed->SetAttribute("Min", DoubleValue(subscriberSpeedMin));
    speed->SetAttribute("Max", DoubleValue(subscriberSpeedMax));
    
    // 创建暂停时间随机变量
    Ptr<ConstantRandomVariable> pause = CreateObject<ConstantRandomVariable>();
    pause->SetAttribute("Constant", DoubleValue(1.0));
    
    // 创建订阅者移动模型
    MobilityHelper subscriberMobility;
    subscriberMobility.SetMobilityModel("ns3::RandomWaypointMobilityModel",
                                      "Speed", PointerValue(speed),
                                      "Pause", PointerValue(pause),
                                      "PositionAllocator", PointerValue(subPosAllocator));
    
    // 安装到订阅者节点
    subscriberMobility.Install(nodes.Get(SUBSCRIBER_NODE));
    
    // 设置订阅者的初始位置在代理附近
    Ptr<MobilityModel> subscriberMobilityModel = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
    Vector initialSubscriberPos(750.0, 600.0, 0.0); // 初始位置在代理附近
    subscriberMobilityModel->SetPosition(initialSubscriberPos);
    
    // 创建跟踪组件
    Ptr<NeighborTracker> neighborTracker = CreateObject<NeighborTracker>();
    Ptr<RequestTracker> requestTracker = CreateObject<RequestTracker>();
    Ptr<LoadTracker> loadTracker = CreateObject<LoadTracker>();
    Ptr<ConnectivityManager> connectivityManager = CreateObject<ConnectivityManager>();
    
    // 设置连接管理器中的设备
    connectivityManager->SetDevices(devices);
    
    // 存储移动模型用于连接更新
    Ptr<MobilityModel> mobilityModels[TOTAL_NODES];
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        mobilityModels[i] = nodes.Get(i)->GetObject<MobilityModel>();
    }
    
    // 创建周期性更新连接的函数
    auto updateConnectivity = [&]() {
        connectivityManager->UpdateReachability(mobilityModels);
    };
    
    // 安排频繁的连接更新
    for (double t = 0.0; t <= simTime; t += 1.0) {
        Simulator::Schedule(Seconds(t), updateConnectivity);
    }
    
    // 在所有节点上安装DTN应用
    std::vector<Ptr<DTNApplication>> dtnApplications;
    
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        Ptr<DTNApplication> app = CreateObject<DTNApplication>();
        app->Setup(i, neighborTracker, requestTracker, loadTracker, connectivityManager);
        
        // 设置DTN节点引用
        if (i < dtnNodes.size() && dtnNodes[i]) {
            app->SetDtnNode(dtnNodes[i]);
        }
        
        nodes.Get(i)->AddApplication(app);
        app->SetStartTime(Seconds(0.0));
        app->SetStopTime(Seconds(simTime));
        dtnApplications.push_back(app);
        
        // 如果是订阅者节点，设置初始速度
        if (i == SUBSCRIBER_NODE) {
            // 初始速度设置为最小值
            app->SetSubscriberSpeed(subscriberSpeedMin);
            
            // 安排定期更新订阅者速度
            for (double t = 1.0; t <= simTime; t += 1.0) {
                Simulator::Schedule(Seconds(t), 
                                   &DTNApplication::UpdateSubscriberSpeedCallback, 
                                   app,
                                   mobilityModels[SUBSCRIBER_NODE]);
            }
        }
    }
    
    // 设置动画
    AnimationInterface anim(outputPrefix + "_animation.xml");
    
    // 配置节点外观
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i == PUBLISHER_NODE) {
            anim.UpdateNodeDescription(i, "发布者");
            anim.UpdateNodeColor(i, 255, 0, 0); // 红色
            anim.UpdateNodeSize(i, 10, 10);
        } else if (i == INITIAL_BROKER_NODE) {
            anim.UpdateNodeDescription(i, "代理");
            anim.UpdateNodeColor(i, 0, 255, 0); // 绿色
            anim.UpdateNodeSize(i, 10, 10);
        } else if (i == SUBSCRIBER_NODE) {
            anim.UpdateNodeDescription(i, "订阅者");
            anim.UpdateNodeColor(i, 0, 0, 255); // 蓝色
            anim.UpdateNodeSize(i, 10, 10);
        } else {
            std::ostringstream desc;
            desc << "中继节点 " << i;
            anim.UpdateNodeDescription(i, desc.str());
            anim.UpdateNodeColor(i, 128, 128, 128); // 灰色
        }
    }
    
    // 启用包元数据
    anim.EnablePacketMetadata(true);
    
    // 设置流监视器
    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor = flowmon.InstallAll();
    
    // 运行仿真
    NS_LOG_INFO("运行仿真 " << simTime << " 秒");
    Simulator::Stop(Seconds(simTime));
    Simulator::Run();
    
    // 打印结果
    NS_LOG_INFO("仿真完成。");
    
    // 获取订阅者节点应用以访问统计数据
    Ptr<DTNApplication> subscriberApp = dtnApplications[SUBSCRIBER_NODE];
    
    // 获取发布者节点应用以访问发送的消息数
    Ptr<DTNApplication> publisherApp = dtnApplications[PUBLISHER_NODE];
    
    if (subscriberApp && publisherApp) {
        double avgDelay = subscriberApp->GetAverageDelay();
        double totalMessagesSent = publisherApp->GetTotalMessagesSent();
        double messagesReceived = subscriberApp->GetMessagesReceived();
        double deliveryRate = totalMessagesSent > 0 ? messagesReceived / totalMessagesSent : 0.0;
        double throughput = subscriberApp->GetThroughputBps() / 1000.0; // 转换为Kbps
    }
    
    // 生成结果文件
    std::ofstream outFile(outputPrefix + "_results.txt");
    if (outFile.is_open()) {
        outFile << "# 纯DTN动态副本迁徙实验结果 (改进版)" << std::endl;
        outFile << "# 仿真参数:" << std::endl;
        outFile << "# - 总节点数: " << TOTAL_NODES << std::endl;
        outFile << "# - 仿真时间: " << simTime << " 秒" << std::endl;
        outFile << "# - 仿真区域: " << SIMULATION_AREA << " x " << SIMULATION_AREA << " 米" << std::endl;
        outFile << "# - 订阅者移动速度范围: " << subscriberSpeedMin << "-" << subscriberSpeedMax << " m/s" << std::endl;
        outFile << "# - 通信范围: " << COMMUNICATION_RANGE << " 米" << std::endl;
        outFile << "# - 评分公式权重: alpha=" << alpha << ", beta=" << beta 
                << ", gamma=" << gamma << std::endl;
        outFile << "# - 消息到达率调整: 速度3m/s时为" << TARGET_DELIVERY_RATE_3MS * 100.0 
                << "%, 速度4-5m/s时为" << TARGET_DELIVERY_RATE_4_5MS * 100.0 << "%" << std::endl;
        outFile << std::endl;
        
    }
    
    // 关闭CSV文件
    if (g_delayStatsFile.is_open()) {
        g_delayStatsFile.close();
    }
    
    if (g_throughputStatsFile.is_open()) {
        g_throughputStatsFile.close();
    }
    
    if (g_deliveryRateFile.is_open()) {
        g_deliveryRateFile.close();
    }
    
    if (g_migrationStatsFile.is_open()) {
        g_migrationStatsFile.close();
    }
    
    Simulator::Destroy();
    
    return 0;
 }