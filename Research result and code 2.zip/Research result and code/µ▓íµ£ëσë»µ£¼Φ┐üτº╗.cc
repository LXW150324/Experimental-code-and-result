/* 
 * MANET Without Dynamic Replica Migration Experiment (对比实验)
 * NS-3.44 Implementation
 *
 * 这个对比实验版本移除了动态副本迁移机制，用于展示在无迁移情况下：
 * - 更高的subscriber移动速度导致更高的平均延迟
 * - 更高的subscriber移动速度导致更低的消息交付率
 * - 更高的subscriber移动速度导致更低的吞吐量
 */

 #include "ns3/core-module.h"
 #include "ns3/network-module.h"
 #include "ns3/mobility-module.h"
 #include "ns3/internet-module.h"
 #include "ns3/applications-module.h"
 #include "ns3/wifi-module.h"
 #include "ns3/aodv-module.h"
 #include "ns3/netanim-module.h"
 #include "ns3/flow-monitor-module.h"
 #include <fstream>
 #include <vector>
 #include <map>
 #include <string>
 #include <algorithm>
 #include <cmath>
 #include <random>
 #include <queue>
 #include <limits>
 
 using namespace ns3;
 
 NS_LOG_COMPONENT_DEFINE("MANETWithoutMigration");
 
 // 实验常量
 const uint32_t TOTAL_NODES = 50;        // 网络中节点总数
 const uint32_t PUBLISHER_NODE = 0;      // 发布者节点ID
 const uint32_t INITIAL_BROKER_NODE = 1; // 初始代理节点ID
 const uint32_t SUBSCRIBER_NODE = 2;     // 订阅者节点ID
 const double SIMULATION_TIME = 300.0;   // 模拟总时间(秒)
 double MOBILITY_SPEED = 2.8;            // 默认订阅者移动速度(m/s)，将从命令行更新
 double COMMUNICATION_RANGE = 250.0;     // 直接通信范围(米)
 const double SIMULATION_AREA = 1000.0;  // 1000m x 1000m模拟区域
 const uint32_t PUBLISH_RATE = 50;       // 50条消息/秒
 const double REQUEST_INTERVAL = 2.0;    // 订阅者每2秒请求一次
 const double STATE_BROADCAST_INTERVAL = 5.0; // 每5秒广播一次状态信息
 const double CONNECTIVITY_UPDATE_INTERVAL = 1.0; // 每1秒更新一次连接性
 
 // 辅助函数 - 计算两点间距离
 double CalculateVectorDistance(const Vector& p1, const Vector& p2) {
     double dx = p1.x - p2.x;
     double dy = p1.y - p2.y;
     return std::sqrt(dx*dx + dy*dy);
 }
 
 // 数据包类型枚举
 enum PacketType {
     SUBSCRIBE_REQUEST = 1,
     DATA_RESPONSE = 2,
     STATE_BROADCAST = 3,
     DATA_RESPONSE_ACK = 6    // 数据确认消息类型
 };
 
 // 节点状态信息结构
 struct NodeState {
     uint32_t nodeId;
     double stability;          // S: 1 - (neighbor changes / upper limit)
     double requestIntensity;   // I: requests from this node / highest request count
     double load;               // L: used cache / total cache
     bool reachableToSubscriber; // 此节点是否可以到达订阅者
     Time lastUpdateTime;       // 最后更新状态的时间
     
     NodeState() : nodeId(0), stability(0.0), requestIntensity(0.0), 
                   load(0.0), reachableToSubscriber(false) {}
 };
 
 // 跟踪节点邻居变化的类
 class NeighborTracker : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_neighbors;      // 每个节点的当前邻居
     std::map<uint32_t, uint32_t> m_neighborChangeCount;      // 邻居变化计数
     const uint32_t m_maxNeighborChanges;                     // 邻居变化上限
     
 public:
     NeighborTracker() : m_maxNeighborChanges(20) {
         // 初始化所有节点的邻居变化计数
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_neighborChangeCount[i] = 0;
         }
     }
     
     void UpdateNeighbors(uint32_t nodeId, const std::set<uint32_t>& currentNeighbors) {
         // 如果这是第一次更新，只需存储邻居
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             m_neighbors[nodeId] = currentNeighbors;
             return;
         }
         
         // 计算有多少邻居发生变化
         std::set<uint32_t> oldNeighbors = m_neighbors[nodeId];
         uint32_t changes = 0;
         
         // 查找被移除的邻居
         std::vector<uint32_t> removedNeighbors;
         for (auto& oldNeighbor : oldNeighbors) {
             if (currentNeighbors.find(oldNeighbor) == currentNeighbors.end()) {
                 changes++;
                 removedNeighbors.push_back(oldNeighbor);
             }
         }
         
         // 查找新增的邻居
         std::vector<uint32_t> addedNeighbors;
         for (auto& newNeighbor : currentNeighbors) {
             if (oldNeighbors.find(newNeighbor) == oldNeighbors.end()) {
                 changes++;
                 addedNeighbors.push_back(newNeighbor);
             }
         }
         
         // 更新邻居变化计数
         m_neighborChangeCount[nodeId] += changes;
         
         // 更新存储的邻居
         m_neighbors[nodeId] = currentNeighbors;
     }
     
     double GetStability(uint32_t nodeId) const {
         // S = 1 - (邻居变化数 / 固定上限)
         if (m_neighborChangeCount.find(nodeId) == m_neighborChangeCount.end()) {
             return 1.0; // 尚未记录变化
         }
         
         double stability = 1.0 - ((double)m_neighborChangeCount.at(nodeId) / m_maxNeighborChanges);
         return std::max(0.0, std::min(1.0, stability)); // 限制在0和1之间
     }
     
     const std::set<uint32_t>& GetNeighbors(uint32_t nodeId) const {
         static const std::set<uint32_t> emptySet;
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             return emptySet;
         }
         return m_neighbors.at(nodeId);
     }
     
     bool AreNeighbors(uint32_t node1, uint32_t node2) const {
         if (m_neighbors.find(node1) == m_neighbors.end()) {
             return false;
         }
         return m_neighbors.at(node1).find(node2) != m_neighbors.at(node1).end();
     }
 };
 
 // 跟踪请求强度的类
 class RequestTracker : public Object {
 private:
     std::map<uint32_t, uint32_t> m_requestCount;  // 每个节点的请求计数
     uint32_t m_maxRequests;                       // 网络中最高请求计数
     
 public:
     RequestTracker() : m_maxRequests(1) {} // 初始化为1以避免除零
     
     void IncrementRequestCount(uint32_t nodeId) {
         m_requestCount[nodeId]++;
         // 如果需要，更新最大请求数
         if (m_requestCount[nodeId] > m_maxRequests) {
             m_maxRequests = m_requestCount[nodeId];
         }
     }
     
     double GetRequestIntensity(uint32_t nodeId) const {
         // I = (此节点在此期间的请求数) / (网络中最高请求数)
         if (m_requestCount.find(nodeId) == m_requestCount.end()) {
             return 0.0; // 该节点没有请求
         }
         
         return (double)m_requestCount.at(nodeId) / m_maxRequests;
     }
 };
 
 // 跟踪节点负载的类
 class LoadTracker : public Object {
 private:
     std::map<uint32_t, double> m_nodeLoad;  // 每个节点的负载(0.0到1.0)
     
 public:
     LoadTracker() {
         // 初始化随机负载在0.1到0.5之间
         std::random_device rd;
         std::mt19937 gen(rd());
         std::uniform_real_distribution<> dis(0.1, 0.5);
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_nodeLoad[i] = dis(gen);
         }
     }
     
     void UpdateLoad(uint32_t nodeId, double load) {
         m_nodeLoad[nodeId] = std::max(0.0, std::min(1.0, load)); // 限制在0和1之间
     }
     
     double GetLoad(uint32_t nodeId) const {
         if (m_nodeLoad.find(nodeId) == m_nodeLoad.end()) {
             return 0.0; // 默认为0负载
         }
         
         return m_nodeLoad.at(nodeId);
     }
 };
 
 // 管理节点间连接性和可达性的类
 class ConnectivityManager : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_reachableNodes;  // 每个节点可达的节点
     Ptr<NetDevice> m_devices[TOTAL_NODES];                    // 所有节点的网络设备
     
 public:
     ConnectivityManager() {}
     
     void SetDevices(NetDeviceContainer devices) {
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_devices[i] = devices.Get(i);
         }
     }
     
     void UpdateReachability(Ptr<MobilityModel> mobilityModels[TOTAL_NODES]) {
         // 清除之前的可达性数据
         m_reachableNodes.clear();
         
         // 首先，基于距离确定直接可达性
         std::map<uint32_t, std::set<uint32_t>> directReachable;
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             for (uint32_t j = 0; j < TOTAL_NODES; j++) {
                 if (i == j) continue;
                 
                 // 计算节点间距离
                 double distance = mobilityModels[i]->GetDistanceFrom(mobilityModels[j]);
                 
                 // 如果距离在通信范围内，则可以直接连接
                 if (distance <= COMMUNICATION_RANGE) {
                     directReachable[i].insert(j);
                 }
             }
         }
         
         // 现在使用BFS确定每个节点的完整可达性
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             std::queue<uint32_t> nodesToVisit;
             std::set<uint32_t> visited;
             
             // 从当前节点开始
             nodesToVisit.push(i);
             visited.insert(i);
             
             // BFS查找所有可达节点
             while (!nodesToVisit.empty()) {
                 uint32_t currentNode = nodesToVisit.front();
                 nodesToVisit.pop();
                 
                 // 添加到可达节点
                 if (currentNode != i) {
                     m_reachableNodes[i].insert(currentNode);
                 }
                 
                 // 探索当前节点的直接邻居
                 for (uint32_t neighbor : directReachable[currentNode]) {
                     if (visited.find(neighbor) == visited.end()) {
                         visited.insert(neighbor);
                         nodesToVisit.push(neighbor);
                     }
                 }
             }
         }
         
         // 记录重要的可达性变化
         bool subCanReachBroker = IsReachable(SUBSCRIBER_NODE, INITIAL_BROKER_NODE);
         bool brokerCanReachSub = IsReachable(INITIAL_BROKER_NODE, SUBSCRIBER_NODE);
         
         NS_LOG_INFO("可达性更新时间" << Simulator::Now().GetSeconds() << "秒: "
                     << "订阅者可达代理: " << (subCanReachBroker ? "是" : "否")
                     << ", 代理可达订阅者: " << (brokerCanReachSub ? "是" : "否"));
         
         // 记录订阅者可达节点数
         NS_LOG_INFO("订阅者可达 " << m_reachableNodes[SUBSCRIBER_NODE].size() 
                     << " 个节点，总共 " << TOTAL_NODES << " 个");
     }
     
     bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
         if (m_reachableNodes.find(fromNode) == m_reachableNodes.end()) {
             return false;
         }
         
         return m_reachableNodes.at(fromNode).find(toNode) != m_reachableNodes.at(fromNode).end();
     }
     
     std::set<uint32_t> GetNodesInSamePartition(uint32_t nodeId) const {
         if (m_reachableNodes.find(nodeId) == m_reachableNodes.end()) {
             return std::set<uint32_t>(); // 空集
         }
         
         // 包括节点本身
         std::set<uint32_t> result = m_reachableNodes.at(nodeId);
         result.insert(nodeId);
         
         return result;
     }
 };
 
 // 应用程序消息的自定义头
 class MessageHeader : public Header 
 {
 public:
     MessageHeader();
     virtual ~MessageHeader();
     
     // 设置消息属性
     void SetType(uint8_t type);
     void SetSourceId(uint32_t sourceId);
     void SetDestId(uint32_t destId);
     void SetDataId(uint32_t dataId);
     void SetTimestamp(Time timestamp);
     
     // 获取消息属性
     uint8_t GetType() const;
     uint32_t GetSourceId() const;
     uint32_t GetDestId() const;
     uint32_t GetDataId() const;
     Time GetTimestamp() const;
     
     // 头部序列化/反序列化
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint8_t m_type;        // 数据包类型
     uint32_t m_sourceId;   // 源节点ID
     uint32_t m_destId;     // 目标节点ID
     uint32_t m_dataId;     // 数据/内容ID
     uint64_t m_timestamp;  // 时间戳(用于计算延迟)
 };
 
 MessageHeader::MessageHeader()
     : m_type(0), m_sourceId(0), m_destId(0), m_dataId(0), m_timestamp(0)
 {
 }
 
 MessageHeader::~MessageHeader()
 {
 }
 
 TypeId MessageHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::MessageHeader")
         .SetParent<Header>()
         .AddConstructor<MessageHeader>();
     return tid;
 }
 
 TypeId MessageHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void MessageHeader::SetType(uint8_t type)
 {
     m_type = type;
 }
 
 void MessageHeader::SetSourceId(uint32_t sourceId)
 {
     m_sourceId = sourceId;
 }
 
 void MessageHeader::SetDestId(uint32_t destId)
 {
     m_destId = destId;
 }
 
 void MessageHeader::SetDataId(uint32_t dataId)
 {
     m_dataId = dataId;
 }
 
 void MessageHeader::SetTimestamp(Time timestamp)
 {
     m_timestamp = timestamp.GetNanoSeconds();
 }
 
 uint8_t MessageHeader::GetType() const
 {
     return m_type;
 }
 
 uint32_t MessageHeader::GetSourceId() const
 {
     return m_sourceId;
 }
 
 uint32_t MessageHeader::GetDestId() const
 {
     return m_destId;
 }
 
 uint32_t MessageHeader::GetDataId() const
 {
     return m_dataId;
 }
 
 Time MessageHeader::GetTimestamp() const
 {
     return Time(NanoSeconds(m_timestamp));
 }
 
 uint32_t MessageHeader::GetSerializedSize() const
 {
     return 1 + 4 + 4 + 4 + 8; // type + sourceId + destId + dataId + timestamp
 }
 
 void MessageHeader::Serialize(Buffer::Iterator start) const
 {
     start.WriteU8(m_type);
     start.WriteHtonU32(m_sourceId);
     start.WriteHtonU32(m_destId);
     start.WriteHtonU32(m_dataId);
     start.WriteHtonU64(m_timestamp);
 }
 
 uint32_t MessageHeader::Deserialize(Buffer::Iterator start)
 {
     m_type = start.ReadU8();
     m_sourceId = start.ReadNtohU32();
     m_destId = start.ReadNtohU32();
     m_dataId = start.ReadNtohU32();
     m_timestamp = start.ReadNtohU64();
     return GetSerializedSize();
 }
 
 void MessageHeader::Print(std::ostream &os) const
 {
     os << "MessageHeader [Type=" << (uint32_t)m_type 
        << ", SourceId=" << m_sourceId 
        << ", DestId=" << m_destId 
        << ", DataId=" << m_dataId 
        << ", Timestamp=" << m_timestamp << "]";
 }
 
 // 节点状态头，用于广播节点状态信息
 class NodeStateHeader : public Header 
 {
 public:
     NodeStateHeader();
     virtual ~NodeStateHeader();
     
     // 设置状态属性
     void SetNodeId(uint32_t nodeId);
     void SetStability(double stability);
     void SetRequestIntensity(double requestIntensity);
     void SetLoad(double load);
     
     // 获取状态属性
     uint32_t GetNodeId() const;
     double GetStability() const;
     double GetRequestIntensity() const;
     double GetLoad() const;
     
     // 头部序列化/反序列化
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint32_t m_nodeId;           // 节点ID
     double m_stability;          // 稳定性因子(S)
     double m_requestIntensity;   // 请求强度因子(I)
     double m_load;               // 负载因子(L)
 };
 
 NodeStateHeader::NodeStateHeader()
     : m_nodeId(0), m_stability(0.0), m_requestIntensity(0.0), m_load(0.0)
 {
 }
 
 NodeStateHeader::~NodeStateHeader()
 {
 }
 
 TypeId NodeStateHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::NodeStateHeader")
         .SetParent<Header>()
         .AddConstructor<NodeStateHeader>();
     return tid;
 }
 
 TypeId NodeStateHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void NodeStateHeader::SetNodeId(uint32_t nodeId)
 {
     m_nodeId = nodeId;
 }
 
 void NodeStateHeader::SetStability(double stability)
 {
     m_stability = stability;
 }
 
 void NodeStateHeader::SetRequestIntensity(double requestIntensity)
 {
     m_requestIntensity = requestIntensity;
 }
 
 void NodeStateHeader::SetLoad(double load)
 {
     m_load = load;
 }
 
 uint32_t NodeStateHeader::GetNodeId() const
 {
     return m_nodeId;
 }
 
 double NodeStateHeader::GetStability() const
 {
     return m_stability;
 }
 
 double NodeStateHeader::GetRequestIntensity() const
 {
     return m_requestIntensity;
 }
 
 double NodeStateHeader::GetLoad() const
 {
     return m_load;
 }
 
 uint32_t NodeStateHeader::GetSerializedSize() const
 {
     return 4 + 8 + 8 + 8; // nodeId + stability + requestIntensity + load
 }
 
 void NodeStateHeader::Serialize(Buffer::Iterator start) const
 {
     // 写入节点ID
     start.WriteHtonU32(m_nodeId);
     
     // 将浮点值转换为定点表示
     uint64_t stabilityFixed = static_cast<uint64_t>(m_stability * 1000000.0);
     uint64_t requestIntensityFixed = static_cast<uint64_t>(m_requestIntensity * 1000000.0);
     uint64_t loadFixed = static_cast<uint64_t>(m_load * 1000000.0);
     
     // 写入定点值
     start.WriteHtonU64(stabilityFixed);
     start.WriteHtonU64(requestIntensityFixed);
     start.WriteHtonU64(loadFixed);
 }
 
 uint32_t NodeStateHeader::Deserialize(Buffer::Iterator start)
 {
     // 读取节点ID
     m_nodeId = start.ReadNtohU32();
     
     // 读取定点值
     uint64_t stabilityFixed = start.ReadNtohU64();
     uint64_t requestIntensityFixed = start.ReadNtohU64();
     uint64_t loadFixed = start.ReadNtohU64();
     
     // 将定点值转回浮点数
     m_stability = static_cast<double>(stabilityFixed) / 1000000.0;
     m_requestIntensity = static_cast<double>(requestIntensityFixed) / 1000000.0;
     m_load = static_cast<double>(loadFixed) / 1000000.0;
     
     return GetSerializedSize();
 }
 
 void NodeStateHeader::Print(std::ostream &os) const
 {
     os << "NodeStateHeader [NodeId=" << m_nodeId 
        << ", Stability=" << m_stability 
        << ", RequestIntensity=" << m_requestIntensity 
        << ", Load=" << m_load << "]";
 }
 
 // 无副本迁移的MANET应用程序类
 class MANETWithoutMigrationApp : public Application
 {
 public:
     static TypeId GetTypeId();
     MANETWithoutMigrationApp();
     virtual ~MANETWithoutMigrationApp();
     
     void Setup(uint32_t nodeId, 
                Ptr<NeighborTracker> neighborTracker,
                Ptr<RequestTracker> requestTracker,
                Ptr<LoadTracker> loadTracker,
                Ptr<ConnectivityManager> connectivityManager);
     
     void StartApplication() override;
     void StopApplication() override;
     
     // 向特定节点发送数据包
     void SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId);
     
     // 开始发布数据(仅限Publisher)
     void StartPublishing();
     
     // 开始发送订阅请求(仅限Subscriber)
     void StartSubscribing();
     
     // 开始广播状态信息
     void StartStateBroadcasting();
     
     // 处理接收到的数据包
     void HandleRead(Ptr<Socket> socket);
     
     // 用于跟踪延迟和交付率
     void RecordDelay(Time delay);
     void RecordMessageSent();
     void RecordMessageReceived();
     double GetAverageDelay() const;
     double GetDeliveryRate() const;
     
     // 吞吐量计算方法
     double GetAverageThroughput() const;
 
     // 获取消息计数器
     uint32_t GetMessagesSent() const { return m_messagesSent; }
     uint32_t GetMessagesReceived() const { return m_messagesReceived; }
     
     // 检查连接性周期性事件
     void PeriodicConnectivityCheck();
     
 private:
     // 更新基于当前连接性的邻居列表
     void UpdateNeighbors();
     
     // 计划的事件
     void PeriodicSubscribe();
     void PeriodicPublish();
     void PeriodicStateBroadcast();
     
     // 通信套接字
     Ptr<Socket> m_socket;
     
     // 节点信息
     uint32_t m_nodeId;
     std::set<uint32_t> m_localContent;  // 本地存储的内容ID
     
     // 跟踪组件
     Ptr<NeighborTracker> m_neighborTracker;
     Ptr<RequestTracker> m_requestTracker;
     Ptr<LoadTracker> m_loadTracker;
     Ptr<ConnectivityManager> m_connectivityManager;
     
     // 统计数据
     std::vector<Time> m_delays;
     uint32_t m_messagesSent;
     uint32_t m_messagesReceived;
     
     // 当前节点状态
     std::map<uint32_t, NodeState> m_nodeStates;
     std::set<uint32_t> m_currentNeighbors;
     
     // 用于调度的事件ID
     EventId m_subscribeEvent;
     EventId m_publishEvent;
     EventId m_stateBroadcastEvent;
     EventId m_connectivityCheckEvent;
     
     // 应用程序运行状态
     bool m_running;
 };
 
 NS_OBJECT_ENSURE_REGISTERED(MANETWithoutMigrationApp);
 
 TypeId MANETWithoutMigrationApp::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::MANETWithoutMigrationApp")
         .SetParent<Application>()
         .AddConstructor<MANETWithoutMigrationApp>();
     return tid;
 }
 
 MANETWithoutMigrationApp::MANETWithoutMigrationApp()
     : m_nodeId(0),
       m_messagesSent(0),
       m_messagesReceived(0),
       m_running(false)  // 初始化为非运行状态
 {
     
 }
 
 MANETWithoutMigrationApp::~MANETWithoutMigrationApp()
 {
 }
 
 void MANETWithoutMigrationApp::Setup(uint32_t nodeId, 
                             Ptr<NeighborTracker> neighborTracker,
                             Ptr<RequestTracker> requestTracker,
                             Ptr<LoadTracker> loadTracker,
                             Ptr<ConnectivityManager> connectivityManager)
 {
     m_nodeId = nodeId;
     m_neighborTracker = neighborTracker;
     m_requestTracker = requestTracker;
     m_loadTracker = loadTracker;
     m_connectivityManager = connectivityManager;
     
     // Publisher和Broker有初始内容
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE) {
         m_localContent.insert(1); // 内容ID 1
     }
 }
 
 void MANETWithoutMigrationApp::StartApplication()
 {
     // 设置为运行状态
     m_running = true;
     
     // 创建并设置套接字
     if (!m_socket) {
         m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
         InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), 9);
         m_socket->Bind(local);
         m_socket->SetRecvCallback(MakeCallback(&MANETWithoutMigrationApp::HandleRead, this));
     }
     
     // 开始定期连接性检查，使用非零延迟确保模拟器已经初始化
     m_connectivityCheckEvent = Simulator::Schedule(MilliSeconds(10), 
                                                  &MANETWithoutMigrationApp::PeriodicConnectivityCheck, 
                                                  this);
     
     // 开始广播状态信息，使用不同的延迟，避免事件冲突
     if (m_nodeId != PUBLISHER_NODE) { // Publisher不需要广播状态
         Simulator::Schedule(MilliSeconds(20), &MANETWithoutMigrationApp::StartStateBroadcasting, this);
     }
     
     // 特定角色
     if (m_nodeId == PUBLISHER_NODE) {
         // Publisher开始发布，使用不同的延迟，避免事件冲突
         Simulator::Schedule(MilliSeconds(30), &MANETWithoutMigrationApp::StartPublishing, this);
     } else if (m_nodeId == SUBSCRIBER_NODE) {
         // Subscriber在短暂延迟后开始订阅，确保所有初始化已完成
         Simulator::Schedule(MilliSeconds(50), &MANETWithoutMigrationApp::StartSubscribing, this);
     }
     
     // 记录应用程序启动
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE || m_nodeId == SUBSCRIBER_NODE) {
         NS_LOG_INFO("节点 " << m_nodeId << " (" << 
                     (m_nodeId == PUBLISHER_NODE ? "Publisher" : 
                      (m_nodeId == INITIAL_BROKER_NODE ? "Broker" : "Subscriber")) << 
                     ") 应用程序在 " << Simulator::Now().GetSeconds() << "秒启动");
     }
 }
 
 void MANETWithoutMigrationApp::StopApplication()
 {
     // 设置为非运行状态
     m_running = false;
     
     // 取消任何挂起的事件
     if (m_subscribeEvent.IsRunning()) {
         Simulator::Cancel(m_subscribeEvent);
     }
     
     if (m_publishEvent.IsRunning()) {
         Simulator::Cancel(m_publishEvent);
     }
     
     if (m_stateBroadcastEvent.IsRunning()) {
         Simulator::Cancel(m_stateBroadcastEvent);
     }
     
     if (m_connectivityCheckEvent.IsRunning()) {
         Simulator::Cancel(m_connectivityCheckEvent);
     }
     
     // 关闭套接字
     if (m_socket) {
         m_socket->Close();
     }
 }
 
 void MANETWithoutMigrationApp::SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId)
 {
     // 如果当前应用已停止，不发送数据包
     if (!m_running) {
         return;
     }
     
     // 确认数据包可以传递给目标节点(是否可达)
     if (packetType != STATE_BROADCAST) {
         bool isReachable = m_connectivityManager->IsReachable(m_nodeId, destId);
         
         if (!isReachable) {
             NS_LOG_INFO("节点 " << m_nodeId << " 无法发送 " << (int)packetType 
                         << " 到节点 " << destId << " - 不可达");
             return;
         }
     }
     
     // 创建带头部的数据包
     Ptr<Packet> packet = Create<Packet>(100); // 添加100字节的有效负载
     
     MessageHeader header;
     header.SetType(packetType);
     header.SetSourceId(m_nodeId);
     header.SetDestId(destId);
     header.SetDataId(dataId);
     header.SetTimestamp(Simulator::Now());
     
     packet->AddHeader(header);
     
     // 如果发送状态广播，添加节点状态头
     if (packetType == STATE_BROADCAST) {
         NodeStateHeader stateHeader;
         stateHeader.SetNodeId(m_nodeId);
         stateHeader.SetStability(m_neighborTracker->GetStability(m_nodeId));
         stateHeader.SetRequestIntensity(m_requestTracker->GetRequestIntensity(m_nodeId));
         stateHeader.SetLoad(m_loadTracker->GetLoad(m_nodeId));
         
         packet->AddHeader(stateHeader);
     }
     
     // 添加目标IP地址
     Ptr<Node> node = GetNode();
     Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
     
     // 获取目标IP(假设节点有IP地址10.1.1.X，其中X是节点ID + 1)
     std::ostringstream oss;
     oss << "10.1.1." << (destId + 1);
     Ipv4Address ipDest(oss.str().c_str());
     
     // 发送数据包
     m_socket->SendTo(packet, 0, InetSocketAddress(ipDest, 9));
     
     // 只统计Subscriber的SUBSCRIBE_REQUEST消息和Broker的DATA_RESPONSE消息
     if ((m_nodeId == SUBSCRIBER_NODE && packetType == SUBSCRIBE_REQUEST) ||
         (m_nodeId == INITIAL_BROKER_NODE && packetType == DATA_RESPONSE && destId == SUBSCRIBER_NODE)) {
         RecordMessageSent();
     }
     
     // 记录重要数据包类型的传输
     if (packetType == SUBSCRIBE_REQUEST || 
         packetType == DATA_RESPONSE || 
         packetType == DATA_RESPONSE_ACK) {
         
         NS_LOG_INFO("节点 " << m_nodeId << " 发送 " << (int)packetType << " 数据包到节点 " << destId
                     << " 时间 " << Simulator::Now().GetSeconds() << "秒");
     }
 }
 
 void MANETWithoutMigrationApp::StartPublishing()
 {
     // 安排定期发布, 使用微秒级别的延迟防止边界条件
     m_publishEvent = Simulator::Schedule(MilliSeconds(1000.0 / PUBLISH_RATE), 
                                          &MANETWithoutMigrationApp::PeriodicPublish, 
                                          this);
 }
 
 void MANETWithoutMigrationApp::StartSubscribing()
 {
     // 向当前broker发送初始订阅请求
     SendPacket(INITIAL_BROKER_NODE, SUBSCRIBE_REQUEST, 1);
     
     // 安排定期订阅, 使用微秒级别的延迟防止边界条件
     m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL) + MicroSeconds(1), 
                                           &MANETWithoutMigrationApp::PeriodicSubscribe, 
                                           this);
     
     NS_LOG_INFO("节点 " << m_nodeId << " (Subscriber) 在 " 
                 << Simulator::Now().GetSeconds() << "秒开始订阅");
 }
 
 void MANETWithoutMigrationApp::StartStateBroadcasting()
 {
     // 安排定期状态广播, 使用微秒级别的延迟防止边界条件
     m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL) + MicroSeconds(2), 
                                                &MANETWithoutMigrationApp::PeriodicStateBroadcast, 
                                                this);
 }
 
 void MANETWithoutMigrationApp::HandleRead(Ptr<Socket> socket)
 {
     Ptr<Packet> packet;
     Address from;
     
     // 接收数据包
     while ((packet = socket->RecvFrom(from))) {
         // 提取消息头
         MessageHeader header;
         packet->RemoveHeader(header);
         
         uint8_t packetType = header.GetType();
         uint32_t sourceId = header.GetSourceId();
         uint32_t destId = header.GetDestId();
         uint32_t dataId = header.GetDataId();
         Time timestamp = header.GetTimestamp();
         
         // 特别处理针对订阅者的数据响应包
         if (packetType == DATA_RESPONSE && m_nodeId == SUBSCRIBER_NODE) {
             // 使用真实的网络传输延迟计算，确保延迟非负
             Time now = Simulator::Now();
             
             // 确保时间戳不大于当前时间，避免负延迟
             // 这可能发生在模拟器边界条件或者时钟同步问题时
             Time delay;
             if (now > timestamp) {
                 delay = now - timestamp;
             } else {
                 // 如果发生了边界情况，使用最小正延迟
                 delay = MicroSeconds(1);
                 NS_LOG_WARN("检测到时间戳问题，sourceId=" << sourceId << ", destId=" << destId << 
                           ", timestamp=" << timestamp.GetSeconds() << "s, now=" << now.GetSeconds() << "s");
             }
             
             // 记录实际延迟
             RecordDelay(delay);
             RecordMessageReceived();
             
             NS_LOG_INFO("节点 " << m_nodeId << " (subscriber) 从节点 " 
                         << sourceId << " 接收到数据响应，延迟 " << delay.GetMilliSeconds() 
                         << "ms，时间 " << Simulator::Now().GetSeconds() << "秒");
             
             // 发送确认消息
             // 使用微秒级延迟避免出现负延迟问题
             Simulator::Schedule(MicroSeconds(10), &MANETWithoutMigrationApp::SendPacket, this, 
                               sourceId, DATA_RESPONSE_ACK, dataId);
         }
         // 处理订阅请求
         else if (packetType == SUBSCRIBE_REQUEST) {
             // Broker接收来自订阅者的订阅请求
             if (m_nodeId == INITIAL_BROKER_NODE && m_localContent.find(dataId) != m_localContent.end()) {
                 // 如果此节点有请求的内容，发送响应
                 // 使用微秒级延迟避免出现负延迟问题
                 Simulator::Schedule(MicroSeconds(10), &MANETWithoutMigrationApp::SendPacket, this, 
                                    sourceId, DATA_RESPONSE, dataId);
                                    
                 NS_LOG_INFO("节点 " << m_nodeId << " (broker) 响应来自节点 " 
                             << sourceId << " 的订阅请求，时间 " << Simulator::Now().GetSeconds() << "秒");
             }
             
             // 更新源节点的请求强度
             m_requestTracker->IncrementRequestCount(sourceId);
         }
         // 处理状态广播消息
         else if (packetType == STATE_BROADCAST) {
             // 提取节点状态头
             NodeStateHeader stateHeader;
             packet->RemoveHeader(stateHeader);
             
             uint32_t stateNodeId = stateHeader.GetNodeId();
             double stability = stateHeader.GetStability();
             double requestIntensity = stateHeader.GetRequestIntensity();
             double load = stateHeader.GetLoad();
             
             // 更新节点状态信息
             NodeState state;
             state.nodeId = stateNodeId;
             state.stability = stability;
             state.requestIntensity = requestIntensity;
             state.load = load;
             state.reachableToSubscriber = m_connectivityManager->IsReachable(stateNodeId, SUBSCRIBER_NODE);
             state.lastUpdateTime = Simulator::Now();
             
             m_nodeStates[stateNodeId] = state;
         }
     }
 }
 
 void MANETWithoutMigrationApp::RecordDelay(Time delay)
 {
     m_delays.push_back(delay);
 }
 
 void MANETWithoutMigrationApp::RecordMessageSent()
 {
     m_messagesSent++;
 }
 
 void MANETWithoutMigrationApp::RecordMessageReceived()
 {
     m_messagesReceived++;
 }
 
 double MANETWithoutMigrationApp::GetAverageDelay() const
 {
     if (m_delays.empty()) {
         return 0.0;
     }
     
     Time totalDelay = Time(0);
     for (const auto& delay : m_delays) {
         totalDelay += delay;
     }
     
     return totalDelay.GetSeconds() / m_delays.size();
 }
 
 double MANETWithoutMigrationApp::GetDeliveryRate() const
 {
     if (m_messagesSent == 0) {
         return 0.0;
     }
     
     // 计算实际交付率
     return (double)m_messagesReceived / m_messagesSent;
 }
 
 // 计算平均吞吐量
 double MANETWithoutMigrationApp::GetAverageThroughput() const
 {
     // 吞吐量 = 发布速率(PUBLISH_RATE) × 消息到达率
     return PUBLISH_RATE * GetDeliveryRate();
 }
 
 void MANETWithoutMigrationApp::UpdateNeighbors()
 {
     // 获取基于连接性的当前邻居集
     std::set<uint32_t> neighbors;
     
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i == m_nodeId) continue;
         
         // 如果从此节点可直接到达节点i，则它是邻居
         bool isReachable = m_connectivityManager->IsReachable(m_nodeId, i);
         
         // 如果可达，它是邻居
         if (isReachable) {
             neighbors.insert(i);
         }
     }
     
     // 用新的邻居集更新邻居跟踪器
     m_neighborTracker->UpdateNeighbors(m_nodeId, neighbors);
     
     // 更新本地邻居集
     m_currentNeighbors = neighbors;
 }
 
 void MANETWithoutMigrationApp::PeriodicSubscribe()
 {
     // 确保应用程序仍在运行
     if (!m_running) {
         return;
     }
     
     // 发送订阅请求到broker
     SendPacket(INITIAL_BROKER_NODE, SUBSCRIBE_REQUEST, 1);
     
     // 安排下一次订阅请求, 添加微小延迟避免边界条件
     m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL) + MicroSeconds(1), 
                                           &MANETWithoutMigrationApp::PeriodicSubscribe, 
                                           this);
 }
 
 void MANETWithoutMigrationApp::PeriodicPublish()
 {
     // 确保应用程序仍在运行
     if (!m_running) {
         return;
     }
     
     // Publisher向broker发送数据
     if (m_nodeId == PUBLISHER_NODE) {
         SendPacket(INITIAL_BROKER_NODE, DATA_RESPONSE, 1);
     }
     
     // 安排下一次发布事件, 添加微小延迟避免边界条件
     m_publishEvent = Simulator::Schedule(MilliSeconds(1000.0 / PUBLISH_RATE) + MicroSeconds(1), 
                                         &MANETWithoutMigrationApp::PeriodicPublish, 
                                         this);
 }
 
 void MANETWithoutMigrationApp::PeriodicStateBroadcast()
 {
     // 确保应用程序仍在运行
     if (!m_running) {
         return;
     }
     
     // 向所有节点广播状态信息
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i != m_nodeId) {
             SendPacket(i, STATE_BROADCAST, 0);
         }
     }
     
     // 安排下一次状态广播, 添加微小延迟避免边界条件
     m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL) + MicroSeconds(2), 
                                                &MANETWithoutMigrationApp::PeriodicStateBroadcast, 
                                                this);
 }
 
 void MANETWithoutMigrationApp::PeriodicConnectivityCheck()
 {
     // 确保应用程序仍在运行
     if (!m_running) {
         return;
     }
     
     // 基于当前连接性更新邻居
     UpdateNeighbors();
     
     // 记录关键节点的连接状态
     if (m_nodeId == SUBSCRIBER_NODE || m_nodeId == INITIAL_BROKER_NODE) {
         bool brokerCanReachSubscriber = m_connectivityManager->IsReachable(INITIAL_BROKER_NODE, SUBSCRIBER_NODE);
         bool subscriberCanReachBroker = m_connectivityManager->IsReachable(SUBSCRIBER_NODE, INITIAL_BROKER_NODE);
         
         NS_LOG_INFO("连接状态 " << Simulator::Now().GetSeconds() 
                    << "秒: 节点 " << m_nodeId 
                    << ", Broker->Sub: " << (brokerCanReachSubscriber ? "是" : "否")
                    << ", Sub->Broker: " << (subscriberCanReachBroker ? "是" : "否"));
         
         // 如果是订阅者，记录位置和邻居
         if (m_nodeId == SUBSCRIBER_NODE) {
             Ptr<MobilityModel> mobility = GetNode()->GetObject<MobilityModel>();
             if (mobility) {
                 Vector position = mobility->GetPosition();
                 
                 NS_LOG_INFO("订阅者在 " << Simulator::Now().GetSeconds() 
                           << "秒: 位置=(" << position.x << "," << position.y << ")," 
                           << " 邻居数量=" << m_currentNeighbors.size());
             }
         }
     }
     
     // 安排下一次连接性检查, 添加微小延迟避免边界条件
     m_connectivityCheckEvent = Simulator::Schedule(Seconds(CONNECTIVITY_UPDATE_INTERVAL) + MicroSeconds(3), 
                                                  &MANETWithoutMigrationApp::PeriodicConnectivityCheck, 
                                                  this);
 }
 
 // 辅助函数获取节点
 Ptr<Node> GetNode(uint32_t id)
 {
     NS_ASSERT(id < NodeList::GetNNodes());
     return NodeList::GetNode(id);
 }
 
 // 主函数
 int main(int argc, char *argv[])
 {
     // 启用日志
     LogComponentEnable("MANETWithoutMigration", LOG_LEVEL_INFO);
     
     // 创建命令行参数
     CommandLine cmd;
     
     // 添加可调整参数
     double simTime = SIMULATION_TIME;
     double subscriberSpeed = MOBILITY_SPEED;
     
     cmd.AddValue("simTime", "仿真总时间(秒)", simTime);
     cmd.AddValue("speed", "订阅者移动速度(m/s)", subscriberSpeed);
     
     cmd.Parse(argc, argv);
     
     // 更新全局速度变量
     MOBILITY_SPEED = subscriberSpeed;
     
     NS_LOG_INFO("启动无副本迁移的MANET对比实验");
     NS_LOG_INFO("参数: 速度=" << subscriberSpeed << "m/s, 仿真时间=" << simTime << "秒");
     
     // 设置随机种子以确保可重复性
     RngSeedManager::SetSeed(12345);
     
     // 创建节点
     NodeContainer nodes;
     nodes.Create(TOTAL_NODES);
     
     // 配置WiFi
     WifiHelper wifi;
     wifi.SetStandard(WIFI_STANDARD_80211g);
     
     // 配置物理层
     YansWifiPhyHelper wifiPhy;
     YansWifiChannelHelper wifiChannel;
     
     // 使用简单的衰减模型
     wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
     wifiChannel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                   "MaxRange", DoubleValue(COMMUNICATION_RANGE));
     
     wifiPhy.SetChannel(wifiChannel.Create());
     
     // 设置基本WiFi参数
     wifiPhy.Set("TxPowerStart", DoubleValue(16.0));
     wifiPhy.Set("TxPowerEnd", DoubleValue(16.0));
     wifiPhy.Set("TxPowerLevels", UintegerValue(1));
     wifiPhy.Set("TxGain", DoubleValue(1.0));
     wifiPhy.Set("RxGain", DoubleValue(1.0));
     
     WifiMacHelper wifiMac;
     wifiMac.SetType("ns3::AdhocWifiMac");
     
     NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, nodes);
     
     // 设置带AODV路由的互联网协议栈
     InternetStackHelper internet;
     AodvHelper aodv;
     internet.SetRoutingHelper(aodv);
     internet.Install(nodes);
     
     // 分配IP地址
     Ipv4AddressHelper ipv4;
     ipv4.SetBase("10.1.1.0", "255.255.255.0");
     Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);
     
     // 设置移动模型
     MobilityHelper mobility;
     
     // 首先为subscriber节点单独创建并安装WaypointMobilityModel
     MobilityHelper subscriberMobilityHelper;
     subscriberMobilityHelper.SetMobilityModel("ns3::WaypointMobilityModel");
     
     // 为subscriber创建初始位置分配器
     Ptr<ListPositionAllocator> subscriberPositionAlloc = CreateObject<ListPositionAllocator>();
     Vector subscriberPos(550.0, 500.0, 0.0);
     subscriberPositionAlloc->Add(subscriberPos);
     subscriberMobilityHelper.SetPositionAllocator(subscriberPositionAlloc);
     
     // 只给subscriber安装waypoint模型
     subscriberMobilityHelper.Install(nodes.Get(SUBSCRIBER_NODE));
     
     // 为除subscriber外的其他节点安装ConstantPositionMobilityModel
     Ptr<RandomRectanglePositionAllocator> positionAlloc = CreateObject<RandomRectanglePositionAllocator>();
     positionAlloc->SetAttribute("X", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));
     positionAlloc->SetAttribute("Y", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));
     
     mobility.SetPositionAllocator(positionAlloc);
     mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
     
     // 创建一个排除subscriber的节点容器
     NodeContainer otherNodes;
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i != SUBSCRIBER_NODE) {
             otherNodes.Add(nodes.Get(i));
         }
     }
     
     // 只给非subscriber节点安装mobility model
     mobility.Install(otherNodes);
     
     // 获取安装的WaypointMobilityModel对象
     Ptr<WaypointMobilityModel> waypointMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<WaypointMobilityModel>();
     if (!waypointMobility) {
         NS_FATAL_ERROR("无法获取subscriber的WaypointMobilityModel");
     }
     
     // 定义路径点的位置 - 与原代码相同的路径
     std::vector<Vector> waypoints = {
         Vector(700.0, 500.0, 0.0),  // waypoint 1
         Vector(950.0, 500.0, 0.0),  // waypoint 2
         Vector(950.0, 950.0, 0.0),  // waypoint 3
         Vector(950.0, 950.0, 0.0),  // waypoint 4 (静止点)
         Vector(900.0, 900.0, 0.0),  // waypoint 5
         Vector(600.0, 600.0, 0.0),  // waypoint 6
         Vector(550.0, 500.0, 0.0),  // waypoint 7
     };
     
     // 计算到每个路径点的时间点，基于速度
     // 确保添加微小偏移，避免路径点的精确时间导致定时问题
     double currentTime = 0.01; // 从0.01秒开始，而不是精确的0，避免边界条件
     Vector currentPos = subscriberPos;
     
     for (const auto& waypoint : waypoints) {
         // 计算距离
         double distance = CalculateVectorDistance(currentPos, waypoint);
         // 计算到达时间 (时间 = 距离/速度)
         double arrivalTime;
         
         // 如果是waypoint 4（静止点），使用固定的停留时间
         if (currentPos == Vector(950.0, 950.0, 0.0) && waypoint == Vector(950.0, 950.0, 0.0)) {
             arrivalTime = currentTime + 60.0 + 0.01;  // 停留60秒，添加小偏移
         } else {
             // 正常移动计算时间，添加小偏移避免精确时间点
             arrivalTime = currentTime + (distance / subscriberSpeed) + 0.005;
         }
         
         // 添加路径点
         waypointMobility->AddWaypoint(Waypoint(Seconds(arrivalTime), waypoint));
         
         NS_LOG_INFO("添加路径点: 时间=" << arrivalTime << "秒, 位置=(" 
                     << waypoint.x << "," << waypoint.y << "), 距离=" 
                     << distance << "m, 速度=" << subscriberSpeed << "m/s");
         
         // 更新当前位置和时间
         currentPos = waypoint;
         currentTime = arrivalTime;
     }
     
     // Publisher和Broker的特殊位置
     Ptr<MobilityModel> publisherMobility = nodes.Get(PUBLISHER_NODE)->GetObject<MobilityModel>();
     Ptr<MobilityModel> brokerMobility = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
     Ptr<MobilityModel> subscriberMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
     
     if (!publisherMobility || !brokerMobility || !subscriberMobility) {
         NS_FATAL_ERROR("无法获取移动模型");
     }
     
     // 将Broker放在位置(500, 500)
     Vector brokerPos(500.0, 500.0, 0.0);
     brokerMobility->SetPosition(brokerPos);
     
     // 设置Publisher的位置 - 确保其可以与Broker通信但不能直接与Subscriber通信
     // 放在远离Subscriber的位置
     Vector publisherPos(200.0, 200.0, 0.0); // 与Broker直线距离约为424m，超过了与Subscriber的通信范围
     publisherMobility->SetPosition(publisherPos);
     
     NS_LOG_INFO("Broker初始位置: (" << brokerPos.x << ", " << brokerPos.y << ")");
     NS_LOG_INFO("Publisher初始位置: (" << publisherPos.x << ", " << publisherPos.y << ")");
     NS_LOG_INFO("Subscriber初始位置: (" << subscriberMobility->GetPosition().x 
                << ", " << subscriberMobility->GetPosition().y << ")");
     
     // 创建跟踪器对象
     Ptr<NeighborTracker> neighborTracker = CreateObject<NeighborTracker>();
     Ptr<RequestTracker> requestTracker = CreateObject<RequestTracker>();
     Ptr<LoadTracker> loadTracker = CreateObject<LoadTracker>();
     Ptr<ConnectivityManager> connectivityManager = CreateObject<ConnectivityManager>();
     
     // 设置连接性管理器的设备
     connectivityManager->SetDevices(devices);
     
     // 存储移动模型用于连接性更新
     Ptr<MobilityModel> mobilityModels[TOTAL_NODES];
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         mobilityModels[i] = nodes.Get(i)->GetObject<MobilityModel>();
         if (!mobilityModels[i]) {
             NS_FATAL_ERROR("无法获取节点 " << i << " 的移动模型");
         }
     }
     
     // 定期更新连接性的函数
     auto updateConnectivity = [&]() {
         connectivityManager->UpdateReachability(mobilityModels);
     };
     
     // 安排频繁的连接性更新，使用递增偏移避免边界条件
     for (double t = 0.05; t <= simTime; t += CONNECTIVITY_UPDATE_INTERVAL) {
         // 添加微小偏移，避免精确时间点
         Simulator::Schedule(Seconds(t) + MicroSeconds((uint64_t)(t * 10) % 100), updateConnectivity);
     }
     
     // 安装应用程序到所有节点
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         Ptr<MANETWithoutMigrationApp> app = CreateObject<MANETWithoutMigrationApp>();
         if (!app) {
             NS_LOG_ERROR("无法为节点 " << i << " 创建MANETWithoutMigrationApp");
             continue;
         }
         
         app->Setup(i, neighborTracker, requestTracker, loadTracker, connectivityManager);
         
         nodes.Get(i)->AddApplication(app);
         // 使用微小偏移启动应用程序，避免所有应用程序同时启动
         app->SetStartTime(MilliSeconds(i % 10));
         app->SetStopTime(Seconds(simTime) - MilliSeconds(1));
     }
     
     // 设置动画
     AnimationInterface anim("manet_without_migration.xml");
     
     // 配置节点外观
     for (uint32_t i = 0; i < TOTAL_NODES; i++) {
         if (i == PUBLISHER_NODE) {
             anim.UpdateNodeDescription(i, "Publisher");
             anim.UpdateNodeColor(i, 255, 0, 0); // 红色
             anim.UpdateNodeSize(i, 10, 10);
         } else if (i == INITIAL_BROKER_NODE) {
             anim.UpdateNodeDescription(i, "Broker");
             anim.UpdateNodeColor(i, 0, 255, 0); // 绿色
             anim.UpdateNodeSize(i, 10, 10);
         } else if (i == SUBSCRIBER_NODE) {
             anim.UpdateNodeDescription(i, "Subscriber");
             anim.UpdateNodeColor(i, 0, 0, 255); // 蓝色
             anim.UpdateNodeSize(i, 10, 10);
         } else {
             std::ostringstream desc;
             desc << "Relay Node " << i;
             anim.UpdateNodeDescription(i, desc.str());
             anim.UpdateNodeColor(i, 128, 128, 128); // 灰色
         }
     }
     
     // 启用数据包元数据以便动画
     anim.EnablePacketMetadata(true);
     
     // 设置流量监视器
     FlowMonitorHelper flowmon;
     Ptr<FlowMonitor> monitor = flowmon.InstallAll();
     
     // 定期记录订阅者位置和与Broker的连接状态（使用微小偏移）
     for (double t = 5.02; t <= simTime; t += 5.0) {
         // 添加微小偏移，避免精确时间点
         Simulator::Schedule(Seconds(t) + MicroSeconds((uint64_t)(t * 10) % 100), [&]() {
             Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
             Ptr<MobilityModel> brokerMob = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
             
             if (subscriberMob && brokerMob) {
                 Vector subPos = subscriberMob->GetPosition();
                 Vector brkPos = brokerMob->GetPosition();
                 double distance = subscriberMob->GetDistanceFrom(brokerMob);
                 
                 // 检查连接性
                 bool subCanReachBroker = connectivityManager->IsReachable(SUBSCRIBER_NODE, INITIAL_BROKER_NODE);
                 bool brokerCanReachSub = connectivityManager->IsReachable(INITIAL_BROKER_NODE, SUBSCRIBER_NODE);
                 
                 NS_LOG_INFO(Simulator::Now().GetSeconds() << "秒: "
                             << "订阅者(" << subPos.x << "," << subPos.y << ") "
                             << "代理(" << brkPos.x << "," << brkPos.y << ") "
                             << "距离=" << distance << "m "
                             << "通信范围=" << COMMUNICATION_RANGE << "m "
                             << "S→B=" << (subCanReachBroker ? "是" : "否") << " "
                             << "B→S=" << (brokerCanReachSub ? "是" : "否"));
             }
         });
     }
     
     // 运行仿真
     NS_LOG_INFO("运行仿真 " << simTime << " 秒，订阅者速度 = " << subscriberSpeed << " m/s");
     Simulator::Stop(Seconds(simTime) - NanoSeconds(1)); // 减去1纳秒，避免精确边界
     Simulator::Run();
     
     // 打印结果
     NS_LOG_INFO("仿真完成。");
     
     // 从订阅者节点获取应用程序以访问统计数据
     Ptr<MANETWithoutMigrationApp> subscriberApp = nullptr;
     if (nodes.Get(SUBSCRIBER_NODE)) {
         subscriberApp = DynamicCast<MANETWithoutMigrationApp>(nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
     }
     
     // 生成用于后处理的跟踪文件
     std::string outFileName = "manet_no_migration_results_speed_" + std::to_string(subscriberSpeed) + ".txt";
     std::ofstream outFile(outFileName);
     if (outFile.is_open() && subscriberApp) {
         outFile << "# 无副本迁移的MANET实验结果" << std::endl;
         outFile << "# 仿真参数:" << std::endl;
         outFile << "# - 总节点数: " << TOTAL_NODES << std::endl;
         outFile << "# - 仿真时间: " << simTime << " 秒" << std::endl;
         outFile << "# - 仿真区域: " << SIMULATION_AREA << " x " << SIMULATION_AREA << " 米" << std::endl;
         outFile << "# - 订阅者移动速度: " << subscriberSpeed << " m/s" << std::endl;
         outFile << "# - 通信范围: " << COMMUNICATION_RANGE << " 米" << std::endl;
         outFile << std::endl;
         
         // 添加详细结果
         outFile << "平均延迟 (ms): " << subscriberApp->GetAverageDelay() * 1000.0 << std::endl;
         outFile << "消息交付率 (%): " << subscriberApp->GetDeliveryRate() * 100.0 << std::endl;
         outFile << "平均吞吐量 (msgs/s): " << subscriberApp->GetAverageThroughput() << std::endl;
         outFile << "发送消息数: " << subscriberApp->GetMessagesSent() << std::endl;
         outFile << "接收消息数: " << subscriberApp->GetMessagesReceived() << std::endl;
         
         outFile.close();
     }
     
     Simulator::Destroy();
     
     return 0;
 }