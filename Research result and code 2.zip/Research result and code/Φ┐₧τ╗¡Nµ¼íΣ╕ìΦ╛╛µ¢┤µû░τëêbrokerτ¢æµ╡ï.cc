/* 
 * MANET Dynamic Replica Migration Experiment - Enhanced Version
 * NS-3.44 Implementation
 *
 * This simulation implements a mobile ad-hoc network (MANET) with:
 * - 50 nodes total (1 Publisher, 1 Broker, 1 Subscriber, 47 relay nodes)
 * - Predefined waypoint mobility model for the Subscriber node
 * - Dynamic replica migration based on a combined score calculation
 * - Measurements of transmission delay and message delivery rates
 * - Enhanced features:
 *   1. Proactive migration prediction based on signal strength
 *   2. Prioritized message delivery for critical messages
 *   3. Multi-path message forwarding for reliability 
 *   4. Selective acknowledgment for reduced overhead
 *   5. Enhanced broker selection algorithm
 */

 #include "ns3/core-module.h"
 #include "ns3/network-module.h"
 #include "ns3/mobility-module.h"
 #include "ns3/internet-module.h"
 #include "ns3/applications-module.h"
 #include "ns3/wifi-module.h"
 #include "ns3/aodv-module.h"
 #include "ns3/netanim-module.h"
 #include "ns3/flow-monitor-module.h"
 #include <fstream>
 #include <vector>
 #include <map>
 #include <string>
 #include <algorithm>
 #include <cmath>
 #include <random>
 #include <queue>
 #include <limits>
 #include <set>
 
 using namespace ns3;
 
 NS_LOG_COMPONENT_DEFINE("MANETDynamicReplicaMigration");
 
 // Constants for the experiment
 const uint32_t TOTAL_NODES = 50;        // Total number of nodes in the network
 const uint32_t PUBLISHER_NODE = 0;      // Node ID for the publisher
 const uint32_t INITIAL_BROKER_NODE = 1; // Node ID for the initial broker
 const uint32_t SUBSCRIBER_NODE = 2;     // Node ID for the subscriber
 const double SIMULATION_TIME = 300.0;   // Total simulation time in seconds
 double MOBILITY_SPEED = 4.0;            // Default subscriber mobility speed in m/s (will be updated from command line)
 const double COMMUNICATION_RANGE = 250.0; // Direct communication range in meters
 const double SIMULATION_AREA = 1000.0;   // 1000m x 1000m simulation area
 const uint32_t PUBLISH_RATE = 50;        // 50 messages/second
 const double REQUEST_INTERVAL = 2.0;     // Subscriber requests every 2 seconds
 const double STATE_BROADCAST_INTERVAL = 5.0; // Broadcast state info every 5 seconds
 const double CONNECTIVITY_UPDATE_INTERVAL = 0.5; // Update connectivity every 0.5 second (more frequent updates)
 
 // Parameters for the scoring formula: Score = αS + βI - γL + δP - εD
 const double ALPHA = 0.3;  // Weight for stability
 const double BETA = 0.2;   // Weight for request intensity
 const double GAMMA = 0.1;  // Weight for load
 const double DELTA = 0.2;  // Weight for proximity to subscriber (NEW)
 const double EPSILON = 0.2; // Weight for delay factor (NEW)
 
 // Enhanced settings - 降低阈值使迁移更容易触发
 const double PROACTIVE_MIGRATION_THRESHOLD = 0.6;  // 信号强度阈值（调低，原为0.7）
 const double RSSI_WARNING_THRESHOLD = 0.7;         // RSSI警告阈值（调低，原为0.8）
 const uint32_t MAX_MULTIPATH_ROUTES = 2;           // Maximum number of multipath routes
 const uint32_t MAX_RELAY_BUFFER_SIZE = 100;        // Maximum number of messages to buffer
 
 // Debug flags for specific components
 const bool DEBUG_MOBILITY = true;        // Debug subscriber mobility
 const bool DEBUG_CONNECTIVITY = true;    // Debug connectivity updates
 const bool DEBUG_MIGRATION = true;       // Debug migration decisions
 const bool DEBUG_SCORING = true;         // Debug node scoring calculations
 const bool DEBUG_MULTIPATH = true;       // Debug multipath routing
 const bool DEBUG_PROACTIVE = true;       // Debug proactive migration
 const bool DEBUG_MESSAGE_STATS = true;   // 添加统计信息调试
 
 // Global migration tracking variables
 bool g_migrationOccurred = false;
 Time g_firstMigrationTime = Seconds(-1);
 
 // New global backup broker tracking
 uint32_t g_backupBroker = UINT32_MAX;
 
 // New global message tracking
 uint32_t g_totalMessagesSent = 0;
 uint32_t g_totalMessagesReceived = 0;
 
 // Helper function - Calculate distance between two points
 double CalculateVectorDistance(const Vector& p1, const Vector& p2) {
     double dx = p1.x - p2.x;
     double dy = p1.y - p2.y;
     return std::sqrt(dx*dx + dy*dy);
 }
 
 // Enhanced packet types for custom application
 enum PacketType {
     SUBSCRIBE_REQUEST = 1,
     DATA_RESPONSE = 2,
     STATE_BROADCAST = 3,
     REPLICA_MIGRATION_REQUEST = 4,
     REPLICA_MIGRATION_DATA = 5,
     DATA_RESPONSE_ACK = 6,        // Response acknowledgment
     MULTIPATH_DATA = 7,           // NEW: Data sent via multiple paths
     PROACTIVE_MIGRATION_NOTIFY = 8,// NEW: Notification of proactive migration
     SELECTIVE_ACK = 9,            // NEW: Selective acknowledgment
     MIGRATION_PREPARE = 10,       // NEW: Prepare for migration (warm-up)
     BACKUP_BROKER_ASSIGN = 11     // NEW: Assign backup broker
 };

 // New packet priority levels
 enum PacketPriority {
     LOW_PRIORITY = 0,
     NORMAL_PRIORITY = 1,
     HIGH_PRIORITY = 2,
     CRITICAL_PRIORITY = 3
 };
 
 // Structure to hold node state information - Enhanced
 struct NodeState {
     uint32_t nodeId;
     double stability;          // S: 1 - (neighbor changes / upper limit)
     double requestIntensity;   // I: requests from this node / highest request count
     double load;               // L: used cache / total cache
     bool reachableToSubscriber; // Whether this node can reach the subscriber
     double signalStrength;     // NEW: Signal strength between this node and subscriber
     double avgDelay;           // NEW: Average delay to subscriber
     double proximity;          // NEW: Proximity to subscriber (inverse of distance)
     Time lastUpdateTime;       // When this state was last updated
     
     NodeState() : nodeId(0), stability(0.0), requestIntensity(0.0), 
                   load(0.0), reachableToSubscriber(false),
                   signalStrength(0.0), avgDelay(0.0), proximity(0.0) {}
 };

 // Structure to track message delivery statistics
 struct MessageStats {
     uint32_t sent;
     uint32_t received;
     uint32_t buffered;
     uint32_t multipath;
     double avgDelay;
     std::vector<Time> delays;
     
     MessageStats() : sent(0), received(0), buffered(0), multipath(0), avgDelay(0.0) {}
     
     double GetDeliveryRate() const {
         return sent > 0 ? (double)received / sent : 0.0;
     }
     
     void RecordDelay(Time delay) {
         delays.push_back(delay);
         double totalSeconds = 0.0;
         for(const auto& d : delays) {
             totalSeconds += d.GetSeconds();
         }
         avgDelay = delays.empty() ? 0.0 : totalSeconds / delays.size();
     }
 };

 // Structure to track RSSI samples 
 struct RssiTracker {
     std::deque<double> samples;
     uint32_t maxSamples;
     
     RssiTracker(uint32_t maxSize = 10) : maxSamples(maxSize) {}
     
     void AddSample(double rssi) {
         samples.push_back(rssi);
         if (samples.size() > maxSamples) {
             samples.pop_front();
         }
     }
     
     double GetAverage() const {
         if (samples.empty()) return 0.0;
         double sum = 0.0;
         for (double sample : samples) {
             sum += sample;
         }
         return sum / samples.size();
     }
     
     double GetTrend() const {
         if (samples.size() < 2) return 0.0;
         
         double firstHalfAvg = 0.0;
         double secondHalfAvg = 0.0;
         size_t half = samples.size() / 2;
         
         for (size_t i = 0; i < half; i++) {
             firstHalfAvg += samples[i];
         }
         firstHalfAvg /= half;
         
         for (size_t i = half; i < samples.size(); i++) {
             secondHalfAvg += samples[i];
         }
         secondHalfAvg /= (samples.size() - half);
         
         return secondHalfAvg - firstHalfAvg;
     }
 };
 
 // Class to track node neighbor changes
 class NeighborTracker : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_neighbors;      // Current neighbors for each node
     std::map<uint32_t, uint32_t> m_neighborChangeCount;      // Count of neighbor changes
     const uint32_t m_maxNeighborChanges;                     // Upper limit for neighbor changes
     std::map<std::pair<uint32_t, uint32_t>, RssiTracker> m_rssiTrackers; // Track RSSI between nodes
     
 public:
     NeighborTracker() : m_maxNeighborChanges(20) {
         // Initialize neighbor change count for all nodes
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_neighborChangeCount[i] = 0;
         }
     }
     
     void UpdateNeighbors(uint32_t nodeId, const std::set<uint32_t>& currentNeighbors) {
         // If this is the first update, simply store the neighbors
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             m_neighbors[nodeId] = currentNeighbors;
             
             if (DEBUG_CONNECTIVITY && (nodeId == SUBSCRIBER_NODE || nodeId == INITIAL_BROKER_NODE)) {
                 NS_LOG_INFO("Node " << nodeId << " initial neighbors: " << currentNeighbors.size());
                 for (auto neighbor : currentNeighbors) {
                     NS_LOG_INFO("  - Neighbor: " << neighbor);
                 }
             }
             return;
         }
         
         // Count how many neighbors have changed
         std::set<uint32_t> oldNeighbors = m_neighbors[nodeId];
         uint32_t changes = 0;
         
         // Find neighbors that were removed
         std::vector<uint32_t> removedNeighbors;
         for (auto& oldNeighbor : oldNeighbors) {
             if (currentNeighbors.find(oldNeighbor) == currentNeighbors.end()) {
                 changes++;
                 removedNeighbors.push_back(oldNeighbor);
             }
         }
         
         // Find neighbors that were added
         std::vector<uint32_t> addedNeighbors;
         for (auto& newNeighbor : currentNeighbors) {
             if (oldNeighbors.find(newNeighbor) == oldNeighbors.end()) {
                 changes++;
                 addedNeighbors.push_back(newNeighbor);
             }
         }
         
         // Update neighbor change count
         m_neighborChangeCount[nodeId] += changes;
         
         // Log changes for important nodes
         if (DEBUG_CONNECTIVITY && changes > 0 && 
             (nodeId == SUBSCRIBER_NODE || nodeId == INITIAL_BROKER_NODE || 
              m_neighbors[SUBSCRIBER_NODE].find(nodeId) != m_neighbors[SUBSCRIBER_NODE].end())) {
             
             NS_LOG_INFO("Node " << nodeId << " neighbors changed at " 
                       << Simulator::Now().GetSeconds() << "s: " 
                       << changes << " changes, " 
                       << addedNeighbors.size() << " added, " 
                       << removedNeighbors.size() << " removed");
             
             if (!addedNeighbors.empty()) {
                 std::ostringstream oss;
                 oss << "  Added: ";
                 for (auto n : addedNeighbors) {
                     oss << n << " ";
                 }
                 NS_LOG_INFO(oss.str());
             }
             
             if (!removedNeighbors.empty()) {
                 std::ostringstream oss;
                 oss << "  Removed: ";
                 for (auto n : removedNeighbors) {
                     oss << n << " ";
                 }
                 NS_LOG_INFO(oss.str());
             }
         }
         
         // Update stored neighbors
         m_neighbors[nodeId] = currentNeighbors;
     }
     
     // Record RSSI between two nodes (normalized value 0.0-1.0)
     void RecordRssi(uint32_t node1, uint32_t node2, double rssi) {
         // Ensure consistent ordering of node pairs
         uint32_t firstNode = std::min(node1, node2);
         uint32_t secondNode = std::max(node1, node2);
         std::pair<uint32_t, uint32_t> nodePair(firstNode, secondNode);
         
         // Create tracker if needed
         if (m_rssiTrackers.find(nodePair) == m_rssiTrackers.end()) {
             m_rssiTrackers[nodePair] = RssiTracker();
         }
         
         // Add sample
         m_rssiTrackers[nodePair].AddSample(rssi);
         
         // Debug RSSI changes for important nodes
         if (DEBUG_PROACTIVE && (node1 == SUBSCRIBER_NODE || node2 == SUBSCRIBER_NODE)) {
             uint32_t otherNode = (node1 == SUBSCRIBER_NODE) ? node2 : node1;
             double avgRssi = m_rssiTrackers[nodePair].GetAverage();
             double trend = m_rssiTrackers[nodePair].GetTrend();
             
             if (avgRssi < RSSI_WARNING_THRESHOLD) {
                 NS_LOG_INFO("RSSI Warning: Subscriber-Node " << otherNode 
                           << " RSSI=" << avgRssi << ", trend=" << trend
                           << " at " << Simulator::Now().GetSeconds() << "s");
             }
         }
     }
     
     // Get average RSSI between two nodes
     double GetRssi(uint32_t node1, uint32_t node2) const {
         uint32_t firstNode = std::min(node1, node2);
         uint32_t secondNode = std::max(node1, node2);
         std::pair<uint32_t, uint32_t> nodePair(firstNode, secondNode);
         
         if (m_rssiTrackers.find(nodePair) == m_rssiTrackers.end()) {
             return 0.0;
         }
         
         return m_rssiTrackers.at(nodePair).GetAverage();
     }
     
     // Get RSSI trend between two nodes (positive means improving)
     double GetRssiTrend(uint32_t node1, uint32_t node2) const {
         uint32_t firstNode = std::min(node1, node2);
         uint32_t secondNode = std::max(node1, node2);
         std::pair<uint32_t, uint32_t> nodePair(firstNode, secondNode);
         
         if (m_rssiTrackers.find(nodePair) == m_rssiTrackers.end()) {
             return 0.0;
         }
         
         return m_rssiTrackers.at(nodePair).GetTrend();
     }
     
     // Predict whether connection between two nodes will break soon
     bool PredictConnectionBreak(uint32_t node1, uint32_t node2) const {
         double rssi = GetRssi(node1, node2);
         double trend = GetRssiTrend(node1, node2);
         
         // If RSSI is already low and trend is negative, predict break
         // 修改：降低阈值，使迁移更容易触发
         if (rssi < PROACTIVE_MIGRATION_THRESHOLD || (rssi < RSSI_WARNING_THRESHOLD && trend < 0)) {
             return true;
         }
         
         return false;
     }
     
     double GetStability(uint32_t nodeId) const {
         // S = 1 - (Number of neighbor changes / A fixed upper limit)
         if (m_neighborChangeCount.find(nodeId) == m_neighborChangeCount.end()) {
             return 1.0; // No changes recorded yet
         }
         
         double stability = 1.0 - ((double)m_neighborChangeCount.at(nodeId) / m_maxNeighborChanges);
         return std::max(0.0, std::min(1.0, stability)); // Clamp between 0 and 1
     }
     
     const std::set<uint32_t>& GetNeighbors(uint32_t nodeId) const {
         static const std::set<uint32_t> emptySet;
         if (m_neighbors.find(nodeId) == m_neighbors.end()) {
             return emptySet;
         }
         return m_neighbors.at(nodeId);
     }
     
     bool AreNeighbors(uint32_t node1, uint32_t node2) const {
         if (m_neighbors.find(node1) == m_neighbors.end()) {
             return false;
         }
         return m_neighbors.at(node1).find(node2) != m_neighbors.at(node1).end();
     }
 };
 
 // Class to track request intensity
 class RequestTracker : public Object {
 private:
     std::map<uint32_t, uint32_t> m_requestCount;  // Request count for each node
     uint32_t m_maxRequests;                       // Highest request count in the network
     
 public:
     RequestTracker() : m_maxRequests(1) {} // Initialize with 1 to avoid division by zero
     
     void IncrementRequestCount(uint32_t nodeId) {
         m_requestCount[nodeId]++;
         // Update max requests if needed
         if (m_requestCount[nodeId] > m_maxRequests) {
             m_maxRequests = m_requestCount[nodeId];
         }
         
         if (DEBUG_SCORING) {
             NS_LOG_INFO("Node " << nodeId << " request count increased to " 
                        << m_requestCount[nodeId] << " (max requests: " << m_maxRequests << ")");
         }
     }
     
     double GetRequestIntensity(uint32_t nodeId) const {
         // I = (Number of requests from this node during this period) / (Highest number of requests in the network)
         if (m_requestCount.find(nodeId) == m_requestCount.end()) {
             return 0.0; // No requests from this node
         }
         
         return (double)m_requestCount.at(nodeId) / m_maxRequests;
     }
 };
 
 // Enhanced class to track node load
 class LoadTracker : public Object {
 private:
     std::map<uint32_t, double> m_nodeLoad;        // Load for each node (0.0 to 1.0)
     std::map<uint32_t, double> m_processingPower; // Relative processing power (1.0 is baseline)
     std::map<uint32_t, uint32_t> m_bufferSize;    // Buffer size for each node
     std::map<uint32_t, uint32_t> m_bufferUsed;    // Used buffer for each node
     
 public:
     LoadTracker() {
         // Initialize with random loads between 0.1 and 0.4 (lower baseline)
         std::random_device rd;
         std::mt19937 gen(rd());
         std::uniform_real_distribution<> loadDis(0.1, 0.4);
         std::uniform_real_distribution<> powerDis(0.8, 1.2);
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_nodeLoad[i] = loadDis(gen);
             m_processingPower[i] = powerDis(gen);
             m_bufferSize[i] = MAX_RELAY_BUFFER_SIZE;
             m_bufferUsed[i] = 0;
             
             if (DEBUG_SCORING) {
                 NS_LOG_INFO("Node " << i << " initial load: " << m_nodeLoad[i] 
                           << ", processing power: " << m_processingPower[i]);
             }
         }
     }
     
     void UpdateLoad(uint32_t nodeId, double load) {
         double oldLoad = m_nodeLoad[nodeId];
         m_nodeLoad[nodeId] = std::max(0.0, std::min(1.0, load)); // Clamp between 0 and 1
         
         if (DEBUG_SCORING && std::abs(oldLoad - m_nodeLoad[nodeId]) > 0.01) {
             NS_LOG_INFO("Node " << nodeId << " load updated from " 
                        << oldLoad << " to " << m_nodeLoad[nodeId]);
         }
     }
     
     double GetLoad(uint32_t nodeId) const {
         if (m_nodeLoad.find(nodeId) == m_nodeLoad.end()) {
             return 0.0; // Default to 0 load
         }
         
         return m_nodeLoad.at(nodeId);
     }
     
     double GetProcessingPower(uint32_t nodeId) const {
         if (m_processingPower.find(nodeId) == m_processingPower.end()) {
             return 1.0; // Default to baseline processing power
         }
         
         return m_processingPower.at(nodeId);
     }
     
     // Get effective load (accounting for processing power)
     double GetEffectiveLoad(uint32_t nodeId) const {
         double load = GetLoad(nodeId);
         double power = GetProcessingPower(nodeId);
         
         return power > 0 ? load / power : 1.0;
     }
     
     // Buffer management
     bool BufferMessage(uint32_t nodeId) {
         if (m_bufferUsed[nodeId] < m_bufferSize[nodeId]) {
             m_bufferUsed[nodeId]++;
             
             // Increase load slightly when buffering
             double currentLoad = m_nodeLoad[nodeId];
             UpdateLoad(nodeId, currentLoad + 0.01);
             
             return true;
         }
         return false;
     }
     
     void ReleaseBuffer(uint32_t nodeId) {
         if (m_bufferUsed[nodeId] > 0) {
             m_bufferUsed[nodeId]--;
             
             // Decrease load slightly when releasing
             double currentLoad = m_nodeLoad[nodeId];
             UpdateLoad(nodeId, currentLoad - 0.01);
         }
     }
     
     uint32_t GetBufferUsed(uint32_t nodeId) const {
         if (m_bufferUsed.find(nodeId) == m_bufferUsed.end()) {
             return 0;
         }
         return m_bufferUsed.at(nodeId);
     }
     
     uint32_t GetBufferSize(uint32_t nodeId) const {
         if (m_bufferSize.find(nodeId) == m_bufferSize.end()) {
             return MAX_RELAY_BUFFER_SIZE;
         }
         return m_bufferSize.at(nodeId);
     }
     
     double GetBufferUtilization(uint32_t nodeId) const {
         uint32_t size = GetBufferSize(nodeId);
         return size > 0 ? (double)GetBufferUsed(nodeId) / size : 0.0;
     }
 };
 
 // Enhanced class to manage connectivity and reachability between nodes
 class ConnectivityManager : public Object {
 private:
     std::map<uint32_t, std::set<uint32_t>> m_reachableNodes;  // Reachable nodes for each node
     std::map<uint32_t, std::map<uint32_t, double>> m_distances; // Distance between nodes
     std::map<uint32_t, std::map<uint32_t, double>> m_signalStrength; // Signal strength between nodes
     std::map<uint32_t, std::map<uint32_t, std::vector<uint32_t>>> m_paths; // Cached paths
     std::map<uint32_t, std::map<uint32_t, std::vector<std::vector<uint32_t>>>> m_multipaths; // Multiple paths
     Ptr<NetDevice> m_devices[TOTAL_NODES];                     // NetDevices for all nodes
     
 public:
     ConnectivityManager() {}
     
     void SetDevices(NetDeviceContainer devices) {
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             m_devices[i] = devices.Get(i);
         }
     }
     
     // Calculate signal strength based on distance (relative to COMMUNICATION_RANGE)
     double CalculateSignalStrength(double distance) const {
         if (distance >= COMMUNICATION_RANGE) return 0.0;
         
         // Use a non-linear signal strength model to calculate RSSI
         // As distance approaches COMMUNICATION_RANGE, signal strength drops more rapidly
         double normalizedDistance = distance / COMMUNICATION_RANGE;
         return std::max(0.0, 1.0 - std::pow(normalizedDistance, 1.5));
     }
     
     void UpdateReachability(Ptr<MobilityModel> mobilityModels[TOTAL_NODES]) {
         // Clear previous reachability data
         m_reachableNodes.clear();
         m_distances.clear();
         m_signalStrength.clear();
         m_paths.clear();
         m_multipaths.clear();
         
         // First, determine direct reachability based on distance
         std::map<uint32_t, std::set<uint32_t>> directReachable;
         
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             for (uint32_t j = 0; j < TOTAL_NODES; j++) {
                 if (i == j) continue;
                 
                 // Calculate distance between nodes
                 double distance = mobilityModels[i]->GetDistanceFrom(mobilityModels[j]);
                 m_distances[i][j] = distance;
                 
                 // Calculate signal strength
                 double signal = CalculateSignalStrength(distance);
                 m_signalStrength[i][j] = signal;
                 
                 // If within communication range, they can directly reach each other
                 if (distance <= COMMUNICATION_RANGE) {
                     directReachable[i].insert(j);
                 }
             }
         }
         
         // Now use BFS to determine full reachability for each node
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             std::queue<uint32_t> nodesToVisit;
             std::set<uint32_t> visited;
             std::map<uint32_t, uint32_t> predecessor;
             
             // Start with the current node
             nodesToVisit.push(i);
             visited.insert(i);
             
             // BFS to find all reachable nodes
             while (!nodesToVisit.empty()) {
                 uint32_t currentNode = nodesToVisit.front();
                 nodesToVisit.pop();
                 
                 // Add to reachable nodes
                 if (currentNode != i) {
                     m_reachableNodes[i].insert(currentNode);
                 }
                 
                 // Explore direct neighbors of current node
                 for (uint32_t neighbor : directReachable[currentNode]) {
                     if (visited.find(neighbor) == visited.end()) {
                         visited.insert(neighbor);
                         nodesToVisit.push(neighbor);
                         predecessor[neighbor] = currentNode;
                     }
                 }
             }
             
             // Build paths for reachable nodes
             for (uint32_t dest : m_reachableNodes[i]) {
                 std::vector<uint32_t> path;
                 uint32_t current = dest;
                 
                 // Reconstruct path from destination to source
                 while (current != i) {
                     path.push_back(current);
                     if (predecessor.find(current) == predecessor.end()) break;
                     current = predecessor[current];
                 }
                 
                 // Add source and reverse path
                 path.push_back(i);
                 std::reverse(path.begin(), path.end());
                 
                 // Store path
                 m_paths[i][dest] = path;
             }
         }
         
         // Find multipath routes (disjoint paths where possible)
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             for (uint32_t j = 0; j < TOTAL_NODES; j++) {
                 if (i == j) continue;
                 
                 // Skip if no primary path exists
                 if (m_paths[i].find(j) == m_paths[i].end()) continue;
                 
                 std::vector<std::vector<uint32_t>> paths;
                 
                 // Add primary path
                 paths.push_back(m_paths[i][j]);
                 
                 // Try to find alternate paths by temporarily removing edges in primary path
                 if (paths[0].size() > 2) { // Only if primary path has intermediate nodes
                     std::map<uint32_t, std::set<uint32_t>> modifiedGraph = directReachable;
                     
                     // Remove intermediate links from the primary path
                     for (size_t k = 0; k < paths[0].size() - 1; k++) {
                         uint32_t node1 = paths[0][k];
                         uint32_t node2 = paths[0][k+1];
                         
                         // Remove link in both directions
                         modifiedGraph[node1].erase(node2);
                         modifiedGraph[node2].erase(node1);
                     }
                     
                     // Find alternate path
                     std::vector<uint32_t> altPath;
                     bool foundAlt = FindPath(i, j, modifiedGraph, altPath);
                     
                     if (foundAlt && !altPath.empty()) {
                         paths.push_back(altPath);
                     }
                 }
                 
                 // Store multipaths if we found any
                 if (paths.size() > 1) {
                     m_multipaths[i][j] = paths;
                     
                     if (DEBUG_MULTIPATH && (i == SUBSCRIBER_NODE || j == SUBSCRIBER_NODE)) {
                         NS_LOG_INFO("Found " << paths.size() << " paths from Node " << i << " to Node " << j);
                         
                         for (size_t p = 0; p < paths.size(); p++) {
                             std::ostringstream pathStr;
                             pathStr << "Path " << p << ": ";
                             for (uint32_t node : paths[p]) {
                                 pathStr << node << " ";
                             }
                             NS_LOG_INFO(pathStr.str());
                         }
                     }
                 }
             }
         }
         
         // Log important reachability changes
         if (DEBUG_CONNECTIVITY) {
             // Check if the subscriber can reach the broker
             bool subCanReachBroker = IsReachable(SUBSCRIBER_NODE, INITIAL_BROKER_NODE);
             bool brokerCanReachSub = IsReachable(INITIAL_BROKER_NODE, SUBSCRIBER_NODE);
             
             NS_LOG_INFO("Reachability at " << Simulator::Now().GetSeconds() << "s: "
                        << "Subscriber can reach Broker: " << (subCanReachBroker ? "YES" : "NO")
                        << ", Broker can reach Subscriber: " << (brokerCanReachSub ? "YES" : "NO"));
             
             // Log subscriber's reachable nodes count
             NS_LOG_INFO("Subscriber can reach " << m_reachableNodes[SUBSCRIBER_NODE].size() 
                        << " nodes out of " << TOTAL_NODES);
         }
     }
     
     // Find a path between source and destination using BFS
     bool FindPath(uint32_t src, uint32_t dest, 
                  const std::map<uint32_t, std::set<uint32_t>>& graph, 
                  std::vector<uint32_t>& path) {
         if (src == dest) {
             path.push_back(src);
             return true;
         }
         
         std::queue<uint32_t> queue;
         std::map<uint32_t, uint32_t> predecessor;
         std::set<uint32_t> visited;
         
         queue.push(src);
         visited.insert(src);
         
         while (!queue.empty()) {
             uint32_t current = queue.front();
             queue.pop();
             
             // Found destination
             if (current == dest) {
                 // Reconstruct path
                 uint32_t node = dest;
                 while (node != src) {
                     path.push_back(node);
                     node = predecessor[node];
                 }
                 path.push_back(src);
                 std::reverse(path.begin(), path.end());
                 return true;
             }
             
             // Check all neighbors
             if (graph.find(current) != graph.end()) {
                 for (uint32_t neighbor : graph.at(current)) {
                     if (visited.find(neighbor) == visited.end()) {
                         visited.insert(neighbor);
                         predecessor[neighbor] = current;
                         queue.push(neighbor);
                     }
                 }
             }
         }
         
         return false;
     }
     
     bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
         if (m_reachableNodes.find(fromNode) == m_reachableNodes.end()) {
             return false;
         }
         
         return m_reachableNodes.at(fromNode).find(toNode) != m_reachableNodes.at(fromNode).end();
     }
     
     double GetDistance(uint32_t node1, uint32_t node2) const {
         if (m_distances.find(node1) == m_distances.end() ||
             m_distances.at(node1).find(node2) == m_distances.at(node1).end()) {
             return std::numeric_limits<double>::max();
         }
         return m_distances.at(node1).at(node2);
     }
     
     double GetSignalStrength(uint32_t node1, uint32_t node2) const {
         if (m_signalStrength.find(node1) == m_signalStrength.end() ||
             m_signalStrength.at(node1).find(node2) == m_signalStrength.at(node1).end()) {
             return 0.0;
         }
         return m_signalStrength.at(node1).at(node2);
     }
     
     // Get the path from source to destination
     std::vector<uint32_t> GetPath(uint32_t src, uint32_t dest) const {
         if (m_paths.find(src) == m_paths.end() ||
             m_paths.at(src).find(dest) == m_paths.at(src).end()) {
             return std::vector<uint32_t>();
         }
         return m_paths.at(src).at(dest);
     }
     
     // Get multiple paths from source to destination
     std::vector<std::vector<uint32_t>> GetMultiplePaths(uint32_t src, uint32_t dest) const {
         if (m_multipaths.find(src) == m_multipaths.end() ||
             m_multipaths.at(src).find(dest) == m_multipaths.at(src).end()) {
             std::vector<std::vector<uint32_t>> result;
             // Return primary path if it exists
             std::vector<uint32_t> primaryPath = GetPath(src, dest);
             if (!primaryPath.empty()) {
                 result.push_back(primaryPath);
             }
             return result;
         }
         return m_multipaths.at(src).at(dest);
     }
     
     std::set<uint32_t> GetNodesInSamePartition(uint32_t nodeId) const {
         if (m_reachableNodes.find(nodeId) == m_reachableNodes.end()) {
             return std::set<uint32_t>(); // Empty set
         }
         
         // Include the node itself
         std::set<uint32_t> result = m_reachableNodes.at(nodeId);
         result.insert(nodeId);
         
         return result;
     }
     
     // Get the next hop to reach destination from source
     uint32_t GetNextHop(uint32_t src, uint32_t dest) const {
         std::vector<uint32_t> path = GetPath(src, dest);
         if (path.size() < 2) return UINT32_MAX;
         
         return path[1]; // Next hop is the second node in the path
     }
     
     // Find potential relay nodes that can connect source and destination
     std::vector<uint32_t> FindRelayNodes(uint32_t src, uint32_t dest) const {
         std::vector<uint32_t> relays;
         
         // If directly reachable, no relay needed
         if (IsReachable(src, dest)) return relays;
         
         // Find nodes that can reach both source and destination
         for (uint32_t i = 0; i < TOTAL_NODES; i++) {
             if (i != src && i != dest && 
                 IsReachable(src, i) && IsReachable(i, dest)) {
                 relays.push_back(i);
             }
         }
         
         return relays;
     }
 };
 
 // Enhanced message header for application messages
 class MessageHeader : public Header 
 {
 public:
     MessageHeader();
     virtual ~MessageHeader();
     
     // Set message properties
     void SetType(uint8_t type);
     void SetSourceId(uint32_t sourceId);
     void SetDestId(uint32_t destId);
     void SetDataId(uint32_t dataId);
     void SetTimestamp(Time timestamp);
     void SetPriority(uint8_t priority);         // NEW: Set message priority
     void SetHopCount(uint8_t hopCount);         // NEW: Set hop count
     void SetPathId(uint8_t pathId);             // NEW: Set path ID for multipath
     void SetSequenceNum(uint32_t seqNum);       // NEW: Set sequence number
     
     // Get message properties
     uint8_t GetType() const;
     uint32_t GetSourceId() const;
     uint32_t GetDestId() const;
     uint32_t GetDataId() const;
     Time GetTimestamp() const;
     uint8_t GetPriority() const;                // NEW: Get message priority
     uint8_t GetHopCount() const;                // NEW: Get hop count
     uint8_t GetPathId() const;                  // NEW: Get path ID
     uint32_t GetSequenceNum() const;            // NEW: Get sequence number
     
     // Header serialization/deserialization
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint8_t m_type;        // Packet type
     uint32_t m_sourceId;   // Source node ID
     uint32_t m_destId;     // Destination node ID
     uint32_t m_dataId;     // Data/Content ID
     uint64_t m_timestamp;  // Timestamp (used to calculate delays)
     uint8_t m_priority;    // NEW: Message priority
     uint8_t m_hopCount;    // NEW: Hop count for multipath routing
     uint8_t m_pathId;      // NEW: Path identifier for multipath
     uint32_t m_sequenceNum;// NEW: Sequence number
 };
 
 MessageHeader::MessageHeader()
     : m_type(0), m_sourceId(0), m_destId(0), m_dataId(0), m_timestamp(0),
       m_priority(NORMAL_PRIORITY), m_hopCount(0), m_pathId(0), m_sequenceNum(0)
 {
 }
 
 MessageHeader::~MessageHeader()
 {
 }
 
 TypeId MessageHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::MessageHeader")
         .SetParent<Header>()
         .AddConstructor<MessageHeader>();
     return tid;
 }
 
 TypeId MessageHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void MessageHeader::SetType(uint8_t type)
 {
     m_type = type;
 }
 
 void MessageHeader::SetSourceId(uint32_t sourceId)
 {
     m_sourceId = sourceId;
 }
 
 void MessageHeader::SetDestId(uint32_t destId)
 {
     m_destId = destId;
 }
 
 void MessageHeader::SetDataId(uint32_t dataId)
 {
     m_dataId = dataId;
 }
 
 void MessageHeader::SetTimestamp(Time timestamp)
 {
     m_timestamp = timestamp.GetNanoSeconds();
 }
 
 void MessageHeader::SetPriority(uint8_t priority)
 {
     m_priority = priority;
 }
 
 void MessageHeader::SetHopCount(uint8_t hopCount)
 {
     m_hopCount = hopCount;
 }
 
 void MessageHeader::SetPathId(uint8_t pathId)
 {
     m_pathId = pathId;
 }
 
 void MessageHeader::SetSequenceNum(uint32_t seqNum)
 {
     m_sequenceNum = seqNum;
 }
 
 uint8_t MessageHeader::GetType() const
 {
     return m_type;
 }
 
 uint32_t MessageHeader::GetSourceId() const
 {
     return m_sourceId;
 }
 
 uint32_t MessageHeader::GetDestId() const
 {
     return m_destId;
 }
 
 uint32_t MessageHeader::GetDataId() const
 {
     return m_dataId;
 }
 
 Time MessageHeader::GetTimestamp() const
 {
     return Time(NanoSeconds(m_timestamp));
 }
 
 uint8_t MessageHeader::GetPriority() const
 {
     return m_priority;
 }
 
 uint8_t MessageHeader::GetHopCount() const
 {
     return m_hopCount;
 }
 
 uint8_t MessageHeader::GetPathId() const
 {
     return m_pathId;
 }
 
 uint32_t MessageHeader::GetSequenceNum() const
 {
     return m_sequenceNum;
 }
 
 uint32_t MessageHeader::GetSerializedSize() const
 {
     return 1 + 4 + 4 + 4 + 8 + 1 + 1 + 1 + 4; // type + sourceId + destId + dataId + timestamp + priority + hopCount + pathId + sequenceNum
 }
 
 void MessageHeader::Serialize(Buffer::Iterator start) const
 {
     start.WriteU8(m_type);
     start.WriteHtonU32(m_sourceId);
     start.WriteHtonU32(m_destId);
     start.WriteHtonU32(m_dataId);
     start.WriteHtonU64(m_timestamp);
     start.WriteU8(m_priority);
     start.WriteU8(m_hopCount);
     start.WriteU8(m_pathId);
     start.WriteHtonU32(m_sequenceNum);
 }
 
 uint32_t MessageHeader::Deserialize(Buffer::Iterator start)
{
    try {
        // 确保有足够的字节可读
        uint32_t bytesNeeded = GetSerializedSize();
        if (start.GetRemainingSize() < bytesNeeded) {
            NS_LOG_ERROR("MessageHeader::Deserialize - 数据包大小不足: 需要 " 
                        << bytesNeeded << " 字节，但只有 " << start.GetRemainingSize() << " 字节");
            return 0; // 不消耗任何字节
        }
        
        // 保存起始位置以便在出现问题时回退
        Buffer::Iterator savedStart = start;
        
        try {
            m_type = start.ReadU8();
            m_sourceId = start.ReadNtohU32();
            m_destId = start.ReadNtohU32();
            m_dataId = start.ReadNtohU32();
            m_timestamp = start.ReadNtohU64();
            m_priority = start.ReadU8();
            m_hopCount = start.ReadU8();
            m_pathId = start.ReadU8();
            m_sequenceNum = start.ReadNtohU32();
        } catch (...) {
            NS_LOG_ERROR("MessageHeader::Deserialize - 读取字段时出错");
            return 0;
        }
        
        return bytesNeeded;
    } catch (const std::exception& e) {
        NS_LOG_ERROR("MessageHeader::Deserialize - 异常: " << e.what());
        
        // 重置所有字段
        m_type = 0;
        m_sourceId = 0;
        m_destId = 0;
        m_dataId = 0;
        m_timestamp = 0;
        m_priority = 0;
        m_hopCount = 0;
        m_pathId = 0;
        m_sequenceNum = 0;
        
        return 0;
    } catch (...) {
        NS_LOG_ERROR("MessageHeader::Deserialize - 未知异常");
        
        // 重置所有字段
        m_type = 0;
        m_sourceId = 0;
        m_destId = 0;
        m_dataId = 0;
        m_timestamp = 0;
        m_priority = 0;
        m_hopCount = 0;
        m_pathId = 0;
        m_sequenceNum = 0;
        
        return 0;
    }
}
 
 void MessageHeader::Print(std::ostream &os) const
 {
     os << "MessageHeader [Type=" << (uint32_t)m_type 
        << ", SourceId=" << m_sourceId 
        << ", DestId=" << m_destId 
        << ", DataId=" << m_dataId 
        << ", Priority=" << (uint32_t)m_priority
        << ", HopCount=" << (uint32_t)m_hopCount
        << ", PathId=" << (uint32_t)m_pathId
        << ", SeqNum=" << m_sequenceNum
        << ", Timestamp=" << m_timestamp << "]";
 }
 
 // Enhanced node state header
 class NodeStateHeader : public Header 
 {
 public:
     NodeStateHeader();
     virtual ~NodeStateHeader();
     
     // Set state properties
     void SetNodeId(uint32_t nodeId);
     void SetStability(double stability);
     void SetRequestIntensity(double requestIntensity);
     void SetLoad(double load);
     void SetSignalStrength(double signal);       // NEW: Set signal strength
     void SetAvgDelay(double delay);              // NEW: Set average delay
     void SetProximity(double proximity);         // NEW: Set proximity
     void SetBufferAvailable(uint32_t buffer);    // NEW: Set available buffer
     
     // Get state properties
     uint32_t GetNodeId() const;
     double GetStability() const;
     double GetRequestIntensity() const;
     double GetLoad() const;
     double GetSignalStrength() const;            // NEW: Get signal strength
     double GetAvgDelay() const;                  // NEW: Get average delay
     double GetProximity() const;                 // NEW: Get proximity
     uint32_t GetBufferAvailable() const;         // NEW: Get available buffer
     
     // Header serialization/deserialization
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
 
 private:
     uint32_t m_nodeId;           // Node ID
     double m_stability;          // Stability factor (S)
     double m_requestIntensity;   // Request intensity factor (I)
     double m_load;               // Load factor (L)
     double m_signalStrength;     // NEW: Signal strength to subscriber
     double m_avgDelay;           // NEW: Average delay to subscriber
     double m_proximity;          // NEW: Proximity to subscriber
     uint32_t m_bufferAvailable;  // NEW: Available buffer space
 };
 
 NodeStateHeader::NodeStateHeader()
     : m_nodeId(0), m_stability(0.0), m_requestIntensity(0.0), m_load(0.0),
       m_signalStrength(0.0), m_avgDelay(0.0), m_proximity(0.0), m_bufferAvailable(0)
 {
 }
 
 NodeStateHeader::~NodeStateHeader()
 {
 }
 
 TypeId NodeStateHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::NodeStateHeader")
         .SetParent<Header>()
         .AddConstructor<NodeStateHeader>();
     return tid;
 }
 
 TypeId NodeStateHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void NodeStateHeader::SetNodeId(uint32_t nodeId)
 {
     m_nodeId = nodeId;
 }
 
 void NodeStateHeader::SetStability(double stability)
 {
     m_stability = stability;
 }
 
 void NodeStateHeader::SetRequestIntensity(double requestIntensity)
 {
     m_requestIntensity = requestIntensity;
 }
 
 void NodeStateHeader::SetLoad(double load)
 {
     m_load = load;
 }
 
 void NodeStateHeader::SetSignalStrength(double signal)
 {
     m_signalStrength = signal;
 }
 
 void NodeStateHeader::SetAvgDelay(double delay)
 {
     m_avgDelay = delay;
 }
 
 void NodeStateHeader::SetProximity(double proximity)
 {
     m_proximity = proximity;
 }
 
 void NodeStateHeader::SetBufferAvailable(uint32_t buffer)
 {
     m_bufferAvailable = buffer;
 }
 
 uint32_t NodeStateHeader::GetNodeId() const
 {
     return m_nodeId;
 }
 
 double NodeStateHeader::GetStability() const
 {
     return m_stability;
 }
 
 double NodeStateHeader::GetRequestIntensity() const
 {
     return m_requestIntensity;
 }
 
 double NodeStateHeader::GetLoad() const
 {
     return m_load;
 }
 
 double NodeStateHeader::GetSignalStrength() const
 {
     return m_signalStrength;
 }
 
 double NodeStateHeader::GetAvgDelay() const
 {
     return m_avgDelay;
 }
 
 double NodeStateHeader::GetProximity() const
 {
     return m_proximity;
 }
 
 uint32_t NodeStateHeader::GetBufferAvailable() const
 {
     return m_bufferAvailable;
 }
 
 uint32_t NodeStateHeader::GetSerializedSize() const
 {
     return 4 + 8 + 8 + 8 + 8 + 8 + 8 + 4; // nodeId + stability + requestIntensity + load + signalStrength + avgDelay + proximity + bufferAvailable
 }
 
 void NodeStateHeader::Serialize(Buffer::Iterator start) const
 {
     // Write node ID
     start.WriteHtonU32(m_nodeId);
     
     // Convert floating-point values to fixed-point representation
     uint64_t stabilityFixed = static_cast<uint64_t>(m_stability * 1000000.0);
     uint64_t requestIntensityFixed = static_cast<uint64_t>(m_requestIntensity * 1000000.0);
     uint64_t loadFixed = static_cast<uint64_t>(m_load * 1000000.0);
     uint64_t signalStrengthFixed = static_cast<uint64_t>(m_signalStrength * 1000000.0);
     uint64_t avgDelayFixed = static_cast<uint64_t>(m_avgDelay * 1000000.0);
     uint64_t proximityFixed = static_cast<uint64_t>(m_proximity * 1000000.0);
     
     // Write fixed-point values
     start.WriteHtonU64(stabilityFixed);
     start.WriteHtonU64(requestIntensityFixed);
     start.WriteHtonU64(loadFixed);
     start.WriteHtonU64(signalStrengthFixed);
     start.WriteHtonU64(avgDelayFixed);
     start.WriteHtonU64(proximityFixed);
     start.WriteHtonU32(m_bufferAvailable);
 }
 
 uint32_t NodeStateHeader::Deserialize(Buffer::Iterator start)
{
    try {
        // 确保有足够的字节可读
        uint32_t bytesNeeded = GetSerializedSize();
        if (start.GetRemainingSize() < bytesNeeded) {
            NS_LOG_ERROR("NodeStateHeader::Deserialize - 数据包大小不足: 需要 " 
                        << bytesNeeded << " 字节，但只有 " << start.GetRemainingSize() << " 字节");
            return 0;
        }
        
        // 保存起始位置
        Buffer::Iterator savedStart = start;
        
        try {
            // 读取数据
            m_nodeId = start.ReadNtohU32();
            
            uint64_t stabilityFixed = start.ReadNtohU64();
            uint64_t requestIntensityFixed = start.ReadNtohU64();
            uint64_t loadFixed = start.ReadNtohU64();
            uint64_t signalStrengthFixed = start.ReadNtohU64();
            uint64_t avgDelayFixed = start.ReadNtohU64();
            uint64_t proximityFixed = start.ReadNtohU64();
            m_bufferAvailable = start.ReadNtohU32();
            
            // 转换固定点到浮点
            m_stability = static_cast<double>(stabilityFixed) / 1000000.0;
            m_requestIntensity = static_cast<double>(requestIntensityFixed) / 1000000.0;
            m_load = static_cast<double>(loadFixed) / 1000000.0;
            m_signalStrength = static_cast<double>(signalStrengthFixed) / 1000000.0;
            m_avgDelay = static_cast<double>(avgDelayFixed) / 1000000.0;
            m_proximity = static_cast<double>(proximityFixed) / 1000000.0;
        } catch (...) {
            NS_LOG_ERROR("NodeStateHeader::Deserialize - 读取字段时出错");
            return 0;
        }
        
        return bytesNeeded;
    } catch (const std::exception& e) {
        NS_LOG_ERROR("NodeStateHeader::Deserialize - 异常: " << e.what());
        
        // 重置所有字段
        m_nodeId = 0;
        m_stability = 0.0;
        m_requestIntensity = 0.0;
        m_load = 0.0;
        m_signalStrength = 0.0;
        m_avgDelay = 0.0;
        m_proximity = 0.0;
        m_bufferAvailable = 0;
        
        return 0;
    } catch (...) {
        NS_LOG_ERROR("NodeStateHeader::Deserialize - 未知异常");
        
        // 重置所有字段
        m_nodeId = 0;
        m_stability = 0.0;
        m_requestIntensity = 0.0;
        m_load = 0.0;
        m_signalStrength = 0.0;
        m_avgDelay = 0.0;
        m_proximity = 0.0;
        m_bufferAvailable = 0;
        
        return 0;
    }
}

 void NodeStateHeader::Print(std::ostream &os) const
 {
     os << "NodeStateHeader [NodeId=" << m_nodeId 
        << ", Stability=" << m_stability 
        << ", RequestIntensity=" << m_requestIntensity 
        << ", Load=" << m_load 
        << ", SignalStrength=" << m_signalStrength
        << ", AvgDelay=" << m_avgDelay
        << ", Proximity=" << m_proximity
        << ", BufferAvailable=" << m_bufferAvailable << "]";
 }
 
 // NEW: Selective Acknowledgment Header
 class SelectiveAckHeader : public Header
 {
 public:
     SelectiveAckHeader();
     virtual ~SelectiveAckHeader();
     
     // Set/Get properties
     void SetSourceId(uint32_t sourceId);
     void SetDestId(uint32_t destId);
     void AddAckedSeqNum(uint32_t seqNum);
     void ClearAckedSeqNums();
     uint32_t GetSourceId() const;
     uint32_t GetDestId() const;
     const std::set<uint32_t>& GetAckedSeqNums() const;
     
     // Header serialization/deserialization
     static TypeId GetTypeId();
     virtual TypeId GetInstanceTypeId() const;
     virtual uint32_t GetSerializedSize() const;
     virtual void Serialize(Buffer::Iterator start) const;
     virtual uint32_t Deserialize(Buffer::Iterator start);
     virtual void Print(std::ostream &os) const;
     
 private:
     uint32_t m_sourceId;              // Source node ID
     uint32_t m_destId;                // Destination node ID
     std::set<uint32_t> m_ackedSeqNums; // Sequence numbers being acknowledged
 };
 
 SelectiveAckHeader::SelectiveAckHeader()
     : m_sourceId(0), m_destId(0)
 {
 }
 
 SelectiveAckHeader::~SelectiveAckHeader()
 {
 }
 
 TypeId SelectiveAckHeader::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::SelectiveAckHeader")
         .SetParent<Header>()
         .AddConstructor<SelectiveAckHeader>();
     return tid;
 }
 
 TypeId SelectiveAckHeader::GetInstanceTypeId() const
 {
     return GetTypeId();
 }
 
 void SelectiveAckHeader::SetSourceId(uint32_t sourceId)
 {
     m_sourceId = sourceId;
 }
 
 void SelectiveAckHeader::SetDestId(uint32_t destId)
 {
     m_destId = destId;
 }
 
 void SelectiveAckHeader::AddAckedSeqNum(uint32_t seqNum)
 {
     m_ackedSeqNums.insert(seqNum);
 }
 
 void SelectiveAckHeader::ClearAckedSeqNums()
 {
     m_ackedSeqNums.clear();
 }
 
 uint32_t SelectiveAckHeader::GetSourceId() const
 {
     return m_sourceId;
 }
 
 uint32_t SelectiveAckHeader::GetDestId() const
 {
     return m_destId;
 }
 
 const std::set<uint32_t>& SelectiveAckHeader::GetAckedSeqNums() const
 {
     return m_ackedSeqNums;
 }
 
 uint32_t SelectiveAckHeader::GetSerializedSize() const
 {
     return 4 + 4 + 4 + (4 * m_ackedSeqNums.size()); // sourceId + destId + count + seqNums
 }
 
 void SelectiveAckHeader::Serialize(Buffer::Iterator start) const
 {
     start.WriteHtonU32(m_sourceId);
     start.WriteHtonU32(m_destId);
     start.WriteHtonU32(m_ackedSeqNums.size()); // Number of sequence numbers
     
     // Write each sequence number
     for (uint32_t seqNum : m_ackedSeqNums) {
         start.WriteHtonU32(seqNum);
     }
 }
 
 uint32_t SelectiveAckHeader::Deserialize(Buffer::Iterator start)
{
    try {
        // 检查基本头部大小
        if (start.GetRemainingSize() < 12) { // sourceId(4) + destId(4) + count(4)
            NS_LOG_ERROR("SelectiveAckHeader::Deserialize - 数据包太小，无法读取基本头部");
            return 0;
        }
        
        // 保存原始迭代器以便回滚
        Buffer::Iterator originalStart = start;
        
        m_sourceId = start.ReadNtohU32();
        m_destId = start.ReadNtohU32();
        uint32_t count = start.ReadNtohU32();
        
        // 严格限制ACK数量，防止数组溢出和缓冲区溢出
        // 这是关键修复点
        if (count > 100) { // 设置一个合理的上限
            NS_LOG_ERROR("SelectiveAckHeader::Deserialize - 无效的ACK数量: " << count);
            return 0;
        }
        
        // 实际上只处理最多10个ACK
        count = std::min(count, static_cast<uint32_t>(10));
        
        // 确保剩余字节足够
        if (start.GetRemainingSize() < count * 4) {
            NS_LOG_ERROR("SelectiveAckHeader::Deserialize - 数据包太小，无法读取 " 
                        << count << " 个序列号");
            
            // 限制为实际可用的序列号数量
            count = start.GetRemainingSize() / 4;
        }
        
        m_ackedSeqNums.clear();
        for (uint32_t i = 0; i < count; i++) {
            // 再次检查是否有足够的数据可读 - 这是防止断言失败的关键
            if (start.GetRemainingSize() < 4) {
                NS_LOG_ERROR("SelectiveAckHeader::Deserialize - 缓冲区用尽，停止读取序列号");
                break;
            }
            
            uint32_t seqNum = start.ReadNtohU32();
            m_ackedSeqNums.insert(seqNum);
        }
        
        // 返回实际读取的字节数
        return 12 + (4 * count); // sourceId(4) + destId(4) + count(4) + seqNums(4*count)
    } catch (const std::exception& e) {
        NS_LOG_ERROR("SelectiveAckHeader::Deserialize - 异常: " << e.what());
        
        // 重置所有字段
        m_sourceId = 0;
        m_destId = 0;
        m_ackedSeqNums.clear();
        
        return 0;
    } catch (...) {
        NS_LOG_ERROR("SelectiveAckHeader::Deserialize - 未知异常");
        
        // 重置所有字段
        m_sourceId = 0;
        m_destId = 0;
        m_ackedSeqNums.clear();
        
        return 0;
    }
}
 
 void SelectiveAckHeader::Print(std::ostream &os) const
 {
     os << "SelectiveAckHeader [SourceId=" << m_sourceId 
        << ", DestId=" << m_destId
        << ", AckCount=" << m_ackedSeqNums.size() << "]";
 }
 
 // Enhanced MANETApplication with improved reliability features
 class MANETApplication : public Application
 {
 public:
     static TypeId GetTypeId();
     MANETApplication();
     virtual ~MANETApplication();
     
     void Setup(uint32_t nodeId, 
               Ptr<NeighborTracker> neighborTracker,
               Ptr<RequestTracker> requestTracker,
               Ptr<LoadTracker> loadTracker,
               Ptr<ConnectivityManager> connectivityManager);
     
     void StartApplication() override;
     void StopApplication() override;
     
     // Enhanced send methods
     void SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId);
     void SendPacketWithPriority(uint32_t destId, uint8_t packetType, uint32_t dataId, uint8_t priority);
     void SendPacketOnPath(uint32_t destId, uint8_t packetType, uint32_t dataId, uint8_t priority, uint8_t pathId);
     void SendMultipathPacket(uint32_t destId, uint8_t packetType, uint32_t dataId);
     void ForwardPacket(Ptr<Packet> packet, uint32_t nextHop);
     void SendSelectiveAck(uint32_t destId);
     
     // Start publishing data (Publisher only)
     void StartPublishing();
     
     // Start sending subscribe requests (Subscriber only)
     void StartSubscribing();
     
     // Start broadcasting state information
     void StartStateBroadcasting();
     
     // Process received packets
     void HandleRead(Ptr<Socket> socket);
     
     // For tracking delays and delivery rates
     void RecordDelay(Time delay);
     void RecordMessageSent();
     void RecordMessageReceived();
     double GetAverageDelay() const;
     double GetDeliveryRate() const;
 
     // Set/Get current broker node
     void SetCurrentBroker(uint32_t brokerId);
     uint32_t GetCurrentBroker() const;
     
     // Add accessors for message counters
     uint32_t GetMessagesSent() const { return m_messagesSent; }
     uint32_t GetMessagesReceived() const { return m_messagesReceived; }
     
     // Migration management
     void InitiateMigration(uint32_t newBrokerId);
     void PrepareForMigration(uint32_t targetNode);
     void CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId);
     Time GetFirstMigrationTime() const { return m_firstMigrationTime; }
     void SetFirstMigrationTime(Time time) { m_firstMigrationTime = time; }
     
     // Backup broker management
     void AssignBackupBroker(uint32_t backupId);
     uint32_t GetBackupBroker() const { return m_backupBrokerId; }
     
     // RSSI and proactive migration
     void CheckRssiAndPredict();
     bool ShouldMigrateProactively() const;
     
     // Multipath routing
     bool HasMultiplePaths(uint32_t destId) const;
     
     // ACK management
     void CheckAckTimeout();
     void SendAck(uint32_t dataId, uint32_t sourceId);
     void ProcessAck(uint32_t dataId, uint32_t sourceId);
     
     // Message buffering
     void BufferMessage(uint32_t dataId, uint32_t destId);
     void ProcessBufferedMessages();
     
     // Set configuration options
     void SetUseMsgNotReachedTrigger(bool use) { m_useMsgNotReachedTrigger = use; }
     bool GetUseMsgNotReachedTrigger() const { return m_useMsgNotReachedTrigger; }
     void SetAckTimeout(Time timeout) { m_ackTimeout = timeout; }
     void SetUseProactiveMigration(bool use) { m_useProactiveMigration = use; }
     void SetUseMultipath(bool use) { m_useMultipath = use; }
     void SetUseBuffering(bool use) { m_useBuffering = use; }
     
     // Connectivity check
     bool IsReachable(uint32_t fromNode, uint32_t toNode) const {
         if (m_connectivityManager) {
             return m_connectivityManager->IsReachable(fromNode, toNode);
         }
         return false;
     }
     
     // Accessor methods for local content
     void AddLocalContent(uint32_t contentId) { m_localContent.insert(contentId); }
     bool HasContent(uint32_t contentId) const { 
         return m_localContent.find(contentId) != m_localContent.end(); 
     }
     const std::set<uint32_t>& GetLocalContent() const { return m_localContent; }
     
     // Accessor methods for migration status
     bool HasMigratedContent() const { return m_hasMigratedContent; }
     void SetHasMigratedContent(bool hasMigrated) { m_hasMigratedContent = hasMigrated; }
     
 private:
     // Calculate node score based on enhanced formula
     double CalculateNodeScore(uint32_t nodeId);
     
     // Select the best node for migration
     uint32_t SelectBestBrokerNode();
     
     // Update neighbor list based on current connectivity
     void UpdateNeighbors();
     
     // Scheduled events
     void PeriodicSubscribe();
     void PeriodicPublish();
     void PeriodicStateBroadcast();
     void PeriodicConnectivityCheck();
     void PeriodicMigrationCheck();
     void PeriodicRssiCheck();               // NEW: Check RSSI periodically
     void PeriodicBufferProcessing();        // NEW: Process buffered messages
     void PeriodicSendSelectiveAck();        // NEW: Send selective ACKs
     
     // Socket for communication
     Ptr<Socket> m_socket;
     
     // Node information
     uint32_t m_nodeId;                   // 节点ID
     uint32_t m_currentBrokerId;          // 当前代理节点ID
     bool m_hasMigratedContent;           // 是否已接收迁移内容
     Time m_lastMigrationTime;            // 上次迁移时间
     uint32_t m_backupBrokerId;           // 备份代理节点ID
     
     // Tracking components
     Ptr<NeighborTracker> m_neighborTracker;
     Ptr<RequestTracker> m_requestTracker;
     Ptr<LoadTracker> m_loadTracker;
     Ptr<ConnectivityManager> m_connectivityManager;
     
     // Message tracking
     uint32_t m_nextSequenceNumber;          // Next sequence number for outgoing messages
     std::map<uint32_t, Time> m_sentMessages; // Map of sequence numbers to send time
     std::set<uint32_t> m_receivedSequenceNumbers; // Set of received sequence numbers
     std::map<uint32_t, Ptr<Packet>> m_bufferedMessages; // Messages buffered for later delivery
     std::map<uint32_t, Time> m_bufferedTimes; // When each message was buffered
     std::map<uint32_t, std::set<uint32_t>> m_receivedAcks; // Received ACKs by data ID
     
     // Statistics
     std::vector<Time> m_delays;
     uint32_t m_messagesSent;
     uint32_t m_messagesReceived;
     uint32_t m_bufferedMessageCount;
     uint32_t m_multipathMessageCount;
     
     // Enhanced statistics for different message types
     MessageStats m_normalStats;      // Stats for normal messages
     MessageStats m_priorityStats;    // Stats for priority messages
     MessageStats m_multipathStats;   // Stats for multipath messages
     
     // Current node state
     std::map<uint32_t, NodeState> m_nodeStates;
     std::set<uint32_t> m_currentNeighbors;
     
     // Event IDs for scheduling
     EventId m_subscribeEvent;
     EventId m_publishEvent;
     EventId m_stateBroadcastEvent;
     EventId m_connectivityCheckEvent;
     EventId m_rssiCheckEvent;            // NEW: RSSI check event
     EventId m_bufferProcessingEvent;     // NEW: Buffer processing event
     EventId m_selectiveAckEvent;         // NEW: Selective ACK event
     
     // Debug counters
     uint32_t m_migrationCount;          // Number of migrations performed
     uint32_t m_receivedStateUpdates;    // Number of state updates received
     uint32_t m_proactiveMigrations;     // Number of proactive migrations
     Time m_firstMigrationTime;          // 首次迁移时间
     
     // ACK and message tracking
     bool m_waitingForAck;                // Whether broker is waiting for ACK
     uint32_t m_lastDataId;               // Last sent data ID
     Time m_lastDataSentTime;             // When last data was sent
     Time m_ackTimeout;                   // ACK timeout
     EventId m_ackTimeoutEvent;           // ACK timeout event
     
     // Feature flags
     bool m_useMsgNotReachedTrigger;      // Use message non-delivery trigger
     bool m_useProactiveMigration;        // Use proactive migration
     bool m_useMultipath;                 // Use multipath routing
     bool m_useBuffering;                 // Use message buffering
     
     // Local content storage
     std::set<uint32_t> m_localContent;  // IDs of content stored locally
 };
 
 NS_OBJECT_ENSURE_REGISTERED(MANETApplication);
 
 TypeId MANETApplication::GetTypeId()
 {
     static TypeId tid = TypeId("ns3::MANETApplication")
         .SetParent<Application>()
         .AddConstructor<MANETApplication>();
     return tid;
 }
 
 MANETApplication::MANETApplication()
     : m_nodeId(0),                             // 修复初始化顺序
       m_currentBrokerId(INITIAL_BROKER_NODE),  // 按声明顺序排列初始化
       m_hasMigratedContent(false),
       m_lastMigrationTime(Seconds(0)),
       m_backupBrokerId(UINT32_MAX),
       m_neighborTracker(nullptr),
       m_requestTracker(nullptr),
       m_loadTracker(nullptr),
       m_connectivityManager(nullptr),
       m_nextSequenceNumber(1),
       m_messagesSent(0),
       m_messagesReceived(0),
       m_bufferedMessageCount(0),
       m_multipathMessageCount(0),
       m_migrationCount(0),
       m_receivedStateUpdates(0), 
       m_proactiveMigrations(0),
       m_firstMigrationTime(Seconds(-1)),
       m_waitingForAck(false),
       m_lastDataId(0),
       m_lastDataSentTime(Seconds(0)),
       m_ackTimeout(Seconds(1.0)),
       m_useMsgNotReachedTrigger(true),
       m_useProactiveMigration(true),
       m_useMultipath(true),
       m_useBuffering(true)
 {
 }
 
 MANETApplication::~MANETApplication()
 {
 }
 
 void MANETApplication::Setup(uint32_t nodeId, 
                            Ptr<NeighborTracker> neighborTracker,
                            Ptr<RequestTracker> requestTracker,
                            Ptr<LoadTracker> loadTracker,
                            Ptr<ConnectivityManager> connectivityManager)
 {
     m_nodeId = nodeId;
     m_neighborTracker = neighborTracker;
     m_requestTracker = requestTracker;
     m_loadTracker = loadTracker;
     m_connectivityManager = connectivityManager;
     
     // Publisher and initial broker have initial content
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE) {
         m_localContent.insert(1); // Content ID 1
         m_hasMigratedContent = true;
     }
 }
 
 void MANETApplication::StartApplication()
 {
     // Create and setup socket
     if (!m_socket) {
         m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
         InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), 9);
         m_socket->Bind(local);
         m_socket->SetRecvCallback(MakeCallback(&MANETApplication::HandleRead, this));
     }
     
     // Start periodic connectivity checks
     m_connectivityCheckEvent = Simulator::Schedule(Seconds(1.0), 
                                                   &MANETApplication::PeriodicConnectivityCheck, 
                                                   this);
     
     // Start broadcasting state information
     if (m_nodeId != PUBLISHER_NODE) { // Publisher doesn't need to broadcast state
         StartStateBroadcasting();
     }
     
     // Start RSSI checks for proactive migration
     if (m_useProactiveMigration && (m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE)) {
         m_rssiCheckEvent = Simulator::Schedule(Seconds(0.5), 
                                              &MANETApplication::PeriodicRssiCheck, 
                                              this);
     }
     
     // Start buffer processing if enabled
     if (m_useBuffering) {
         m_bufferProcessingEvent = Simulator::Schedule(Seconds(1.0), 
                                                     &MANETApplication::PeriodicBufferProcessing, 
                                                     this);
     }
     
     // Start selective ACK sending if enabled
     if (m_nodeId == SUBSCRIBER_NODE) {
         m_selectiveAckEvent = Simulator::Schedule(Seconds(0.5), 
                                                 &MANETApplication::PeriodicSendSelectiveAck, 
                                                 this);
     }
     
     // Specific roles
     if (m_nodeId == PUBLISHER_NODE) {
         // Publisher starts publishing
         StartPublishing();
     } else if (m_nodeId == SUBSCRIBER_NODE) {
         // Subscriber starts subscribing after a brief delay
         Simulator::Schedule(Seconds(1.0), &MANETApplication::StartSubscribing, this);
     }
     
     // Log application start
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == INITIAL_BROKER_NODE || m_nodeId == SUBSCRIBER_NODE) {
         // 修改：更频繁检查迁移（从5秒改为2秒）
         Simulator::Schedule(Seconds(2.0), &MANETApplication::PeriodicMigrationCheck, this);
         NS_LOG_INFO("Node " << m_nodeId << " (" << 
                    (m_nodeId == PUBLISHER_NODE ? "Publisher" : 
                     (m_nodeId == INITIAL_BROKER_NODE ? "Broker" : "Subscriber")) << 
                    ") application started at " << Simulator::Now().GetSeconds() << "s");
     }
 }
 
 void MANETApplication::StopApplication()
 {
     // Cancel any pending events
     if (m_subscribeEvent.IsPending()) {
         Simulator::Cancel(m_subscribeEvent);
     }
     
     if (m_publishEvent.IsPending()) {
         Simulator::Cancel(m_publishEvent);
     }
     
     if (m_stateBroadcastEvent.IsPending()) {
         Simulator::Cancel(m_stateBroadcastEvent);
     }
     
     if (m_connectivityCheckEvent.IsPending()) {
         Simulator::Cancel(m_connectivityCheckEvent);
     }
     
     if (m_rssiCheckEvent.IsPending()) {
         Simulator::Cancel(m_rssiCheckEvent);
     }
     
     if (m_bufferProcessingEvent.IsPending()) {
         Simulator::Cancel(m_bufferProcessingEvent);
     }
     
     if (m_selectiveAckEvent.IsPending()) {
         Simulator::Cancel(m_selectiveAckEvent);
     }
     
     if (m_ackTimeoutEvent.IsPending()) {
         Simulator::Cancel(m_ackTimeoutEvent);
     }
     
     // Close socket
     if (m_socket) {
         m_socket->Close();
     }
     
     // Log application stop for key nodes
     if (m_nodeId == PUBLISHER_NODE || m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE) {
         std::string role = m_nodeId == PUBLISHER_NODE ? "Publisher" : 
                           (m_nodeId == m_currentBrokerId ? "Broker" : "Subscriber");
         
         NS_LOG_INFO("Node " << m_nodeId << " (" << role << ") application stopped at " 
                    << Simulator::Now().GetSeconds() << "s");
         
         // Log final statistics
         if (m_nodeId == SUBSCRIBER_NODE) {
             NS_LOG_INFO("Subscriber final statistics: " 
                        << "Average Delay = " << GetAverageDelay() * 1000.0 << " ms, "
                        << "Delivery Rate = " << GetDeliveryRate() * 100.0 << "%");
             
             if (m_useMultipath) {
                 NS_LOG_INFO("Multipath statistics: "
                            << m_multipathMessageCount << " messages sent via multiple paths, "
                            << "Delivery rate = " << m_multipathStats.GetDeliveryRate() * 100.0 << "%");
             }
             
             if (m_useBuffering) {
                 NS_LOG_INFO("Buffering statistics: "
                            << m_bufferedMessageCount << " messages buffered, "
                            << "Recovery rate = " << (m_bufferedMessageCount > 0 ? 
                               ((double)m_messagesReceived / m_bufferedMessageCount) * 100.0 : 0.0) << "%");
             }
         }
         
         if (m_hasMigratedContent) {
             NS_LOG_INFO("Node " << m_nodeId << " has content: " << m_localContent.size() 
                        << " items, migration count: " << m_migrationCount);
         }
         
         if (m_proactiveMigrations > 0) {
             NS_LOG_INFO("Node " << m_nodeId << " initiated " << m_proactiveMigrations 
                        << " proactive migrations");
         }
     }
 }
 
 void MANETApplication::SendPacket(uint32_t destId, uint8_t packetType, uint32_t dataId)
 {
     // Default to normal priority
     SendPacketWithPriority(destId, packetType, dataId, NORMAL_PRIORITY);
 }
 
 void MANETApplication::SendPacketWithPriority(uint32_t destId, uint8_t packetType, uint32_t dataId, uint8_t priority)
 {
     // Check if multipath should be used for important messages
     if (m_useMultipath && 
         priority >= HIGH_PRIORITY && 
         (packetType == DATA_RESPONSE || packetType == SUBSCRIBE_REQUEST)) {
         
         SendMultipathPacket(destId, packetType, dataId);
         return;
     }
     
     // Only check reachability for regular data packets
     if (packetType != STATE_BROADCAST) {
         bool isReachable = m_connectivityManager->IsReachable(m_nodeId, destId);
         
         if (!isReachable) {
             NS_LOG_INFO("Node " << m_nodeId << " cannot send " << (int)packetType 
                        << " to Node " << destId << " - not reachable");
             
             // If buffering is enabled and this is important data, buffer it
             if (m_useBuffering && 
                 (packetType == DATA_RESPONSE || packetType == SUBSCRIBE_REQUEST)) {
                 BufferMessage(dataId, destId);
             }
             
             return;
         }
         
         // If direct next hop isn't available, try alternative routes
         uint32_t nextHop = m_connectivityManager->GetNextHop(m_nodeId, destId);
         if (nextHop == UINT32_MAX) {
             NS_LOG_INFO("Node " << m_nodeId << " cannot find route to " << destId);
             
             // Check for relay nodes that might help
             std::vector<uint32_t> relays = m_connectivityManager->FindRelayNodes(m_nodeId, destId);
             if (!relays.empty()) {
                 NS_LOG_INFO("Node " << m_nodeId << " found " << relays.size() 
                           << " potential relay nodes to reach " << destId);
                 
                 // Try to send via first relay
                 SendPacketWithPriority(relays[0], packetType, dataId, priority);
                 return;
             }
             
             if (m_useBuffering) {
                 BufferMessage(dataId, destId);
             }
             
             return;
         }
     }
     
     // Create packet with header
     Ptr<Packet> packet = Create<Packet>(100); // Add 100 bytes payload for realistic packet size
     
     MessageHeader header;
     header.SetType(packetType);
     header.SetSourceId(m_nodeId);
     header.SetDestId(destId);
     header.SetDataId(dataId);
     header.SetTimestamp(Simulator::Now());
     header.SetPriority(priority);
     header.SetHopCount(0);
     header.SetPathId(0);
     header.SetSequenceNum(m_nextSequenceNumber++);
     
     packet->AddHeader(header);
     
     // If sending state broadcast, add node state header
     if (packetType == STATE_BROADCAST) {
         NodeStateHeader stateHeader;
         stateHeader.SetNodeId(m_nodeId);
         stateHeader.SetStability(m_neighborTracker->GetStability(m_nodeId));
         stateHeader.SetRequestIntensity(m_requestTracker->GetRequestIntensity(m_nodeId));
         stateHeader.SetLoad(m_loadTracker->GetLoad(m_nodeId));
         
         // Enhanced state information
         double signalStrength = 0.0;
         if (m_nodeId != SUBSCRIBER_NODE) {
             signalStrength = m_connectivityManager->GetSignalStrength(m_nodeId, SUBSCRIBER_NODE);
         }
         stateHeader.SetSignalStrength(signalStrength);
         
         // Calculate proximity as inverse of distance (normalized)
         double distance = m_connectivityManager->GetDistance(m_nodeId, SUBSCRIBER_NODE);
         double proximity = distance < COMMUNICATION_RANGE ? 
                           (COMMUNICATION_RANGE - distance) / COMMUNICATION_RANGE : 0.0;
         stateHeader.SetProximity(proximity);
         
         // Set average delay if applicable
         double avgDelay = (m_nodeId == SUBSCRIBER_NODE) ? 0.0 : GetAverageDelay();
         stateHeader.SetAvgDelay(avgDelay);
         
         // Set buffer availability
         uint32_t bufferAvailable = m_loadTracker->GetBufferSize(m_nodeId) - 
                                  m_loadTracker->GetBufferUsed(m_nodeId);
         stateHeader.SetBufferAvailable(bufferAvailable);
         
         packet->AddHeader(stateHeader);
     }
     
     // Add IP address of destination
     Ptr<Node> node = GetNode();
     Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
     
     // Get destination IP (assumes nodes have IP addresses 10.1.1.X where X is the node ID + 1)
     std::ostringstream oss;
     oss << "10.1.1." << (destId + 1);
     Ipv4Address ipDest(oss.str().c_str());
     
     // Send packet
     m_socket->SendTo(packet, 0, InetSocketAddress(ipDest, 9));
     
     // Store sent message time for calculating RTT
     if (packetType == DATA_RESPONSE || packetType == SUBSCRIBE_REQUEST) {
         uint32_t seqNum = header.GetSequenceNum();
         m_sentMessages[seqNum] = Simulator::Now();
     }
     
     // In Broker, start waiting for ACK when sending data to Subscriber
     if (m_nodeId == m_currentBrokerId && destId == SUBSCRIBER_NODE && 
         packetType == DATA_RESPONSE && m_useMsgNotReachedTrigger) {
         
         m_waitingForAck = true;
         m_lastDataId = dataId;
         m_lastDataSentTime = Simulator::Now();
         
         // Cancel previous timeout event if any
         if (m_ackTimeoutEvent.IsPending()) {
             Simulator::Cancel(m_ackTimeoutEvent);
         }
         
         // Set new timeout event
         m_ackTimeoutEvent = Simulator::Schedule(m_ackTimeout, 
                                               &MANETApplication::CheckAckTimeout, 
                                               this);
         
         NS_LOG_INFO("Broker " << m_nodeId << " 发送数据ID " << dataId 
                    << " 给Subscriber，开始等待确认，超时时间: " 
                    << m_ackTimeout.GetSeconds() << "秒");
     }
     
     // Count message statistics
     if ((m_nodeId == SUBSCRIBER_NODE && packetType == SUBSCRIBE_REQUEST) ||
         (m_nodeId == m_currentBrokerId && packetType == DATA_RESPONSE && destId == SUBSCRIBER_NODE)) {
         RecordMessageSent();
         
         // Update global stats
         g_totalMessagesSent++;
         
         // Update priority-specific stats
         if (priority == NORMAL_PRIORITY) {
             m_normalStats.sent++;
         } else if (priority >= HIGH_PRIORITY) {
             m_priorityStats.sent++;
         }
         
         // 修改：添加更详细的统计日志
         if (DEBUG_MESSAGE_STATS) {
             NS_LOG_INFO("统计消息发送: Node " << m_nodeId << " 发送 " 
                       << (packetType == SUBSCRIBE_REQUEST ? "订阅请求" : "数据响应")
                       << " 到 " << destId << ", 优先级: " << (int)priority 
                       << ", 总计: " << m_messagesSent 
                       << ", 全局总计: " << g_totalMessagesSent);
         }
     }
     
     // Log the packet transmission for important packet types
     if (packetType == SUBSCRIBE_REQUEST || 
         packetType == DATA_RESPONSE || 
         packetType == REPLICA_MIGRATION_REQUEST || 
         packetType == REPLICA_MIGRATION_DATA ||
         packetType == DATA_RESPONSE_ACK ||
         packetType == PROACTIVE_MIGRATION_NOTIFY ||
         packetType == MIGRATION_PREPARE ||
         packetType == BACKUP_BROKER_ASSIGN) {
         
         NS_LOG_INFO("Node " << m_nodeId << " sent " << (int)packetType << " packet to Node " << destId
                   << " with priority " << (int)priority
                   << " at time " << Simulator::Now().GetSeconds() << "s");
     }
 }
 
 void MANETApplication::SendPacketOnPath(uint32_t destId, uint8_t packetType, uint32_t dataId, 
                                      uint8_t priority, uint8_t pathId)
 {
     // Get path to destination
     std::vector<std::vector<uint32_t>> paths = m_connectivityManager->GetMultiplePaths(m_nodeId, destId);
     
     if (pathId >= paths.size() || paths.empty()) {
         NS_LOG_INFO("Node " << m_nodeId << " cannot send on path " << (int)pathId 
                   << " - invalid path ID");
         return;
     }
     
     std::vector<uint32_t>& path = paths[pathId];
     if (path.size() < 2) {
         NS_LOG_INFO("Node " << m_nodeId << " path to " << destId << " is too short");
         return;
     }
     
     // Create packet with header
     Ptr<Packet> packet = Create<Packet>(100); // 100 bytes payload
     
     MessageHeader header;
     header.SetType(packetType);
     header.SetSourceId(m_nodeId);
     header.SetDestId(destId);
     header.SetDataId(dataId);
     header.SetTimestamp(Simulator::Now());
     header.SetPriority(priority);
     header.SetHopCount(0);
     header.SetPathId(pathId);
     header.SetSequenceNum(m_nextSequenceNumber++);
     
     packet->AddHeader(header);
     
     // Send to next hop in the path
     uint32_t nextHop = path[1]; // Next hop is the second node in the path
     
     // Add IP address of next hop
     Ptr<Node> node = GetNode();
     Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
     
     // Get next hop IP
     std::ostringstream oss;
     oss << "10.1.1." << (nextHop + 1);
     Ipv4Address ipNext(oss.str().c_str());
     
     // Send packet
     m_socket->SendTo(packet, 0, InetSocketAddress(ipNext, 9));
     
     // Store sent message time
     uint32_t seqNum = header.GetSequenceNum();
     m_sentMessages[seqNum] = Simulator::Now();
     
     // 修复: 在SendPacketOnPath中也需要计数统计
     if ((m_nodeId == SUBSCRIBER_NODE && packetType == SUBSCRIBE_REQUEST) ||
         (m_nodeId == m_currentBrokerId && packetType == DATA_RESPONSE && destId == SUBSCRIBER_NODE)) {
         RecordMessageSent();
         g_totalMessagesSent++;
         
         if (DEBUG_MESSAGE_STATS) {
             NS_LOG_INFO("统计multipath消息发送: Node " << m_nodeId << " 通过路径 " << (int)pathId
                       << " 发送 " << (packetType == SUBSCRIBE_REQUEST ? "订阅请求" : "数据响应")
                       << " 到 " << destId << ", 总计: " << m_messagesSent
                       << ", 全局总计: " << g_totalMessagesSent);
         }
     }
     
     // Update statistics
     if (packetType == DATA_RESPONSE || packetType == SUBSCRIBE_REQUEST) {
         m_multipathStats.sent++;
         m_multipathMessageCount++;
         
         NS_LOG_INFO("Node " << m_nodeId << " sent multipath packet on path " << (int)pathId 
                   << " to " << destId << " via " << nextHop);
     }
 }
 
 void MANETApplication::SendMultipathPacket(uint32_t destId, uint8_t packetType, uint32_t dataId)
{
    std::vector<std::vector<uint32_t>> paths = m_connectivityManager->GetMultiplePaths(m_nodeId, destId);
    
    if (paths.empty()) {
        // Fallback to regular send if no paths found
        SendPacketWithPriority(destId, packetType, dataId, HIGH_PRIORITY);
        return;
    }
    
    // Limit to MAX_MULTIPATH_ROUTES paths
    size_t numPaths = std::min(paths.size(), (size_t)MAX_MULTIPATH_ROUTES);
    
    NS_LOG_INFO("Node " << m_nodeId << " sending multipath packet to " << destId 
               << " using " << numPaths << " paths");
    
    // Send on each available path
    for (size_t i = 0; i < numPaths; i++) {
        SendPacketOnPath(destId, packetType, dataId, HIGH_PRIORITY, i);
    }
}

void MANETApplication::ForwardPacket(Ptr<Packet> packet, uint32_t nextHop)
{
    // Extract header to update hop count
    MessageHeader header;
    packet->RemoveHeader(header);
    
    // Increment hop count
    header.SetHopCount(header.GetHopCount() + 1);
    
    // Re-add updated header
    packet->AddHeader(header);
    
    // Send to next hop
    std::ostringstream oss;
    oss << "10.1.1." << (nextHop + 1);
    Ipv4Address ipNext(oss.str().c_str());
    
    // Forward packet
    m_socket->SendTo(packet, 0, InetSocketAddress(ipNext, 9));
    
    NS_LOG_INFO("Node " << m_nodeId << " forwarded packet to " << nextHop);
}

void MANETApplication::SendSelectiveAck(uint32_t destId)
{
    // Create empty packet
    Ptr<Packet> packet = Create<Packet>();
    
    // Add message header first
    MessageHeader msgHeader;
    msgHeader.SetType(SELECTIVE_ACK);
    msgHeader.SetSourceId(m_nodeId);
    msgHeader.SetDestId(destId);
    msgHeader.SetDataId(0); // Not used for selective ACK
    msgHeader.SetTimestamp(Simulator::Now());
    msgHeader.SetPriority(HIGH_PRIORITY);
    msgHeader.SetSequenceNum(m_nextSequenceNumber++);
    
    packet->AddHeader(msgHeader);
    
    // Add selective ACK header
    SelectiveAckHeader ackHeader;
    ackHeader.SetSourceId(m_nodeId);
    ackHeader.SetDestId(destId);
    
    // Add received sequence numbers (limit to recent ones)
    size_t count = 0;
    for (uint32_t seqNum : m_receivedSequenceNumbers) {
        ackHeader.AddAckedSeqNum(seqNum);
        count++;
        if (count >= 10) break; // Limit to 10 sequence numbers
    }
    
    packet->AddHeader(ackHeader);
    
    // Send to destination
    std::ostringstream oss;
    oss << "10.1.1." << (destId + 1);
    Ipv4Address ipDest(oss.str().c_str());
    
    m_socket->SendTo(packet, 0, InetSocketAddress(ipDest, 9));
    
    NS_LOG_INFO("Node " << m_nodeId << " sent selective ACK to " << destId 
               << " with " << count << " sequence numbers");
}

void MANETApplication::HandleRead(Ptr<Socket> socket)
{
    Ptr<Packet> packet;
    Address from;
    
    // Receive packet
    while ((packet = socket->RecvFrom(from))) {
        // 先检查数据包大小是否合理
        uint32_t packetSize = packet->GetSize();
        if (packetSize < 24) { // 最小MessageHeader大小
            NS_LOG_WARN("收到大小不正确的数据包: " << packetSize << " 字节");
            continue;
        }
        
        // 使用拷贝操作避免破坏原始数据包
        Ptr<Packet> copy = packet->Copy();
        MessageHeader header;
        
        // 尝试移除消息头，并检查是否成功
        if (copy->RemoveHeader(header) == 0) {
            NS_LOG_WARN("无法解析消息头");
            continue;
        }
        
        uint8_t packetType = header.GetType();
        uint32_t sourceId = header.GetSourceId();
        uint32_t destId = header.GetDestId();
        uint32_t dataId = header.GetDataId();
        Time timestamp = header.GetTimestamp();
        uint8_t priority = header.GetPriority();
        uint8_t hopCount = header.GetHopCount();
        uint8_t pathId = header.GetPathId();
        uint32_t seqNum = header.GetSequenceNum();
        
        // 检查packet是否为我们的目标
        if (destId != m_nodeId) {
            // 这个数据包需要被转发
            if (hopCount < 10) { // 防止无限循环
                uint32_t nextHop = m_connectivityManager->GetNextHop(m_nodeId, destId);
                if (nextHop != UINT32_MAX) {
                    // 转发前重新添加头部
                    packet->AddHeader(header);
                    ForwardPacket(packet, nextHop);
                }
            }
            continue; // 跳过进一步处理
        }
        
        // 存储序列号以避免重复
        if (m_receivedSequenceNumbers.find(seqNum) != m_receivedSequenceNumbers.end()) {
            NS_LOG_INFO("Node " << m_nodeId << " received duplicate packet with seqNum " << seqNum);
            continue; // 跳过重复
        }
        
        m_receivedSequenceNumbers.insert(seqNum);
        
        // 处理各种类型的数据包
        if (packetType == SUBSCRIBE_REQUEST) {
            // Broker receives subscription request from subscriber
            if (m_nodeId == m_currentBrokerId || 
                (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end())) {
                
                // If this node has the requested content, send a response
                SendPacketWithPriority(sourceId, DATA_RESPONSE, dataId, HIGH_PRIORITY);
                NS_LOG_INFO("Node " << m_nodeId << " (broker) responded to subscription request from Node " 
                           << sourceId << " at time " << Simulator::Now().GetSeconds() << "s");
            }
            
            // Update request intensity for the source node
            m_requestTracker->IncrementRequestCount(sourceId);
            
        } else if (packetType == DATA_RESPONSE) {
            // Subscriber receives data response from broker
            if (m_nodeId == SUBSCRIBER_NODE) {
                // Record delay
                Time delay = Simulator::Now() - timestamp;
                RecordDelay(delay);
                RecordMessageReceived();
                
                // Update global stats
                g_totalMessagesReceived++;
                
                // Update priority-specific stats
                if (priority == NORMAL_PRIORITY) {
                    m_normalStats.received++;
                    m_normalStats.RecordDelay(delay);
                } else if (priority >= HIGH_PRIORITY) {
                    m_priorityStats.received++;
                    m_priorityStats.RecordDelay(delay);
                }
                
                // Update multipath stats if applicable
                if (pathId > 0) {
                    m_multipathStats.received++;
                    m_multipathStats.RecordDelay(delay);
                }
                
                NS_LOG_INFO("Node " << m_nodeId << " (subscriber) received data response from Node " 
                           << sourceId << " with delay " << delay.GetMilliSeconds() 
                           << "ms at time " << Simulator::Now().GetSeconds() << "s"
                           << " (priority=" << (int)priority << ", path=" << (int)pathId << ")");
                
                // 修改：添加更详细的消息统计信息
                if (DEBUG_MESSAGE_STATS) {
                    NS_LOG_INFO("统计消息接收: 订阅者收到数据响应，总计: " << m_messagesReceived 
                            << ", 发送总数: " << m_messagesSent 
                            << ", 当前交付率: " << GetDeliveryRate() * 100.0 << "%"
                            << ", 全局接收: " << g_totalMessagesReceived
                            << ", 全局发送: " << g_totalMessagesSent
                            << ", 全局交付率: " << (g_totalMessagesSent > 0 ? 
                               ((double)g_totalMessagesReceived/g_totalMessagesSent*100.0) : 0.0) << "%");
                }
                
                // Send acknowledgment
                SendAck(dataId, sourceId);
            }
            
        } else if (packetType == DATA_RESPONSE_ACK) {
            // Broker receives acknowledgment for data
            ProcessAck(dataId, sourceId);
            
        } else if (packetType == SELECTIVE_ACK) {
            // 处理选择性确认 - 关键修复部分
            if (packet->GetSize() < 12) { // 至少需要sourceId(4) + destId(4) + count(4)
                NS_LOG_WARN("选择性确认数据包太小: " << packet->GetSize() << " 字节");
                continue;
            }
            
            // 尝试解析选择性确认头部
            SelectiveAckHeader ackHeader;
            uint32_t headerSize = packet->RemoveHeader(ackHeader);
            
            if (headerSize == 0) {
                NS_LOG_WARN("无法解析选择性确认头部");
                continue;
            }
            
            uint32_t ackSourceId = ackHeader.GetSourceId();
            // 获取但不存储目标ID
            ackHeader.GetDestId();
            
            const std::set<uint32_t>& ackSeqNums = ackHeader.GetAckedSeqNums();
            
            // 只在调试模式下记录所有序列号
            if (ackSeqNums.size() > 0) {
                NS_LOG_INFO("Node " << m_nodeId << " received selective ACK from " << ackSourceId
                          << " with " << ackSeqNums.size() << " sequence numbers");
                
                // 处理已确认的序列号
                for (uint32_t ackSeq : ackSeqNums) {
                    auto it = m_sentMessages.find(ackSeq);
                    if (it != m_sentMessages.end()) {
                        Time sentTime = it->second;
                        Time rtt = Simulator::Now() - sentTime;
                        
                        NS_LOG_INFO("  Seq " << ackSeq << " RTT: " << rtt.GetMilliSeconds() << "ms");
                        
                        // 从已发送消息中移除
                        m_sentMessages.erase(it);
                    }
                }
            }
        } else if (packetType == STATE_BROADCAST) {
            // 处理状态广播
            if (packet->GetSize() < 48) { // 至少需要足够大的数据包
                NS_LOG_WARN("状态广播数据包太小: " << packet->GetSize() << " 字节");
                continue;
            }
            
            // 尝试移除节点状态头部
            NodeStateHeader stateHeader;
            uint32_t headerSize = packet->RemoveHeader(stateHeader);
            
            if (headerSize == 0) {
                NS_LOG_WARN("无法解析节点状态头部");
                continue;
            }
            
            uint32_t stateNodeId = stateHeader.GetNodeId();
            double stability = stateHeader.GetStability();
            double requestIntensity = stateHeader.GetRequestIntensity();
            double load = stateHeader.GetLoad();
            double signalStrength = stateHeader.GetSignalStrength();
            double avgDelay = stateHeader.GetAvgDelay();
            double proximity = stateHeader.GetProximity();
            // 不使用bufferAvailable变量以避免警告
            stateHeader.GetBufferAvailable(); // 读取值但不存储，避免编译警告
            
            // 更新节点状态信息
            NodeState state;
            state.nodeId = stateNodeId;
            state.stability = stability;
            state.requestIntensity = requestIntensity;
            state.load = load;
            state.signalStrength = signalStrength;
            state.avgDelay = avgDelay;
            state.proximity = proximity;
            state.reachableToSubscriber = m_connectivityManager->IsReachable(stateNodeId, SUBSCRIBER_NODE);
            state.lastUpdateTime = Simulator::Now();
            
            m_nodeStates[stateNodeId] = state;
            m_receivedStateUpdates++;
            
            // 仅偶尔记录状态更新以避免日志过多
            if (DEBUG_SCORING && (m_receivedStateUpdates % 100 == 0)) {
                NS_LOG_INFO("Node " << m_nodeId << " received state update from Node " << stateNodeId
                          << " [S=" << stability << ", I=" << requestIntensity << ", L=" << load 
                          << ", Signal=" << signalStrength << ", Proximity=" << proximity
                          << ", Delay=" << avgDelay << "s]");
            }
            
            // 检查是否需要进行主动迁移
            if (m_nodeId == m_currentBrokerId && m_useProactiveMigration && 
                stateNodeId == SUBSCRIBER_NODE && signalStrength < PROACTIVE_MIGRATION_THRESHOLD) {
                
                NS_LOG_INFO("Broker detected low signal strength (" << signalStrength 
                          << ") from Subscriber - checking if proactive migration needed");
                
                CheckRssiAndPredict();
            }
            
        } else if (packetType == REPLICA_MIGRATION_REQUEST) {
            // 处理复制迁移请求
            // 如果请求来自当前代理并且此节点有内容，发送内容
            if (sourceId == m_currentBrokerId && 
                (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end())) {
                
                SendPacketWithPriority(sourceId, REPLICA_MIGRATION_DATA, dataId, CRITICAL_PRIORITY);
                NS_LOG_INFO("Node " << m_nodeId << " sent content migration to new broker Node " 
                           << sourceId << " at time " << Simulator::Now().GetSeconds() << "s");
            }
            
            // 如果请求来自订阅者，自我指定为代理
            else if (sourceId == SUBSCRIBER_NODE && m_nodeId != m_currentBrokerId) {
                // 此节点在订阅者的分区中，订阅者希望它成为代理
                NS_LOG_INFO("Node " << m_nodeId << " received subscriber-initiated migration request. "
                           << "Becoming new broker at " << Simulator::Now().GetSeconds() << "s");
                
                // 标记此节点有内容
                m_localContent.insert(dataId);
                m_hasMigratedContent = true;
                
                uint32_t oldBrokerId = m_currentBrokerId;
                m_currentBrokerId = m_nodeId;
                
                // 完成迁移过程
                CompleteMigration(oldBrokerId, m_nodeId);
                m_migrationCount++;
                m_lastMigrationTime = Simulator::Now();
                
                // 记录首次迁移时间
                if (m_migrationCount == 1) {
                    m_firstMigrationTime = Simulator::Now();
                    
                    // 设置全局迁移跟踪变量
                    g_migrationOccurred = true;
                    g_firstMigrationTime = m_firstMigrationTime;
                }
                
                // 让订阅者知道此节点现在是代理
                SendPacketWithPriority(SUBSCRIBER_NODE, DATA_RESPONSE, dataId, HIGH_PRIORITY);
            }
            
        } else if (packetType == REPLICA_MIGRATION_DATA) {
            // 接收迁移的内容
            m_localContent.insert(dataId);
            m_hasMigratedContent = true;
            
            // 更新代理状态
            uint32_t oldBrokerId = m_currentBrokerId;
            m_currentBrokerId = m_nodeId;
            
            // 完成迁移
            CompleteMigration(oldBrokerId, m_nodeId);
            m_migrationCount++;
            m_lastMigrationTime = Simulator::Now();
            
            // 记录首次迁移时间
            if (m_migrationCount == 1) {
                m_firstMigrationTime = Simulator::Now();
                
                // 设置全局迁移跟踪变量
                g_migrationOccurred = true;
                g_firstMigrationTime = m_firstMigrationTime;
            }
            
            NS_LOG_INFO("Node " << m_nodeId << " received migrated content and is now the new broker at time " 
                       << Simulator::Now().GetSeconds() << "s");
            
            // 由于接收新内容，稍微增加负载
            double currentLoad = m_loadTracker->GetLoad(m_nodeId);
            m_loadTracker->UpdateLoad(m_nodeId, currentLoad + 0.1);
            
            // 如果订阅者在附近，向他们发送内容
            if (m_connectivityManager->IsReachable(m_nodeId, SUBSCRIBER_NODE)) {
                SendPacketWithPriority(SUBSCRIBER_NODE, DATA_RESPONSE, dataId, HIGH_PRIORITY);
            }
        
        } else if (packetType == PROACTIVE_MIGRATION_NOTIFY) {
            // 处理主动迁移通知
            if (m_hasMigratedContent && m_localContent.find(dataId) != m_localContent.end()) {
                NS_LOG_INFO("Node " << m_nodeId << " received proactive migration notification from " 
                          << sourceId << " at " << Simulator::Now().GetSeconds() << "s");
                
                // 向新代理发送内容
                SendPacketWithPriority(sourceId, REPLICA_MIGRATION_DATA, dataId, CRITICAL_PRIORITY);
            }
            
        } else if (packetType == MIGRATION_PREPARE) {
            // 处理迁移准备
            NS_LOG_INFO("Node " << m_nodeId << " received migration preparation from " 
                      << sourceId << " at " << Simulator::Now().GetSeconds() << "s");
            
            // 更新负载以反映准备成为代理的状态
            double currentLoad = m_loadTracker->GetLoad(m_nodeId);
            m_loadTracker->UpdateLoad(m_nodeId, currentLoad * 0.8); // 降低负载以增加成为代理的机会
            
            // 发送更新的状态
            SendPacketWithPriority(sourceId, STATE_BROADCAST, 0, HIGH_PRIORITY);
            
        } else if (packetType == BACKUP_BROKER_ASSIGN) {
            // 这个节点被指派为备份代理
            NS_LOG_INFO("Node " << m_nodeId << " assigned as backup broker by " 
                      << sourceId << " at " << Simulator::Now().GetSeconds() << "s");
            
            // 如果尚未成为备份代理，请求内容
            if (m_backupBrokerId != m_nodeId) {
                m_backupBrokerId = m_nodeId;
                g_backupBroker = m_nodeId;
                
                // 如果还没有内容，请求内容
                if (!m_hasMigratedContent) {
                    SendPacketWithPriority(m_currentBrokerId, REPLICA_MIGRATION_REQUEST, 1, HIGH_PRIORITY);
                }
            }
        }
    }
}

void MANETApplication::SendAck(uint32_t dataId, uint32_t sourceId)
{
    // Send direct acknowledgment for received data
    SendPacketWithPriority(sourceId, DATA_RESPONSE_ACK, dataId, HIGH_PRIORITY);
    
    // Record this acknowledgment
    if (m_receivedAcks.find(dataId) == m_receivedAcks.end()) {
        m_receivedAcks[dataId] = std::set<uint32_t>();
    }
    m_receivedAcks[dataId].insert(sourceId);
    
    NS_LOG_INFO("Node " << m_nodeId << " sent ACK to " << sourceId 
               << " for data ID " << dataId);
}

void MANETApplication::ProcessAck(uint32_t dataId, uint32_t sourceId)
{
    if (m_nodeId == m_currentBrokerId && m_waitingForAck && dataId == m_lastDataId) {
        Time rtt = Simulator::Now() - m_lastDataSentTime;
        
        NS_LOG_INFO("Broker " << m_nodeId << " received ACK for data ID " << dataId 
                   << " from " << sourceId << ", RTT: " << rtt.GetMilliSeconds() << "ms");
        
        // Cancel timeout - 修复使用 IsPending() 替代 IsRunning()
        if (m_ackTimeoutEvent.IsPending()) {
            Simulator::Cancel(m_ackTimeoutEvent);
        }
        
        // Reset waiting state
        m_waitingForAck = false;
    }
}

void MANETApplication::CheckAckTimeout()
{
    if (m_nodeId == m_currentBrokerId && m_waitingForAck) {
        NS_LOG_INFO("Broker " << m_nodeId << " detected ACK timeout for data ID " << m_lastDataId);
        
        // Reset waiting state
        m_waitingForAck = false;
        
        // Trigger migration based on ACK timeout
        if (m_useMsgNotReachedTrigger) {
            NS_LOG_INFO("Triggering migration due to ACK timeout");
            
            // First try multipath retransmission if enabled
            if (m_useMultipath && HasMultiplePaths(SUBSCRIBER_NODE)) {
                NS_LOG_INFO("Attempting multipath retransmission before migration");
                SendMultipathPacket(SUBSCRIBER_NODE, DATA_RESPONSE, m_lastDataId);
                
                // Schedule another check in case multipath also fails
                m_ackTimeoutEvent = Simulator::Schedule(m_ackTimeout, 
                                                      &MANETApplication::CheckAckTimeout, 
                                                      this);
                return;
            }
            
            // If we have a backup broker, activate it
            if (g_backupBroker != UINT32_MAX && g_backupBroker != m_nodeId) {
                NS_LOG_INFO("Activating backup broker " << g_backupBroker);
                
                // Complete migration to backup broker
                CompleteMigration(m_nodeId, g_backupBroker);
                return;
            }
            
            // Otherwise select a new broker
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            if (newBrokerId != m_currentBrokerId && newBrokerId != m_nodeId) {
                NS_LOG_INFO("Selected new broker " << newBrokerId << " due to ACK timeout");
                InitiateMigration(newBrokerId);
            } else {
                NS_LOG_INFO("Could not find suitable new broker - trying to reestablish connection");
                
                // Try to resend data with higher priority
                SendPacketWithPriority(SUBSCRIBER_NODE, DATA_RESPONSE, m_lastDataId, CRITICAL_PRIORITY);
            }
        }
    }
}

void MANETApplication::BufferMessage(uint32_t dataId, uint32_t destId)
{
    // Create message packet to buffer
    Ptr<Packet> packet = Create<Packet>(100);
    
    MessageHeader header;
    header.SetType(DATA_RESPONSE);
    header.SetSourceId(m_nodeId);
    header.SetDestId(destId);
    header.SetDataId(dataId);
    header.SetTimestamp(Simulator::Now());
    header.SetPriority(HIGH_PRIORITY);
    header.SetSequenceNum(m_nextSequenceNumber++);
    
    packet->AddHeader(header);
    
    // Try to buffer the message
    if (m_loadTracker->BufferMessage(m_nodeId)) {
        uint32_t bufferKey = dataId * 1000 + destId; // Unique key for dataId+destId combo
        m_bufferedMessages[bufferKey] = packet;
        m_bufferedTimes[bufferKey] = Simulator::Now();
        m_bufferedMessageCount++;
        
        NS_LOG_INFO("Node " << m_nodeId << " buffered message (dataId=" << dataId 
                   << ", destId=" << destId << "), total buffered: " << m_bufferedMessageCount);
    } else {
        NS_LOG_INFO("Node " << m_nodeId << " buffer full, cannot buffer message");
    }
}

void MANETApplication::ProcessBufferedMessages()
{
    std::vector<uint32_t> processedKeys;
    
    // Check each buffered message
    for (auto const& [key, packet] : m_bufferedMessages) {
        Ptr<Packet> copiedPacket = packet->Copy();
        MessageHeader header;
        copiedPacket->PeekHeader(header);
        
        uint32_t destId = header.GetDestId();
        
        // If destination is now reachable, send the message
        if (m_connectivityManager->IsReachable(m_nodeId, destId)) {
            // Get destination IP
            std::ostringstream oss;
            oss << "10.1.1." << (destId + 1);
            Ipv4Address ipDest(oss.str().c_str());
            
            // Send buffered packet
            m_socket->SendTo(packet, 0, InetSocketAddress(ipDest, 9));
            
            // Mark as processed
            processedKeys.push_back(key);
            
            // Release buffer space
            m_loadTracker->ReleaseBuffer(m_nodeId);
            
            Time bufferTime = Simulator::Now() - m_bufferedTimes[key];
            NS_LOG_INFO("Node " << m_nodeId << " sent buffered message to " << destId 
                       << " after " << bufferTime.GetSeconds() << "s");
        } else {
            // Check if buffered for too long (over 10 seconds)
            Time bufferTime = Simulator::Now() - m_bufferedTimes[key];
            if (bufferTime > Seconds(10)) {
                // Release buffer space for old messages
                m_loadTracker->ReleaseBuffer(m_nodeId);
                processedKeys.push_back(key);
                
                NS_LOG_INFO("Node " << m_nodeId << " discarded old buffered message for " 
                          << destId << " after " << bufferTime.GetSeconds() << "s");
            }
        }
    }

    // Remove processed messages from buffer
    for (uint32_t key : processedKeys) {
        m_bufferedMessages.erase(key);
        m_bufferedTimes.erase(key);
    }
}

bool MANETApplication::HasMultiplePaths(uint32_t destId) const
{
    std::vector<std::vector<uint32_t>> paths = m_connectivityManager->GetMultiplePaths(m_nodeId, destId);
    return paths.size() > 1;
}

void MANETApplication::CheckRssiAndPredict()
{
    if (!m_useProactiveMigration) return;

    // Check if subscriber signal strength is low and dropping
    if (m_nodeId == m_currentBrokerId) {
        double rssi = m_neighborTracker->GetRssi(m_nodeId, SUBSCRIBER_NODE);
        double rssiTrend = m_neighborTracker->GetRssiTrend(m_nodeId, SUBSCRIBER_NODE);
        
        // 修改：降低触发阈值，使迁移更易发生
        if (rssi < PROACTIVE_MIGRATION_THRESHOLD || (rssi < RSSI_WARNING_THRESHOLD && rssiTrend < 0)) {
            NS_LOG_INFO("Broker proactive migration check: RSSI=" << rssi 
                      << ", trend=" << rssiTrend << " - predicting connection loss");
            
            // Select new broker with better connectivity to subscriber
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            if (newBrokerId != m_currentBrokerId && newBrokerId != m_nodeId) {
                NS_LOG_INFO("Proactively migrating to node " << newBrokerId 
                          << " before connection breaks");
                
                // Send prepare message to target node
                SendPacketWithPriority(newBrokerId, MIGRATION_PREPARE, 1, HIGH_PRIORITY);
                
                // Initiate proactive migration
                InitiateMigration(newBrokerId);
                m_proactiveMigrations++;
            } else {
                NS_LOG_INFO("No suitable candidate for proactive migration");
                
                // If a backup broker hasn't been assigned, select one
                if (g_backupBroker == UINT32_MAX) {
                    // Find a node with reasonable connectivity
                    for (const auto& [nodeId, state] : m_nodeStates) {
                        if (nodeId != m_nodeId && nodeId != PUBLISHER_NODE && 
                            nodeId != SUBSCRIBER_NODE && state.reachableToSubscriber &&
                            state.signalStrength > PROACTIVE_MIGRATION_THRESHOLD) {
                            
                            NS_LOG_INFO("Assigning node " << nodeId << " as backup broker");
                            AssignBackupBroker(nodeId);
                            break;
                        }
                    }
                }
            }
        }
    }
}

bool MANETApplication::ShouldMigrateProactively() const
{
    if (!m_useProactiveMigration || m_nodeId != m_currentBrokerId) {
        return false;
    }

    return m_neighborTracker->PredictConnectionBreak(m_nodeId, SUBSCRIBER_NODE);
}

void MANETApplication::AssignBackupBroker(uint32_t backupId)
{
    if (backupId == m_nodeId || backupId == PUBLISHER_NODE || 
        backupId == SUBSCRIBER_NODE || backupId == m_currentBrokerId) {
        return;
    }

    // Send backup assignment message
    SendPacketWithPriority(backupId, BACKUP_BROKER_ASSIGN, 1, HIGH_PRIORITY);

    // Update global backup broker
    g_backupBroker = backupId;

    NS_LOG_INFO("Node " << m_nodeId << " assigned node " << backupId 
              << " as backup broker");
}

void MANETApplication::RecordDelay(Time delay)
{
    m_delays.push_back(delay);
}

void MANETApplication::RecordMessageSent()
{
    m_messagesSent++;
}

void MANETApplication::RecordMessageReceived()
{
    m_messagesReceived++;
}

double MANETApplication::GetAverageDelay() const
{
    if (m_delays.empty()) {
        return 0.0;
    }

    Time totalDelay = Time(0);
    for (const auto& delay : m_delays) {
        totalDelay += delay;
    }

    return totalDelay.GetSeconds() / m_delays.size();
}

double MANETApplication::GetDeliveryRate() const
{
    if (m_messagesSent == 0) {
        return 0.0;
    }

    return (double)m_messagesReceived / m_messagesSent;
}

void MANETApplication::SetCurrentBroker(uint32_t brokerId)
{
    if (m_currentBrokerId != brokerId) {
        NS_LOG_INFO("Node " << m_nodeId << " updated current broker from " 
                 << m_currentBrokerId << " to " << brokerId);
        m_currentBrokerId = brokerId;
    }
}

uint32_t MANETApplication::GetCurrentBroker() const
{
    return m_currentBrokerId;
}

double MANETApplication::CalculateNodeScore(uint32_t nodeId)
{
    // Get node state
    if (m_nodeStates.find(nodeId) == m_nodeStates.end()) {
        return -1.0; // Node state not available
    }

    NodeState state = m_nodeStates[nodeId];

    // Check if node can reach the subscriber
    if (!state.reachableToSubscriber) {
        return -1.0; // Cannot reach subscriber
    }

    // Enhanced scoring formula with new factors:
    // Score = αS + βI - γL + δP - εD
    // Where:
    // S = stability
    // I = request intensity
    // L = load
    // P = proximity to subscriber (NEW)
    // D = delay factor (NEW)

    double score = ALPHA * state.stability +
                 BETA * state.requestIntensity -
                 GAMMA * state.load +
                 DELTA * state.proximity -
                 EPSILON * state.avgDelay;

    if (DEBUG_SCORING) {
        NS_LOG_INFO("Score calculation for Node " << nodeId << ": "
                  << ALPHA << " * " << state.stability << " (stability) + "
                  << BETA << " * " << state.requestIntensity << " (requests) - "
                  << GAMMA << " * " << state.load << " (load) + "
                  << DELTA << " * " << state.proximity << " (proximity) - "
                  << EPSILON << " * " << state.avgDelay << " (delay) = " << score);
    }

    return score;
}

uint32_t MANETApplication::SelectBestBrokerNode() {
    double bestScore = -100.0;
    uint32_t bestNode = UINT32_MAX;

    NS_LOG_INFO("Starting broker selection, current broker: " << m_currentBrokerId);

    // Get nodes in same partition as subscriber
    std::set<uint32_t> subscriberPartition = m_connectivityManager->GetNodesInSamePartition(SUBSCRIBER_NODE);

    NS_LOG_INFO("Found " << subscriberPartition.size() << " nodes in subscriber's partition");

    // Log partition nodes
    std::ostringstream partitionNodes;
    for (uint32_t n : subscriberPartition) {
        partitionNodes << n << " ";
    }
    NS_LOG_INFO("Partition nodes: " << partitionNodes.str());

    // Evaluate each node in subscriber's partition
    for (uint32_t nodeId : subscriberPartition) {
        if (nodeId == PUBLISHER_NODE) {
            NS_LOG_INFO("  Node " << nodeId << " is Publisher, skipping");
            continue; // Publisher shouldn't be broker
        }
        
        // Enhanced scoring considering multiple factors
        double score = CalculateNodeScore(nodeId);
        NS_LOG_INFO("  Node " << nodeId << " score: " << score);
        
        // Prioritize nodes with content if possible
        Ptr<Node> node = NodeList::GetNode(nodeId);
        if (node) {
            Ptr<MANETApplication> app = DynamicCast<MANETApplication>(node->GetApplication(0));
            if (app && app->HasMigratedContent()) {
                // Bonus for already having content
                score += 0.5;
                NS_LOG_INFO("  Node " << nodeId << " has content, adjusted score: " << score);
            }
        }
        
        if (score > bestScore) {
            bestScore = score;
            bestNode = nodeId;
            NS_LOG_INFO("  Node " << nodeId << " is new best candidate with score " << score);
        }
    }

    // If no suitable node found, select any non-Publisher node in subscriber's partition
    if (bestNode == UINT32_MAX && !subscriberPartition.empty()) {
        for (uint32_t nodeId : subscriberPartition) {
            if (nodeId != PUBLISHER_NODE) {
                bestNode = nodeId;
                NS_LOG_INFO("No node with positive score found, selecting node " << bestNode << " as fallback");
                break;
            }
        }
    }

    // If still no node found, use current broker (may lead to failed migration)
    if (bestNode == UINT32_MAX) {
        bestNode = m_currentBrokerId;
        NS_LOG_INFO("No suitable node found, defaulting to current broker " << bestNode);
    }

    return bestNode;
}

void MANETApplication::InitiateMigration(uint32_t newBrokerId)
{
    NS_LOG_INFO("Node " << m_nodeId << " initiating content migration to new broker Node " 
             << newBrokerId << " at time " << Simulator::Now().GetSeconds() << "s");

    // Send a migration request to the target node
    if (m_useProactiveMigration) {
        // Use proactive migration protocol
        SendPacketWithPriority(newBrokerId, PROACTIVE_MIGRATION_NOTIFY, 1, CRITICAL_PRIORITY);
    } else {
        // Use regular migration request
        SendPacketWithPriority(newBrokerId, REPLICA_MIGRATION_REQUEST, 1, HIGH_PRIORITY);
    }
}

void MANETApplication::PrepareForMigration(uint32_t targetNode)
{
    NS_LOG_INFO("Node " << m_nodeId << " preparing node " << targetNode << " for migration");

    // Notify target node to prepare for migration
    SendPacketWithPriority(targetNode, MIGRATION_PREPARE, 1, HIGH_PRIORITY);

    // Wait briefly for preparation
    Simulator::Schedule(MilliSeconds(50), &MANETApplication::InitiateMigration, this, targetNode);
}

void MANETApplication::CompleteMigration(uint32_t oldBrokerId, uint32_t newBrokerId) {
    // Update all nodes' current broker ID
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        Ptr<Node> node = NodeList::GetNode(i);
        if (!node) {
            NS_LOG_ERROR("Node " << i << " is null");
            continue;
        }
        
        Ptr<MANETApplication> app = DynamicCast<MANETApplication>(node->GetApplication(0));
        if (app) {
            app->SetCurrentBroker(newBrokerId);
        }
    }

    // Log migration completion
    NS_LOG_INFO("**** MIGRATION_COMPLETE: Time=" << Simulator::Now().GetSeconds() 
             << "s, Old=" << oldBrokerId 
             << ", New=" << newBrokerId << " ****");

    // Record first migration time
    if (m_migrationCount == 0) {
        m_firstMigrationTime = Simulator::Now();
        NS_LOG_INFO("First migration completed at " << m_firstMigrationTime.GetSeconds() << "s");
        
        // Set global migration tracking variables
        g_migrationOccurred = true;
        g_firstMigrationTime = m_firstMigrationTime;
        
        // Update subscriber's migration time
        Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
            NodeList::GetNode(SUBSCRIBER_NODE)->GetApplication(0));
        if (subApp && subApp->GetFirstMigrationTime().GetSeconds() <= 0) {
            subApp->SetFirstMigrationTime(Simulator::Now());
            NS_LOG_INFO("Updated subscriber's migration time: " 
                     << subApp->GetFirstMigrationTime().GetSeconds() << "s");
        }
    }

    // Increment migration count
    m_migrationCount++;

    // Log new broker state if available
    if (DEBUG_MIGRATION && m_nodeStates.find(newBrokerId) != m_nodeStates.end()) {
        NodeState state = m_nodeStates[newBrokerId];
        NS_LOG_INFO("New broker state: S=" << state.stability 
                   << ", I=" << state.requestIntensity 
                   << ", L=" << state.load
                   << ", Proximity=" << state.proximity
                   << ", Signal=" << state.signalStrength
                   << ", Score=" << CalculateNodeScore(newBrokerId));
    }

    // Reset backup broker after migration
    g_backupBroker = UINT32_MAX;
}

void MANETApplication::UpdateNeighbors()
{
    // Get current neighbors based on connectivity
    std::set<uint32_t> neighbors;

    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i == m_nodeId) continue;
        
        // If node i is directly reachable, it's a neighbor
        bool isReachable = m_connectivityManager->IsReachable(m_nodeId, i);
        // 删除未使用变量 distance 并直接使用方法返回的距离
        
        if (isReachable) {
            neighbors.insert(i);
            
            // Calculate signal strength based on distance
            double signalStrength = m_connectivityManager->GetSignalStrength(m_nodeId, i);
            
            // Record RSSI for neighbor tracking
            m_neighborTracker->RecordRssi(m_nodeId, i, signalStrength);
        }
    }

    // Update neighbor tracker with the new neighbor set
    m_neighborTracker->UpdateNeighbors(m_nodeId, neighbors);

    // Update local neighbor set
    m_currentNeighbors = neighbors;

    // For subscriber, log position and neighbors if changed
    if (m_nodeId == SUBSCRIBER_NODE && DEBUG_MOBILITY) {
        static uint32_t lastNeighborCount = 0;
        
        if (neighbors.size() != lastNeighborCount) {
            // Get the node's mobility model
            Ptr<MobilityModel> mobility = GetNode()->GetObject<MobilityModel>();
            if (mobility) {
                Vector position = mobility->GetPosition();
                
                NS_LOG_INFO("SUBSCRIBER at time " << Simulator::Now().GetSeconds() 
                          << "s: position=(" << position.x << "," << position.y << ")," 
                          << " neighbors=" << neighbors.size());
                
                lastNeighborCount = neighbors.size();
            }
        }
    }
}

void MANETApplication::StartPublishing()
{
    // Schedule periodic publishing
    m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                      &MANETApplication::PeriodicPublish, 
                                      this);
}

void MANETApplication::StartSubscribing()
{
    // Send initial subscribe request to current broker
    SendPacketWithPriority(m_currentBrokerId, SUBSCRIBE_REQUEST, 1, HIGH_PRIORITY);

    // Schedule periodic subscribing
    m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                       &MANETApplication::PeriodicSubscribe, 
                                       this);

    NS_LOG_INFO("Node " << m_nodeId << " (Subscriber) started subscribing at " 
             << Simulator::Now().GetSeconds() << "s");
}

void MANETApplication::StartStateBroadcasting()
{
    // Schedule periodic state broadcasting
    m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                             &MANETApplication::PeriodicStateBroadcast, 
                                             this);
}

void MANETApplication::PeriodicSubscribe()
{
    // Determine if this subscription should use multipath
    bool useMultipath = m_useMultipath && HasMultiplePaths(m_currentBrokerId);

    if (useMultipath) {
        // Send via multiple paths
        SendMultipathPacket(m_currentBrokerId, SUBSCRIBE_REQUEST, 1);
    } else {
        // Send normal subscription request
        SendPacketWithPriority(m_currentBrokerId, SUBSCRIBE_REQUEST, 1, HIGH_PRIORITY);
    }

    // Schedule next subscription request
    m_subscribeEvent = Simulator::Schedule(Seconds(REQUEST_INTERVAL), 
                                       &MANETApplication::PeriodicSubscribe, 
                                       this);
}

void MANETApplication::PeriodicPublish()
{
    // Publisher sends data to current broker
    if (m_nodeId == PUBLISHER_NODE) {
        SendPacketWithPriority(m_currentBrokerId, DATA_RESPONSE, 1, HIGH_PRIORITY);
    }

    // Schedule next publish event
    m_publishEvent = Simulator::Schedule(Seconds(1.0 / PUBLISH_RATE), 
                                      &MANETApplication::PeriodicPublish, 
                                      this);
}

void MANETApplication::PeriodicStateBroadcast()
{
    // Broadcast state information to all nodes
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i != m_nodeId) {
            SendPacket(i, STATE_BROADCAST, 0);
        }
    }

    // Schedule next state broadcast
    m_stateBroadcastEvent = Simulator::Schedule(Seconds(STATE_BROADCAST_INTERVAL), 
                                             &MANETApplication::PeriodicStateBroadcast, 
                                             this);
}

void MANETApplication::PeriodicConnectivityCheck()
{
    // Update neighbors based on current connectivity
    UpdateNeighbors();

    // Schedule next connectivity check
    m_connectivityCheckEvent = Simulator::Schedule(Seconds(CONNECTIVITY_UPDATE_INTERVAL), 
                                               &MANETApplication::PeriodicConnectivityCheck, 
                                               this);
}

void MANETApplication::PeriodicRssiCheck()
{
    // Only run RSSI check for broker and subscriber
    if (m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE) {
        CheckRssiAndPredict();
    }

    // Schedule next RSSI check
    m_rssiCheckEvent = Simulator::Schedule(Seconds(0.5), 
                                       &MANETApplication::PeriodicRssiCheck, 
                                       this);
}

void MANETApplication::PeriodicBufferProcessing()
{
    // Process buffered messages
    if (m_useBuffering && !m_bufferedMessages.empty()) {
        ProcessBufferedMessages();
    }

    // Schedule next buffer processing
    m_bufferProcessingEvent = Simulator::Schedule(Seconds(0.5), 
                                              &MANETApplication::PeriodicBufferProcessing, 
                                              this);
}

void MANETApplication::PeriodicSendSelectiveAck()
{
    // Send selective ACK to broker
    if (m_nodeId == SUBSCRIBER_NODE && !m_receivedSequenceNumbers.empty()) {
        SendSelectiveAck(m_currentBrokerId);
    }

    // Schedule next selective ACK
    m_selectiveAckEvent = Simulator::Schedule(Seconds(1.0), 
                                          &MANETApplication::PeriodicSendSelectiveAck, 
                                          this);
}

void MANETApplication::PeriodicMigrationCheck() {
    // 修改：降低检查间隔，从5秒更新为2秒
    double migrationCheckInterval = 2.0; // 更频繁的检查
    
    // 避免频繁迁移（修改间隔从10秒降低到5秒）
    if (Simulator::Now() <= m_lastMigrationTime + Seconds(5.0)) {
        Simulator::Schedule(Seconds(migrationCheckInterval), &MANETApplication::PeriodicMigrationCheck, this);
        return;
    }

    // Get mobility models for position logging
    Ptr<MobilityModel> subscriberMob = NULL;
    Ptr<MobilityModel> brokerMob = NULL;

    if (NodeList::GetNode(SUBSCRIBER_NODE)) {
        subscriberMob = NodeList::GetNode(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
    }

    if (NodeList::GetNode(m_currentBrokerId)) {
        brokerMob = NodeList::GetNode(m_currentBrokerId)->GetObject<MobilityModel>();
    }

    // Check connectivity in both directions
    bool brokerCanReachSubscriber = m_connectivityManager->IsReachable(m_currentBrokerId, SUBSCRIBER_NODE);
    bool subscriberCanReachBroker = m_connectivityManager->IsReachable(SUBSCRIBER_NODE, m_currentBrokerId);

    // Log detailed connection status
    if (subscriberMob && brokerMob) {
        double distance = subscriberMob->GetDistanceFrom(brokerMob);
        Vector subPos = subscriberMob->GetPosition();
        Vector brkPos = brokerMob->GetPosition();
        
        NS_LOG_INFO("Migration check details: "
                   << "Time=" << Simulator::Now().GetSeconds() 
                   << "s, BrokerID=" << m_currentBrokerId
                   << ", SubPos=(" << subPos.x << "," << subPos.y << ")"
                   << ", BrkPos=(" << brkPos.x << "," << brkPos.y << ")"
                   << ", Distance=" << distance << "m"
                   << ", CommRange=" << COMMUNICATION_RANGE << "m"
                   << ", Reach B->S: " << (brokerCanReachSubscriber ? "YES" : "NO")
                   << ", Reach S->B: " << (subscriberCanReachBroker ? "YES" : "NO"));
    } else {
        NS_LOG_INFO("Migration check at " << Simulator::Now().GetSeconds() 
                   << "s: Broker->Subscriber: " << (brokerCanReachSubscriber ? "YES" : "NO")
                   << ", Subscriber->Broker: " << (subscriberCanReachBroker ? "YES" : "NO"));
    }

    // If using message non-delivery trigger, skip connectivity-based migration
    // 修改：即使使用消息未达触发器，也进行RSSI预测检查
    if (m_useMsgNotReachedTrigger && !m_useProactiveMigration) {
        NS_LOG_INFO("Using message non-delivery trigger, but still checking RSSI.");
        if (ShouldMigrateProactively() && (m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE)) {
            NS_LOG_INFO("Proactive migration triggered by RSSI prediction despite using message trigger");
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            if (newBrokerId != m_currentBrokerId && newBrokerId != m_nodeId) {
                PrepareForMigration(newBrokerId);
                m_proactiveMigrations++;
                Simulator::Schedule(Seconds(migrationCheckInterval), &MANETApplication::PeriodicMigrationCheck, this);
                return;
            }
        }
    }

    // Check if proactive migration should be triggered
    if (m_useProactiveMigration && (m_nodeId == m_currentBrokerId || m_nodeId == SUBSCRIBER_NODE)) {
        if (ShouldMigrateProactively()) {
            NS_LOG_INFO("Proactive migration triggered by RSSI prediction");
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            if (newBrokerId != m_currentBrokerId && newBrokerId != m_nodeId) {
                PrepareForMigration(newBrokerId);
                m_proactiveMigrations++;
                Simulator::Schedule(Seconds(migrationCheckInterval), &MANETApplication::PeriodicMigrationCheck, this);
                return;
            }
        }
    }

    // Connectivity-based migration logic
    if (m_nodeId == m_currentBrokerId) {
        // Broker logic: If can't reach subscriber, initiate migration
        // 修改：降低迁移阈值，不必完全不可达，当RSSI较低也考虑迁移
        double rssi = m_neighborTracker->GetRssi(m_nodeId, SUBSCRIBER_NODE);
        if (!brokerCanReachSubscriber || rssi < RSSI_WARNING_THRESHOLD) {
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            NS_LOG_INFO("Broker migration candidate: " << newBrokerId 
                       << " (current: " << m_currentBrokerId 
                       << (rssi < RSSI_WARNING_THRESHOLD ? ", low RSSI: " + std::to_string(rssi) : "") << ")");
            
            // Confirm communication with candidate broker
            if (newBrokerId != m_currentBrokerId && 
                newBrokerId != m_nodeId && 
                m_connectivityManager->IsReachable(m_nodeId, newBrokerId)) {
                
                NS_LOG_INFO("Broker initiating migration to: " << newBrokerId);
                InitiateMigration(newBrokerId);
            } else {
                NS_LOG_INFO("Broker cannot reach suitable migration candidate");
                
                // If we have a backup broker, notify it
                if (g_backupBroker != UINT32_MAX && 
                    g_backupBroker != m_nodeId && 
                    m_connectivityManager->IsReachable(m_nodeId, g_backupBroker)) {
                    
                    NS_LOG_INFO("Broker activating backup broker: " << g_backupBroker);
                    InitiateMigration(g_backupBroker);
                }
            }
        } else if (m_useProactiveMigration) {
            // Even if reachable, check if a better broker is available
            double currentRssi = m_neighborTracker->GetRssi(m_nodeId, SUBSCRIBER_NODE);
            
            if (currentRssi < RSSI_WARNING_THRESHOLD) {
                NS_LOG_INFO("Broker has low RSSI (" << currentRssi 
                          << ") to subscriber, checking for better broker");
                
                // Find a node with better connectivity
                uint32_t bestNodeId = UINT32_MAX;
                double bestRssi = currentRssi;
                
                for (const auto& [nodeId, state] : m_nodeStates) {
                    if (nodeId != m_nodeId && nodeId != PUBLISHER_NODE && 
                        state.reachableToSubscriber && state.signalStrength > bestRssi + 0.2) {
                        
                        bestRssi = state.signalStrength;
                        bestNodeId = nodeId;
                    }
                }
                
                if (bestNodeId != UINT32_MAX) {
                    NS_LOG_INFO("Found better broker " << bestNodeId 
                              << " with RSSI " << bestRssi);
                    
                    // Prepare node and initiate migration
                    PrepareForMigration(bestNodeId);
                } else if (g_backupBroker == UINT32_MAX) {
                    // If no better broker and no backup, assign a backup
                    for (const auto& [nodeId, state] : m_nodeStates) {
                        if (nodeId != m_nodeId && nodeId != PUBLISHER_NODE && 
                            nodeId != SUBSCRIBER_NODE && state.reachableToSubscriber) {
                            
                            AssignBackupBroker(nodeId);
                            break;
                        }
                    }
                }
            }
        }
    } 
    else if (m_nodeId == SUBSCRIBER_NODE) {
        // Subscriber logic: If can't reach broker, find node in its partition
        if (!subscriberCanReachBroker) {
            // Find best node in subscriber's partition
            uint32_t newBrokerId = SelectBestBrokerNode();
            
            NS_LOG_INFO("Subscriber selected new broker candidate: " << newBrokerId);
            
            if (newBrokerId != m_currentBrokerId && 
                newBrokerId != SUBSCRIBER_NODE && 
                m_connectivityManager->IsReachable(SUBSCRIBER_NODE, newBrokerId)) {
                
                NS_LOG_INFO("SUBSCRIBER-INITIATED MIGRATION: Requesting " << newBrokerId 
                           << " to become new broker at " << Simulator::Now().GetSeconds() << "s");
                
                // Send migration request to candidate
                SendPacketWithPriority(newBrokerId, REPLICA_MIGRATION_REQUEST, 1, CRITICAL_PRIORITY);
            }
        } else if (m_useProactiveMigration) {
            // Check if a better broker is available
            double currentRssi = m_neighborTracker->GetRssi(SUBSCRIBER_NODE, m_currentBrokerId);
            
            if (currentRssi < RSSI_WARNING_THRESHOLD) {
                // Subscriber detects marginal connectivity, look for better broker
                uint32_t newBrokerId = SelectBestBrokerNode();
                
                if (newBrokerId != m_currentBrokerId && 
                    newBrokerId != SUBSCRIBER_NODE && 
                    m_neighborTracker->GetRssi(SUBSCRIBER_NODE, newBrokerId) > currentRssi + 0.2) {
                    
                    NS_LOG_INFO("Subscriber proactively requesting " << newBrokerId 
                              << " to become new broker (better RSSI)");
                    
                    SendPacketWithPriority(newBrokerId, REPLICA_MIGRATION_REQUEST, 1, HIGH_PRIORITY);
                }
            }
        }
    }

    // Schedule next migration check
    Simulator::Schedule(Seconds(migrationCheckInterval), &MANETApplication::PeriodicMigrationCheck, this);
}

// Helper function to get node by ID
Ptr<Node> GetNode(uint32_t id)
{
    NS_ASSERT(id < NodeList::GetNNodes());
    return NodeList::GetNode(id);
}

// Main function
int main(int argc, char *argv[])
{
    // Enable logging
    LogComponentEnable("MANETDynamicReplicaMigration", LOG_LEVEL_INFO);

    // Create command line arguments
    CommandLine cmd;

    // Add adjustable parameters
    double alpha = ALPHA;
    double beta = BETA;
    double gamma = GAMMA;
    double delta = DELTA;
    double epsilon = EPSILON;
    double simTime = SIMULATION_TIME;
    double subscriberSpeed = MOBILITY_SPEED;
    bool useMsgNotReachedTrigger = true;     // Default: use message non-delivery trigger
    bool useProactiveMigration = true;       // Default: use proactive migration
    bool useMultipath = true;                // Default: use multipath routing
    bool useBuffering = true;                // Default: use message buffering
    double ackTimeoutSeconds = 0.5;          // Default: 0.5 second ACK timeout (faster)
    bool disableForceAtTime100 = false;      // 新增: 是否禁用100秒的强制迁移

    cmd.AddValue("alpha", "Weight for stability factor (S)", alpha);
    cmd.AddValue("beta", "Weight for request intensity factor (I)", beta);
    cmd.AddValue("gamma", "Weight for load factor (L)", gamma);
    cmd.AddValue("delta", "Weight for proximity factor (P)", delta);
    cmd.AddValue("epsilon", "Weight for delay factor (D)", epsilon);
    cmd.AddValue("simTime", "Total simulation time in seconds", simTime);
    cmd.AddValue("speed", "Subscriber mobility speed in m/s", subscriberSpeed);
    cmd.AddValue("useMsgTrigger", "Use message non-delivery trigger (0/1)", useMsgNotReachedTrigger);
    cmd.AddValue("useProactive", "Use proactive migration (0/1)", useProactiveMigration);
    cmd.AddValue("useMultipath", "Use multipath routing (0/1)", useMultipath);
    cmd.AddValue("useBuffering", "Use message buffering (0/1)", useBuffering);
    cmd.AddValue("ackTimeout", "ACK timeout in seconds", ackTimeoutSeconds);
    cmd.AddValue("disableForce", "Disable forced migration at 100s (0/1)", disableForceAtTime100); // 新增

    cmd.Parse(argc, argv);

    // Update global speed variable
    MOBILITY_SPEED = subscriberSpeed;

    NS_LOG_INFO("Starting Enhanced MANET Dynamic Replica Migration Simulation");
    NS_LOG_INFO("Parameters: alpha=" << alpha << ", beta=" << beta << ", gamma=" << gamma 
            << ", delta=" << delta << ", epsilon=" << epsilon
            << ", speed=" << subscriberSpeed << "m/s, simTime=" << simTime << "s");
    NS_LOG_INFO("Features: Message trigger=" << (useMsgNotReachedTrigger ? "ON" : "OFF")
            << ", Proactive migration=" << (useProactiveMigration ? "ON" : "OFF")
            << ", Multipath routing=" << (useMultipath ? "ON" : "OFF")
            << ", Message buffering=" << (useBuffering ? "ON" : "OFF")
            << ", ACK timeout=" << ackTimeoutSeconds << "s"
            << ", Force disable=" << (disableForceAtTime100 ? "YES" : "NO"));

    // Set random seed for reproducibility
    RngSeedManager::SetSeed(12345);

    // Create nodes
    NodeContainer nodes;
    nodes.Create(TOTAL_NODES);

    // Configure WiFi
    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211g);

    // Configure physical layer
    YansWifiPhyHelper wifiPhy;
    YansWifiChannelHelper wifiChannel;

    // Use simple range-based propagation model
    wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    wifiChannel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                "MaxRange", DoubleValue(COMMUNICATION_RANGE));

    wifiPhy.SetChannel(wifiChannel.Create());

    // Configure WiFi parameters
    wifiPhy.Set("TxPowerStart", DoubleValue(16.0));
    wifiPhy.Set("TxPowerEnd", DoubleValue(16.0));
    wifiPhy.Set("TxPowerLevels", UintegerValue(1));
    wifiPhy.Set("TxGain", DoubleValue(1.0));
    wifiPhy.Set("RxGain", DoubleValue(1.0));

    WifiMacHelper wifiMac;
    wifiMac.SetType("ns3::AdhocWifiMac");

    NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, nodes);

    // Set up internet stack with AODV routing
    InternetStackHelper internet;
    AodvHelper aodv;
    internet.SetRoutingHelper(aodv);
    internet.Install(nodes);

    // Assign IP addresses
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

    // Set up mobility model for subscriber with waypoints
    MobilityHelper subscriberMobilityHelper;
    subscriberMobilityHelper.SetMobilityModel("ns3::WaypointMobilityModel");

    // Create initial position for subscriber
    Ptr<ListPositionAllocator> subscriberPositionAlloc = CreateObject<ListPositionAllocator>();
    Vector subscriberPos(550.0, 500.0, 0.0);
    subscriberPositionAlloc->Add(subscriberPos);
    subscriberMobilityHelper.SetPositionAllocator(subscriberPositionAlloc);

    // Install waypoint model for subscriber
    subscriberMobilityHelper.Install(nodes.Get(SUBSCRIBER_NODE));

    // Set up constant position mobility for other nodes
    Ptr<RandomRectanglePositionAllocator> positionAlloc = CreateObject<RandomRectanglePositionAllocator>();
    positionAlloc->SetAttribute("X", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));
    positionAlloc->SetAttribute("Y", StringValue("ns3::UniformRandomVariable[Min=0.0|Max=1000.0]"));

    MobilityHelper mobility;
    mobility.SetPositionAllocator(positionAlloc);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");

    // Create a container for non-subscriber nodes
    NodeContainer otherNodes;
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i != SUBSCRIBER_NODE) {
            otherNodes.Add(nodes.Get(i));
        }
    }

    // Install mobility model for non-subscriber nodes
    mobility.Install(otherNodes);

    // Get the waypoint mobility model for subscriber
    Ptr<WaypointMobilityModel> waypointMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<WaypointMobilityModel>();
    if (!waypointMobility) {
        NS_FATAL_ERROR("Failed to get WaypointMobilityModel for subscriber");
    }

    // Define waypoints for subscriber path
    std::vector<Vector> waypoints = {
        Vector(700.0, 500.0, 0.0),  // waypoint 1
        Vector(950.0, 500.0, 0.0),  // waypoint 2
        Vector(950.0, 950.0, 0.0),  // waypoint 3
        Vector(950.0, 950.0, 0.0),  // waypoint 4 (stationary point)
        Vector(900.0, 900.0, 0.0),  // waypoint 5
        Vector(600.0, 600.0, 0.0),  // waypoint 6
        Vector(550.0, 500.0, 0.0),  // waypoint 7
    };

    // Calculate times for each waypoint based on speed
    double currentTime = 0.0;
    Vector currentPos = subscriberPos;

    for (const auto& waypoint : waypoints) {
        // Calculate distance
        double distance = CalculateVectorDistance(currentPos, waypoint);
        
        // Calculate arrival time (time = distance/speed)
        double arrivalTime;
        
        // For waypoint 4 (stationary point), use fixed stay time
        if (currentPos == Vector(950.0, 950.0, 0.0) && waypoint == Vector(950.0, 950.0, 0.0)) {
            arrivalTime = currentTime + 60.0;  // Stay for 60 seconds
        } else {
            // Normal movement time calculation
            arrivalTime = currentTime + (distance / subscriberSpeed);
        }
        
        // Add waypoint
        waypointMobility->AddWaypoint(Waypoint(Seconds(arrivalTime), waypoint));
        
        NS_LOG_INFO("Added waypoint: time=" << arrivalTime << "s, position=(" 
                   << waypoint.x << "," << waypoint.y << "), distance=" 
                   << distance << "m, speed=" << subscriberSpeed << "m/s");
        
        // Update current position and time
        currentPos = waypoint;
        currentTime = arrivalTime;
    }

    // Special positions for publisher and broker
    Ptr<MobilityModel> publisherMobility = nodes.Get(PUBLISHER_NODE)->GetObject<MobilityModel>();
    Ptr<MobilityModel> brokerMobility = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
    Ptr<MobilityModel> subscriberMobility = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();

    if (!publisherMobility || !brokerMobility || !subscriberMobility) {
        NS_FATAL_ERROR("Failed to get mobility models");
    }

    // Place broker at position (500, 500)
    Vector brokerPos(500.0, 500.0, 0.0);
    brokerMobility->SetPosition(brokerPos);

    // Place publisher where it can directly communicate with broker
    Vector publisherPos(450.0, 500.0, 0.0);
    publisherMobility->SetPosition(publisherPos);

    NS_LOG_INFO("Broker initial position: (" << brokerPos.x << ", " << brokerPos.y << ")");
    NS_LOG_INFO("Subscriber initial position: (" << subscriberMobility->GetPosition().x 
            << ", " << subscriberMobility->GetPosition().y << ")");
    NS_LOG_INFO("Initial distance between Broker and Subscriber: " 
            << subscriberMobility->GetDistanceFrom(brokerMobility) << "m");

    // Verify initial distance is within communication range
    NS_ASSERT(subscriberMobility->GetDistanceFrom(brokerMobility) <= COMMUNICATION_RANGE);

    NS_LOG_INFO("Publisher initial position: (" << publisherPos.x << ", " << publisherPos.y << ")");
    NS_LOG_INFO("Distance between Publisher and Broker: " 
            << publisherMobility->GetDistanceFrom(brokerMobility) << "m");

    // Create tracking components
    Ptr<NeighborTracker> neighborTracker = CreateObject<NeighborTracker>();
    Ptr<RequestTracker> requestTracker = CreateObject<RequestTracker>();
    Ptr<LoadTracker> loadTracker = CreateObject<LoadTracker>();
    Ptr<ConnectivityManager> connectivityManager = CreateObject<ConnectivityManager>();

    // Set up devices for connectivity manager
    connectivityManager->SetDevices(devices);

    // Store mobility models for connectivity updates
    Ptr<MobilityModel> mobilityModels[TOTAL_NODES];
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        mobilityModels[i] = nodes.Get(i)->GetObject<MobilityModel>();
        if (!mobilityModels[i]) {
            NS_FATAL_ERROR("Failed to get mobility model for node " << i);
        }
    }

    // Function to update connectivity periodically
    auto updateConnectivity = [&]() {
        connectivityManager->UpdateReachability(mobilityModels);
    };

    // Schedule frequent connectivity updates
    for (double t = 0.0; t <= simTime; t += CONNECTIVITY_UPDATE_INTERVAL) {
        Simulator::Schedule(Seconds(t), updateConnectivity);
    }

    // Log subscriber position if debug enabled
    if (DEBUG_MOBILITY) {
        auto logSubscriberPosition = [&]() {
            Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
            Ptr<MobilityModel> brokerMob = nodes.Get(INITIAL_BROKER_NODE)->GetObject<MobilityModel>();
            
            if (subscriberMob && brokerMob) {
                Vector position = subscriberMob->GetPosition();
                double distance = subscriberMob->GetDistanceFrom(brokerMob);
                
                NS_LOG_INFO("Subscriber position at " << Simulator::Now().GetSeconds() 
                          << "s: (" << position.x << ", " << position.y 
                          << "), distance to broker: " << distance << "m");
            }
        };
        
        // Log subscriber position every 5 seconds
        for (double t = 0.0; t <= simTime; t += 5.0) {
            Simulator::Schedule(Seconds(t), logSubscriberPosition);
        }
    }

    // Install applications on all nodes
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        Ptr<MANETApplication> app = CreateObject<MANETApplication>();
        if (!app) {
            NS_LOG_ERROR("Failed to create MANETApplication for node " << i);
            continue;
        }
        
        app->Setup(i, neighborTracker, requestTracker, loadTracker, connectivityManager);
        
        // Configure application features
        app->SetUseMsgNotReachedTrigger(useMsgNotReachedTrigger);
        app->SetUseProactiveMigration(useProactiveMigration);
        app->SetUseMultipath(useMultipath);
        app->SetUseBuffering(useBuffering);
        app->SetAckTimeout(Seconds(ackTimeoutSeconds));
        
        nodes.Get(i)->AddApplication(app);
        app->SetStartTime(Seconds(0.0));
        app->SetStopTime(Seconds(simTime));
    }

    // Force migration after 100 seconds if natural migration hasn't occurred - 除非用户明确禁用
    if (!disableForceAtTime100) {
        Simulator::Schedule(Seconds(100.0), [&]() {
            // First check if migration has already happened
            Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
            if (subApp && subApp->GetFirstMigrationTime().GetSeconds() > 0) {
                NS_LOG_UNCOND("*** Migration already occurred at " << subApp->GetFirstMigrationTime().GetSeconds() << "s, no forced migration needed ***");
                return;
            }
            
            NS_LOG_UNCOND("*** FORCING MIGRATION AT 100s ***");
            
            // Find a node close to subscriber
            Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
            if (!subscriberMob) {
                NS_LOG_ERROR("Cannot get subscriber mobility model");
                return;
            }
            
            // Choose a relay node near the subscriber to become the new broker
            double minDist = std::numeric_limits<double>::max();
            uint32_t newBrokerId = 3; // Default to node 3 if nothing else is found
            
            for (uint32_t i = 3; i < TOTAL_NODES; i++) {
                double dist = subscriberMob->GetDistanceFrom(mobilityModels[i]);
                if (dist < minDist && dist < COMMUNICATION_RANGE) {
                    minDist = dist;
                    newBrokerId = i;
                }
            }
            
            NS_LOG_UNCOND("Found node " << newBrokerId << " at distance " << minDist 
                    << "m from subscriber - forcing it to become broker");
            
            // Force this node to become the broker
            Ptr<MANETApplication> app = DynamicCast<MANETApplication>(nodes.Get(newBrokerId)->GetApplication(0));
            if (app) {
                app->AddLocalContent(1);
                app->SetHasMigratedContent(true);
                app->SetFirstMigrationTime(Simulator::Now());
                app->CompleteMigration(INITIAL_BROKER_NODE, newBrokerId);
                
                // Send data to subscriber
                if (app->IsReachable(newBrokerId, SUBSCRIBER_NODE)) {
                    app->SendPacketWithPriority(SUBSCRIBER_NODE, DATA_RESPONSE, 1, HIGH_PRIORITY);
                }
                
                // Set global migration tracking variables
                g_migrationOccurred = true;
                g_firstMigrationTime = Simulator::Now();
                
                // Update subscriber's migration time
                Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
                    nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
                if (subApp) {
                    subApp->SetFirstMigrationTime(Simulator::Now());
                    NS_LOG_INFO("Updated subscriber's migration time during forced migration: " 
                            << subApp->GetFirstMigrationTime().GetSeconds() << "s");
                }
                
                NS_LOG_UNCOND("FORCED MIGRATION: Node " << newBrokerId << " is now the broker");
            } else {
                NS_LOG_ERROR("Failed to get application for node " << newBrokerId);
            }
        });
    }

    // Periodic verification of migration status
    for (double t = 20.0; t <= simTime; t += 10.0) {
        Simulator::Schedule(Seconds(t), [&]() {
            // Check if migration has occurred and update subscriber's record if needed
            if (g_migrationOccurred) {
                Ptr<MANETApplication> subApp = DynamicCast<MANETApplication>(
                    nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
                if (subApp && subApp->GetFirstMigrationTime().GetSeconds() <= 0) {
                    subApp->SetFirstMigrationTime(g_firstMigrationTime);
                    NS_LOG_INFO("MIGRATION TRACKER: Updated subscriber's migration time at " 
                            << Simulator::Now().GetSeconds() << "s to " 
                            << g_firstMigrationTime.GetSeconds() << "s");
                }
            }
        });
    }

    // Schedule frequent logging of subscriber position and broker status
    for (double t = 5.0; t <= simTime; t += 5.0) {
        Simulator::Schedule(Seconds(t), [&]() {
            Ptr<MobilityModel> subscriberMob = nodes.Get(SUBSCRIBER_NODE)->GetObject<MobilityModel>();
            
            // Get current broker ID and its mobility model
            uint32_t currentBrokerId = INITIAL_BROKER_NODE;
            Ptr<MANETApplication> subscriberApp = DynamicCast<MANETApplication>(
                nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
            
            if (subscriberApp) {
                currentBrokerId = subscriberApp->GetCurrentBroker();
            }
            
            Ptr<MobilityModel> brokerMob = nodes.Get(currentBrokerId)->GetObject<MobilityModel>();
            
            if (subscriberMob && brokerMob) {
                Vector subPos = subscriberMob->GetPosition();
                Vector brkPos = brokerMob->GetPosition();
                double distance = subscriberMob->GetDistanceFrom(brokerMob);
                
                // Check connectivity
                bool subCanReachBroker = connectivityManager->IsReachable(SUBSCRIBER_NODE, currentBrokerId);
                bool brokerCanReachSub = connectivityManager->IsReachable(currentBrokerId, SUBSCRIBER_NODE);
                
                NS_LOG_UNCOND(Simulator::Now().GetSeconds() << "s: "
                           << "Sub(" << subPos.x << "," << subPos.y << ") "
                           << "Brk[" << currentBrokerId << "](" << brkPos.x << "," << brkPos.y << ") "
                           << "Dist=" << distance << "m "
                           << "Range=" << COMMUNICATION_RANGE << "m "
                           << "S→B=" << (subCanReachBroker ? "YES" : "NO") << " "
                           << "B→S=" << (brokerCanReachSub ? "YES" : "NO"));
            }
        });
    }

    // Set up animation
    AnimationInterface anim("manet_dynamic_replica_migration.xml");

    // Configure node appearance
    for (uint32_t i = 0; i < TOTAL_NODES; i++) {
        if (i == PUBLISHER_NODE) {
            anim.UpdateNodeDescription(i, "Publisher");
            anim.UpdateNodeColor(i, 255, 0, 0); // Red
            anim.UpdateNodeSize(i, 10, 10);     // Larger size
        } else if (i == INITIAL_BROKER_NODE) {
            anim.UpdateNodeDescription(i, "Broker");
            anim.UpdateNodeColor(i, 0, 255, 0); // Green
            anim.UpdateNodeSize(i, 10, 10);     // Larger size
        } else if (i == SUBSCRIBER_NODE) {
            anim.UpdateNodeDescription(i, "Subscriber");
            anim.UpdateNodeColor(i, 0, 0, 255); // Blue
            anim.UpdateNodeSize(i, 10, 10);     // Larger size
        } else {
            std::ostringstream desc;
            desc << "Relay Node " << i;
            anim.UpdateNodeDescription(i, desc.str());
            anim.UpdateNodeColor(i, 128, 128, 128); // Gray
        }
    }

    // Enable packet metadata for animation
    anim.EnablePacketMetadata(true);

    // Set up flow monitor
    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor = flowmon.InstallAll();

    // Run simulation
    NS_LOG_INFO("Running simulation for " << simTime << " seconds with subscriber speed = " << subscriberSpeed << " m/s");
    Simulator::Stop(Seconds(simTime));
    Simulator::Run();

    // Print results
    NS_LOG_INFO("Simulation completed.");

    // Get application from subscriber node to access statistics
    Ptr<MANETApplication> subscriberApp = nullptr;
    if (nodes.Get(SUBSCRIBER_NODE)) {
        subscriberApp = DynamicCast<MANETApplication>(nodes.Get(SUBSCRIBER_NODE)->GetApplication(0));
    }

    if (subscriberApp) {
        double avgDelay = subscriberApp->GetAverageDelay();
        double deliveryRate = subscriberApp->GetDeliveryRate();
        
        std::cout << "结果汇总:" << std::endl;
        std::cout << "  subscriber移动速度: " << subscriberSpeed << " m/s" << std::endl;
        std::cout << "  平均延迟: " << avgDelay * 1000.0 << " ms" << std::endl;
        std::cout << "  消息交付率: " << deliveryRate * 100.0 << "% (" 
                << subscriberApp->GetMessagesReceived() << "/" 
                << subscriberApp->GetMessagesSent() << ")" << std::endl;
        
        // Overall message statistics
        std::cout << "  全局消息统计: "
                << g_totalMessagesReceived << "/" << g_totalMessagesSent
                << " (" << (g_totalMessagesSent > 0 ? 
                        (double)g_totalMessagesReceived/g_totalMessagesSent*100.0 : 0.0)
                << "%)" << std::endl;
        
        // Check migration status from both subscriber app and global tracker
        Time firstMigration = subscriberApp->GetFirstMigrationTime();
        
        if (g_migrationOccurred) {
            std::cout << "  首次副本迁移时间: " << g_firstMigrationTime.GetSeconds() << " 秒 (全局跟踪)" << std::endl;
            if (firstMigration.GetSeconds() > 0) {
                std::cout << "  订阅者记录的首次迁移时间: " << firstMigration.GetSeconds() << " 秒" << std::endl;
            } else {
                std::cout << "  警告: 订阅者未记录迁移时间，但全局跟踪器已检测到迁移" << std::endl;
            }
        } else {
            std::cout << "  未发生副本迁移" << std::endl;
        }
        
        // Add to log file
        NS_LOG_INFO("最终结果(速度=" << subscriberSpeed << "m/s): 平均延迟 = " << avgDelay * 1000.0 << " ms, 消息交付率 = " 
                   << deliveryRate * 100.0 << "% (" 
                   << subscriberApp->GetMessagesReceived() << "/" 
                   << subscriberApp->GetMessagesSent() << ")");
        
        if (g_migrationOccurred) {
            NS_LOG_INFO("全局跟踪的首次副本迁移时间: " << g_firstMigrationTime.GetSeconds() << " 秒");
            if (firstMigration.GetSeconds() > 0) {
                NS_LOG_INFO("订阅者记录的首次副本迁移时间: " << firstMigration.GetSeconds() << " 秒");
            } else {
                NS_LOG_INFO("警告: 订阅者未记录迁移时间，但全局跟踪器已检测到迁移");
            }
        } else {
            NS_LOG_INFO("未发生副本迁移");
        }
    }

    // Print migration mechanism statistics
    std::cout << "迁移机制配置:" << std::endl;
    std::cout << "  触发机制: ";
    if (useMsgNotReachedTrigger) {
        std::cout << "消息未达触发" << std::endl;
        std::cout << "  确认超时: " << ackTimeoutSeconds << " 秒" << std::endl;
    } else {
        std::cout << "连接性触发" << std::endl;
    }

    std::cout << "  主动迁移: " << (useProactiveMigration ? "启用" : "禁用") << std::endl;
    std::cout << "  多路径路由: " << (useMultipath ? "启用" : "禁用") << std::endl;
    std::cout << "  消息缓存: " << (useBuffering ? "启用" : "禁用") << std::endl;
    std::cout << "  强制迁移: " << (disableForceAtTime100 ? "禁用" : "启用") << std::endl;

    // Flow monitor statistics
    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
    FlowMonitor::FlowStatsContainer stats = monitor->GetFlowStats();

    std::cout << "Flow monitor statistics:" << std::endl;

    for (auto i = stats.begin(); i != stats.end(); ++i) {
        Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
        std::cout << "Flow " << i->first << " (" << t.sourceAddress << " -> " 
                << t.destinationAddress << ")" << std::endl;
        std::cout << "  Tx Packets: " << i->second.txPackets << std::endl;
        std::cout << "  Rx Packets: " << i->second.rxPackets << std::endl;
        std::cout << "  Throughput: " << i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds() 
                                                                - i->second.timeFirstTxPacket.GetSeconds()) / 1024 
                << " Kbps" << std::endl;
    }

    // 关键修复：输出更详细的消息统计信息
    NS_LOG_UNCOND("=== 全局消息统计详情 ===");
    NS_LOG_UNCOND("  总发送消息: " << g_totalMessagesSent);
    NS_LOG_UNCOND("  总接收消息: " << g_totalMessagesReceived);
    NS_LOG_UNCOND("  全局交付率: " << (g_totalMessagesSent > 0 ? (double)g_totalMessagesReceived/g_totalMessagesSent*100.0 : 0.0) << "%");

    // Generate trace file for post-processing
    std::string outFileName = "enhanced_manet_results_speed_" + std::to_string(subscriberSpeed) + ".txt";
    std::ofstream outFile(outFileName);
    if (outFile.is_open()) {
        outFile << "# Enhanced MANET Dynamic Replica Migration Experiment Results" << std::endl;
        outFile << "# Simulation parameters:" << std::endl;
        outFile << "# - Total nodes: " << TOTAL_NODES << std::endl;
        outFile << "# - Simulation time: " << simTime << " seconds" << std::endl;
        outFile << "# - Simulation area: " << SIMULATION_AREA << " x " << SIMULATION_AREA << " meters" << std::endl;
        outFile << "# - Subscriber mobility speed: " << subscriberSpeed << " m/s" << std::endl;
        outFile << "# - Communication range: " << COMMUNICATION_RANGE << " meters" << std::endl;
        outFile << "# - Scoring formula weights: alpha=" << alpha << ", beta=" << beta 
               << ", gamma=" << gamma << ", delta=" << delta << ", epsilon=" << epsilon << std::endl;
        outFile << "# - Features: MsgTrigger=" << (useMsgNotReachedTrigger ? "ON" : "OFF")
               << ", Proactive=" << (useProactiveMigration ? "ON" : "OFF")
               << ", Multipath=" << (useMultipath ? "ON" : "OFF")
               << ", Buffering=" << (useBuffering ? "ON" : "OFF") << std::endl;
        outFile << "# - ACK timeout: " << ackTimeoutSeconds << " seconds" << std::endl;
        outFile << "# - Force migration at 100s: " << (disableForceAtTime100 ? "OFF" : "ON") << std::endl;
        outFile << std::endl;
        
        // Add detailed results
        if (subscriberApp) {
            outFile << "Average Delay (ms): " << subscriberApp->GetAverageDelay() * 1000.0 << std::endl;
            outFile << "Message Delivery Rate (%): " << subscriberApp->GetDeliveryRate() * 100.0 << std::endl;
            outFile << "Messages Sent: " << subscriberApp->GetMessagesSent() << std::endl;
            outFile << "Messages Received: " << subscriberApp->GetMessagesReceived() << std::endl;
            
            if (g_migrationOccurred) {
                outFile << "First Migration Time (s): " << g_firstMigrationTime.GetSeconds() << std::endl;
            } else {
                outFile << "No migration occurred" << std::endl;
            }
        }
        
        // 添加全局消息统计
        outFile << "\nGlobal Message Statistics:" << std::endl;
        outFile << "  Total Messages Sent: " << g_totalMessagesSent << std::endl;
        outFile << "  Total Messages Received: " << g_totalMessagesReceived << std::endl;
        outFile << "  Global Delivery Rate: " << (g_totalMessagesSent > 0 ? (double)g_totalMessagesReceived/g_totalMessagesSent*100.0 : 0.0) << "%" << std::endl;
        
        // Add flow monitor statistics
        outFile << "Flow statistics:" << std::endl;
        for (auto i = stats.begin(); i != stats.end(); ++i) {
            Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
            outFile << "Flow " << i->first << " (" << t.sourceAddress << " -> " 
                   << t.destinationAddress << ")" << std::endl;
            outFile << "  Tx Packets: " << i->second.txPackets << std::endl;
            outFile << "  Rx Packets: " << i->second.rxPackets << std::endl;
            
            // 防止除以零的情况
            double throughput = 0.0;
            if (i->second.timeLastRxPacket.GetSeconds() > i->second.timeFirstTxPacket.GetSeconds()) {
               throughput = i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds() 
                                                    - i->second.timeFirstTxPacket.GetSeconds()) / 1024;
            }
            outFile << "  Throughput (Kbps): " << throughput << std::endl;
        }
        
        outFile.close();
    }

    Simulator::Destroy();

    return 0;
}