// File: aodv-broker-migration.cc
// AODV-based broker migration notification implementation for NS-3.44
// This simulation corresponds to the comparison experiment described in the experiment design

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/internet-module.h"
#include "ns3/aodv-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/netanim-module.h"
#include "ns3/flow-monitor-module.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include <memory>
#include <cmath>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("AodvBrokerMigrationExperiment");

// Global parameters (mirroring NDN experiment)
uint32_t numNodes = 50;       // Total number of nodes
uint32_t gridSize = 7;        // Grid size
double simulationTime = 300.0; // Simulation time (seconds)
double nodeMobility = 3.0;    // Node mobility speed (m/s)
uint32_t packetSize = 1024;   // Data packet size (bytes)
bool enableDetailedLogging = true; // Enable detailed logging for debugging

// Define packet types for our application protocol
enum PacketType {
  CONTENT_REQUEST = 1,
  CONTENT_RESPONSE = 2,
  BROKER_MIGRATION_NOTIFICATION = 3
};

// Header for our application-level protocol
class BrokerAppHeader : public Header 
{
public:
  BrokerAppHeader();
  virtual ~BrokerAppHeader();

  // Content identifier
  void SetContentId(uint32_t contentId);
  uint32_t GetContentId() const;

  // Packet type
  void SetPacketType(uint8_t type);
  uint8_t GetPacketType() const;

  // Sequence number for packet identification
  void SetSequenceNumber(uint32_t seqNum);
  uint32_t GetSequenceNumber() const;

  // Broker information
  void SetBrokerId(uint32_t id);
  uint32_t GetBrokerId() const;
  
  // Migration timestamp (for notification delay calculation)
  void SetMigrationTimestamp(Time time);
  Time GetMigrationTimestamp() const;
  
  // Notification type (unicast, route-based, or broadcast)
  void SetNotificationType(uint8_t type);
  uint8_t GetNotificationType() const;

  // Header interface methods
  static TypeId GetTypeId();
  virtual TypeId GetInstanceTypeId() const;
  virtual void Print(std::ostream &os) const;
  virtual void Serialize(Buffer::Iterator start) const;
  virtual uint32_t Deserialize(Buffer::Iterator start);
  virtual uint32_t GetSerializedSize() const;

private:
  uint32_t m_contentId;
  uint8_t m_packetType;
  uint32_t m_seqNum;
  uint32_t m_brokerId;
  uint64_t m_migrationTimestamp; // Stored as nanoseconds
  uint8_t m_notificationType;
};

// Types of notification
enum NotificationType {
  UNICAST_NOTIFICATION = 1,
  AODV_ROUTE_NOTIFICATION = 2,
  BROADCAST_NOTIFICATION = 3
};

// Implementation of BrokerAppHeader methods
BrokerAppHeader::BrokerAppHeader() :
  m_contentId(0),
  m_packetType(CONTENT_REQUEST),
  m_seqNum(0),
  m_brokerId(0),
  m_migrationTimestamp(0),
  m_notificationType(UNICAST_NOTIFICATION)
{
}

BrokerAppHeader::~BrokerAppHeader()
{
}

TypeId
BrokerAppHeader::GetTypeId()
{
  static TypeId tid = TypeId("ns3::BrokerAppHeader")
    .SetParent<Header>()
    .AddConstructor<BrokerAppHeader>();
  return tid;
}

TypeId
BrokerAppHeader::GetInstanceTypeId() const
{
  return GetTypeId();
}

void
BrokerAppHeader::Print(std::ostream &os) const
{
  os << "ContentId=" << m_contentId;
  os << ", Type=" << (uint32_t)m_packetType;
  os << ", SeqNum=" << m_seqNum;
  os << ", BrokerId=" << m_brokerId;
  
  if (m_packetType == BROKER_MIGRATION_NOTIFICATION)
  {
    os << ", MigrationTimestamp=" << Time(NanoSeconds(m_migrationTimestamp)).GetSeconds() << "s";
    os << ", NotificationType=" << (uint32_t)m_notificationType;
  }
}

uint32_t
BrokerAppHeader::GetSerializedSize() const
{
  return sizeof(uint32_t) + sizeof(uint8_t) + sizeof(uint32_t) + 
         sizeof(uint32_t) + sizeof(uint64_t) + sizeof(uint8_t);
}

void
BrokerAppHeader::Serialize(Buffer::Iterator start) const
{
  start.WriteHtonU32(m_contentId);
  start.WriteU8(m_packetType);
  start.WriteHtonU32(m_seqNum);
  start.WriteHtonU32(m_brokerId);
  start.WriteHtonU64(m_migrationTimestamp);
  start.WriteU8(m_notificationType);
}

uint32_t
BrokerAppHeader::Deserialize(Buffer::Iterator start)
{
  m_contentId = start.ReadNtohU32();
  m_packetType = start.ReadU8();
  m_seqNum = start.ReadNtohU32();
  m_brokerId = start.ReadNtohU32();
  m_migrationTimestamp = start.ReadNtohU64();
  m_notificationType = start.ReadU8();
  
  return GetSerializedSize();
}

void
BrokerAppHeader::SetContentId(uint32_t contentId)
{
  m_contentId = contentId;
}

uint32_t
BrokerAppHeader::GetContentId() const
{
  return m_contentId;
}

void
BrokerAppHeader::SetPacketType(uint8_t type)
{
  m_packetType = type;
}

uint8_t
BrokerAppHeader::GetPacketType() const
{
  return m_packetType;
}

void
BrokerAppHeader::SetSequenceNumber(uint32_t seqNum)
{
  m_seqNum = seqNum;
}

uint32_t
BrokerAppHeader::GetSequenceNumber() const
{
  return m_seqNum;
}

void
BrokerAppHeader::SetBrokerId(uint32_t id)
{
  m_brokerId = id;
}

uint32_t
BrokerAppHeader::GetBrokerId() const
{
  return m_brokerId;
}

void
BrokerAppHeader::SetMigrationTimestamp(Time time)
{
  m_migrationTimestamp = time.GetNanoSeconds();
}

Time
BrokerAppHeader::GetMigrationTimestamp() const
{
  return NanoSeconds(m_migrationTimestamp);
}

void
BrokerAppHeader::SetNotificationType(uint8_t type)
{
  m_notificationType = type;
}

uint8_t
BrokerAppHeader::GetNotificationType() const
{
  return m_notificationType;
}

// Broker Application class
class BrokerApp : public Application
{
public:
  static TypeId GetTypeId();
  BrokerApp();
  virtual ~BrokerApp();

  // Node roles (like in NDN experiment)
  enum NodeRole { PUBLISHER, SUBSCRIBER, BROKER, REGULAR };
  void SetNodeRole(NodeRole role);
  NodeRole GetNodeRole() const;

  // Set/Get current broker ID
  void SetCurrentBrokerId(uint32_t id);
  uint32_t GetCurrentBrokerId() const;

  // Start publisher and subscriber
  void StartPublishing();
  void StartSubscribing();

  // Broker migration
  void MigrateBroker(uint32_t newBrokerId);
  void TriggerBrokerMigration(uint32_t newBrokerId);

  // Record notification metrics
  void RecordNotificationDelay(Time delay, NotificationType type);
  void RecordMessageSuccess(bool success);

  // Static methods to get statistics
  static Time GetAverageNotificationDelay();
  static Time GetNotificationDelayByType(uint8_t type);
  static double GetMessageSuccessRate();
  static uint32_t GetMessagesSent();
  static uint32_t GetMessagesReceived();

protected:
  virtual void DoDispose();

private:
  virtual void StartApplication();
  virtual void StopApplication();

  // Initialize socket and routing
  void CreateSocket();
  void InitializeRouting();
  
  // Content methods
  void RequestContent();
  void ScheduleNextRequest();
  void GenerateContent(uint32_t contentId, Ptr<Packet>& packet);

  // Packet sending methods
  void SendContentRequest(uint32_t contentId);
  void SendContentResponse(uint32_t contentId, Ipv4Address destination);
  
  // Migration notification methods
  void SendBrokerNotification(uint32_t newBrokerId);
  void SendUnicastNotification(uint32_t newBrokerId, Ipv4Address destination);
  void SendRouteNotification(uint32_t newBrokerId, Ipv4Address destination);
  void SendBroadcastNotification(uint32_t newBrokerId);
  
  // Packet handling
  void ReceivePacket(Ptr<Socket> socket);
  void HandleContentRequest(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header);
  void HandleContentResponse(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header);
  void HandleBrokerNotification(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header);

  // Utility methods
  Ipv4Address GetNodeAddress(uint32_t nodeId);
  Ipv4Address FindPublisherAddress();
  Ipv4Address FindSubscriberAddress();
  bool NodeIsWithinRange(Ptr<Node> node1, Ptr<Node> node2);
  double CalculateDistance(Vector a, Vector b);
  void LogNotificationEvent(const std::string& event, Time timestamp = Simulator::Now());

  // Member variables
  NodeRole m_nodeRole;
  uint32_t m_currentBrokerId;
  uint32_t m_lastKnownBrokerId;
  uint32_t m_requestSequence;
  Ptr<Socket> m_socket;
  EventId m_requestEvent;
  Time m_migrationStartTime;
  bool m_hasMigrated;
  NotificationType m_lastNotificationType;
  
  // Content cache (for broker)
  std::map<uint32_t, Ptr<Packet>> m_contentStore;
  
  // Random number generator
  Ptr<UniformRandomVariable> m_rand;
  
  // Static metrics
  static Time s_totalNotificationDelay;
  static uint32_t s_notificationCount;
  static uint32_t s_messagesSent;
  static uint32_t s_messagesReceived;
  
  // Metrics by notification type
  static Time s_unicastNotificationDelay;
  static uint32_t s_unicastNotificationCount;
  static Time s_routeNotificationDelay;
  static uint32_t s_routeNotificationCount;
  static Time s_broadcastNotificationDelay;
  static uint32_t s_broadcastNotificationCount;
  
  // Track processed notification messages to avoid duplicates
  std::set<uint32_t> m_processedNotifications;
};

// Initialize static members
Time BrokerApp::s_totalNotificationDelay = Time(0);
uint32_t BrokerApp::s_notificationCount = 0;
uint32_t BrokerApp::s_messagesSent = 0;
uint32_t BrokerApp::s_messagesReceived = 0;

Time BrokerApp::s_unicastNotificationDelay = Time(0);
uint32_t BrokerApp::s_unicastNotificationCount = 0;
Time BrokerApp::s_routeNotificationDelay = Time(0);
uint32_t BrokerApp::s_routeNotificationCount = 0;
Time BrokerApp::s_broadcastNotificationDelay = Time(0);
uint32_t BrokerApp::s_broadcastNotificationCount = 0;

TypeId
BrokerApp::GetTypeId()
{
  static TypeId tid = TypeId("ns3::BrokerApp")
    .SetParent<Application>()
    .AddConstructor<BrokerApp>();
  return tid;
}

BrokerApp::BrokerApp() :
  m_nodeRole(REGULAR),
  m_currentBrokerId(0),
  m_lastKnownBrokerId(0),
  m_requestSequence(0),
  m_socket(nullptr),
  m_hasMigrated(false),
  m_lastNotificationType(UNICAST_NOTIFICATION)
{
  m_rand = CreateObject<UniformRandomVariable>();
}

BrokerApp::~BrokerApp()
{
}

void
BrokerApp::DoDispose()
{
  Application::DoDispose();
}

void
BrokerApp::StartApplication()
{
  NS_ASSERT(GetNode() != nullptr);
  
  // Create and initialize socket
  CreateSocket();
  
  // Initialize routing
  Simulator::Schedule(MilliSeconds(100), &BrokerApp::InitializeRouting, this);
  
  // Depending on node role, start appropriate behavior
  if (m_nodeRole == PUBLISHER)
  {
    NS_LOG_INFO("Starting publisher node " << GetNode()->GetId());
    Simulator::Schedule(MilliSeconds(200), &BrokerApp::StartPublishing, this);
  }
  else if (m_nodeRole == SUBSCRIBER)
  {
    NS_LOG_INFO("Starting subscriber node " << GetNode()->GetId());
    Simulator::Schedule(MilliSeconds(200), &BrokerApp::StartSubscribing, this);
  }
  else if (m_nodeRole == BROKER)
  {
    NS_LOG_INFO("Starting broker node " << GetNode()->GetId());
    m_currentBrokerId = GetNode()->GetId();
    
    // Initialize content store for broker
    for (uint32_t i = 1; i <= 100; i++)
    {
      Ptr<Packet> content = Create<Packet>(packetSize);
      m_contentStore[i] = content;
    }
    NS_LOG_INFO("Broker node " << GetNode()->GetId() << " initialized content store");
  }
}

void
BrokerApp::StopApplication()
{
  // Cancel any pending events
  if (m_requestEvent.IsRunning())
  {
    Simulator::Cancel(m_requestEvent);
  }
  
  // Close socket
  if (m_socket)
  {
    m_socket->Close();
    m_socket->SetRecvCallback(MakeNullCallback<void, Ptr<Socket>>());
  }
}

void
BrokerApp::CreateSocket()
{
  if (m_socket != nullptr)
    return;
    
  // Create UDP socket
  TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
  m_socket = Socket::CreateSocket(GetNode(), tid);
  
  // Bind to port 9 (same as in NDN implementation)
  InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), 9);
  
  int result = m_socket->Bind(local);
  if (result == -1)
  {
    NS_LOG_ERROR("Failed to bind socket on node " << GetNode()->GetId());
  }
  else
  {
    NS_LOG_INFO("Socket bound successfully on node " << GetNode()->GetId());
    m_socket->SetRecvCallback(MakeCallback(&BrokerApp::ReceivePacket, this));
    m_socket->SetAllowBroadcast(true);
  }
}

void
BrokerApp::InitializeRouting()
{
  // This function initializes the routing
  // For AODV, this is mostly handled by the AODV module itself
  
  // If this is publisher or subscriber, store broker information
  if (m_nodeRole == PUBLISHER || m_nodeRole == SUBSCRIBER)
  {
    // We don't need to explicitly initialize routes in AODV as it's reactive
    // Routes will be established when the first packet is sent
    NS_LOG_INFO("Node " << GetNode()->GetId() << " ready to use AODV routing");
  }
}

void
BrokerApp::SetNodeRole(NodeRole role)
{
  m_nodeRole = role;
}

BrokerApp::NodeRole
BrokerApp::GetNodeRole() const
{
  return m_nodeRole;
}

void
BrokerApp::SetCurrentBrokerId(uint32_t id)
{
  m_currentBrokerId = id;
}

uint32_t
BrokerApp::GetCurrentBrokerId() const
{
  return m_currentBrokerId;
}

void
BrokerApp::StartPublishing()
{
  NS_LOG_INFO("Publisher node " << GetNode()->GetId() << " is ready to serve content");
  // In our model, publisher passively waits for requests or broker notifications
}

void
BrokerApp::StartSubscribing()
{
  NS_LOG_INFO("Subscriber node " << GetNode()->GetId() << " starting content requests");
  // Schedule first content request after a small delay to ensure system stability
  ScheduleNextRequest();
}

void
BrokerApp::ScheduleNextRequest()
{
  // Send content requests every 1 second (as in NDN implementation)
  m_requestEvent = Simulator::Schedule(Seconds(1.0), &BrokerApp::RequestContent, this);
}

void
BrokerApp::RequestContent()
{
  NS_LOG_INFO("Node " << GetNode()->GetId() << " requesting content at time " << Simulator::Now().GetSeconds());
  
  // Request content with ID based on sequence number (modulo 100, starting from 1)
  uint32_t contentId = (m_requestSequence % 100) + 1;
  SendContentRequest(contentId);
  
  // Increment sequence number for next request
  m_requestSequence++;
  
  // Record message request
  s_messagesSent++;
  
  // Schedule next request
  ScheduleNextRequest();
}

void
BrokerApp::SendContentRequest(uint32_t contentId)
{
  // Create packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetContentId(contentId);
  header.SetPacketType(CONTENT_REQUEST);
  header.SetSequenceNumber(m_requestSequence);
  
  packet->AddHeader(header);
  
  // Determine destination address (current broker)
  Ipv4Address destination;
  
  if (m_currentBrokerId != 0)
  {
    destination = GetNodeAddress(m_currentBrokerId);
  }
  else
  {
    // If broker is unknown, broadcast request
    destination = Ipv4Address("255.255.255.255");
  }
  
  if (destination == Ipv4Address::GetZero())
  {
    NS_LOG_WARN("Unknown broker address, broadcasting content request");
    destination = Ipv4Address("255.255.255.255");
  }
  
  // Send packet
  InetSocketAddress destSocket = InetSocketAddress(destination, 9);
  m_socket->SendTo(packet, 0, destSocket);
  
  NS_LOG_INFO("Node " << GetNode()->GetId() << " sent content request for ID " 
             << contentId << " to " << destination);
}

void
BrokerApp::SendContentResponse(uint32_t contentId, Ipv4Address destination)
{
  // Generate content if we're broker or publisher
  Ptr<Packet> contentPacket;
  
  if (m_nodeRole == BROKER)
  {
    // Get content from store
    auto it = m_contentStore.find(contentId);
    if (it != m_contentStore.end())
    {
      contentPacket = it->second->Copy();
    }
    else
    {
      // Generate content if not in store
      GenerateContent(contentId, contentPacket);
      m_contentStore[contentId] = contentPacket->Copy();
    }
  }
  else if (m_nodeRole == PUBLISHER)
  {
    // Generate content
    GenerateContent(contentId, contentPacket);
  }
  else
  {
    NS_LOG_WARN("Non-publisher, non-broker attempted to send content response");
    return;
  }
  
  // Add header
  BrokerAppHeader header;
  header.SetContentId(contentId);
  header.SetPacketType(CONTENT_RESPONSE);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX)); // Random sequence for response
  
  contentPacket->AddHeader(header);
  
  // Send packet
  InetSocketAddress destSocket = InetSocketAddress(destination, 9);
  m_socket->SendTo(contentPacket, 0, destSocket);
  
  NS_LOG_INFO("Node " << GetNode()->GetId() << " sent content response for ID " 
             << contentId << " to " << destination);
}

void
BrokerApp::GenerateContent(uint32_t contentId, Ptr<Packet>& packet)
{
  // Create a packet with specified size
  packet = Create<Packet>(packetSize);
}

void
BrokerApp::MigrateBroker(uint32_t newBrokerId)
{
  NS_LOG_FUNCTION(this << newBrokerId);
  
  // Record migration start time
  m_migrationStartTime = Simulator::Now();
  NS_LOG_INFO("Broker migration started at " << m_migrationStartTime.GetSeconds() << "s");
  
  // Send broker migration notifications using the three mechanisms
  SendBrokerNotification(newBrokerId);
  
  // Update broker ID
  m_lastKnownBrokerId = m_currentBrokerId;
  m_currentBrokerId = newBrokerId;
  m_hasMigrated = true;
  
  // Configure new broker
  Ptr<Node> newBrokerNode = NodeList::GetNode(newBrokerId);
  if (newBrokerNode)
  {
    Ptr<BrokerApp> newBrokerApp = DynamicCast<BrokerApp>(newBrokerNode->GetApplication(0));
    if (newBrokerApp)
    {
      // Transfer role to new broker
      newBrokerApp->SetNodeRole(BROKER);
      newBrokerApp->SetCurrentBrokerId(newBrokerId);
      
      // Copy content store (in a real system, this would be more complex)
      for (const auto& content : m_contentStore)
      {
        newBrokerApp->m_contentStore[content.first] = content.second->Copy();
      }
      
      NS_LOG_INFO("Transferred broker role to node " << newBrokerId);
    }
  }
  
  // Change current node role to regular
  m_nodeRole = REGULAR;
  
  NS_LOG_INFO("Broker migrated from node " << m_lastKnownBrokerId << " to node " << m_currentBrokerId);
}

void
BrokerApp::TriggerBrokerMigration(uint32_t newBrokerId)
{
  // Only current broker can trigger migration
  if (m_nodeRole != BROKER)
  {
    NS_LOG_WARN("Non-broker node " << GetNode()->GetId() << " attempted to trigger migration");
    return;
  }
  
  NS_LOG_INFO("Manually triggering broker migration from node " << GetNode()->GetId() 
              << " to node " << newBrokerId << " at time " << Simulator::Now().GetSeconds());
  
  MigrateBroker(newBrokerId);
}

void
BrokerApp::SendBrokerNotification(uint32_t newBrokerId)
{
  NS_LOG_FUNCTION(this << newBrokerId);
  
  LogNotificationEvent("BrokerMigrationStarted");
  
  // 1. Unicast notification to publisher
  Ipv4Address publisherAddr = FindPublisherAddress();
  if (publisherAddr != Ipv4Address::GetZero())
  {
    SendUnicastNotification(newBrokerId, publisherAddr);
  }
  else
  {
    NS_LOG_WARN("Cannot find publisher address for unicast notification");
  }
  
  // 2. AODV route notification to subscriber
  Ipv4Address subscriberAddr = FindSubscriberAddress();
  if (subscriberAddr != Ipv4Address::GetZero())
  {
    SendRouteNotification(newBrokerId, subscriberAddr);
  }
  else
  {
    NS_LOG_WARN("Cannot find subscriber address for route notification");
  }
  
  // 3. Broadcast notification to all nodes (backup mechanism)
  SendBroadcastNotification(newBrokerId);
}

void
BrokerApp::SendUnicastNotification(uint32_t newBrokerId, Ipv4Address destination)
{
  // Create notification packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
  header.SetBrokerId(newBrokerId);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX));
  header.SetMigrationTimestamp(m_migrationStartTime);
  header.SetNotificationType(UNICAST_NOTIFICATION);
  
  packet->AddHeader(header);
  
  // Send packet directly to destination
  InetSocketAddress destSocket = InetSocketAddress(destination, 9);
  m_socket->SendTo(packet, 0, destSocket);
  
  m_lastNotificationType = UNICAST_NOTIFICATION;
  
  NS_LOG_INFO("Sent unicast broker notification to " << destination 
              << " with new broker ID " << newBrokerId);
              
  LogNotificationEvent("UnicastNotificationSent");
}

void
BrokerApp::SendRouteNotification(uint32_t newBrokerId, Ipv4Address destination)
{
  // Create notification packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
  header.SetBrokerId(newBrokerId);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX));
  header.SetMigrationTimestamp(m_migrationStartTime);
  header.SetNotificationType(AODV_ROUTE_NOTIFICATION);
  
  packet->AddHeader(header);
  
  // Send packet to destination (AODV will handle route discovery)
  InetSocketAddress destSocket = InetSocketAddress(destination, 9);
  m_socket->SendTo(packet, 0, destSocket);
  
  m_lastNotificationType = AODV_ROUTE_NOTIFICATION;
  
  NS_LOG_INFO("Sent AODV route notification to " << destination 
              << " with new broker ID " << newBrokerId);
              
  LogNotificationEvent("RouteNotificationSent");
}

void
BrokerApp::SendBroadcastNotification(uint32_t newBrokerId)
{
  // Create notification packet
  Ptr<Packet> packet = Create<Packet>();
  
  // Create and add header
  BrokerAppHeader header;
  header.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
  header.SetBrokerId(newBrokerId);
  header.SetSequenceNumber(m_rand->GetInteger(1, UINT32_MAX));
  header.SetMigrationTimestamp(m_migrationStartTime);
  header.SetNotificationType(BROADCAST_NOTIFICATION);
  
  packet->AddHeader(header);
  
  // Broadcast packet
  Ipv4Address bcastAddr = Ipv4Address("255.255.255.255");
  InetSocketAddress destSocket = InetSocketAddress(bcastAddr, 9);
  m_socket->SendTo(packet, 0, destSocket);
  
  m_lastNotificationType = BROADCAST_NOTIFICATION;
  
  NS_LOG_INFO("Broadcast broker notification with new broker ID " << newBrokerId);
  
  LogNotificationEvent("BroadcastNotificationSent");
}

void
BrokerApp::ReceivePacket(Ptr<Socket> socket)
{
  Address senderAddr;
  Ptr<Packet> packet;
  
  while ((packet = socket->RecvFrom(senderAddr)))
  {
    Ipv4Address sender = InetSocketAddress::ConvertFrom(senderAddr).GetIpv4();
    
    // Parse header
    BrokerAppHeader header;
    packet->RemoveHeader(header);
    
    uint32_t packetSize = packet->GetSize();
    
    if (enableDetailedLogging)
    {
      NS_LOG_INFO("Node " << GetNode()->GetId() << " received packet: type=" << 
                 (int)header.GetPacketType() << ", size=" << packetSize << 
                 ", from=" << sender);
    }
    
    // Handle packet based on type
    switch (header.GetPacketType())
    {
      case CONTENT_REQUEST:
        HandleContentRequest(packet, sender, header);
        break;
      case CONTENT_RESPONSE:
        HandleContentResponse(packet, sender, header);
        break;
      case BROKER_MIGRATION_NOTIFICATION:
        HandleBrokerNotification(packet, sender, header);
        break;
      default:
        NS_LOG_WARN("Unknown packet type received: " << (int)header.GetPacketType());
        break;
    }
  }
}

void
BrokerApp::HandleContentRequest(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header)
{
  uint32_t contentId = header.GetContentId();
  NS_LOG_INFO("Node " << GetNode()->GetId() << " handling content request for ID " 
             << contentId << " from " << sender);
  
  // Only broker or publisher should respond to content requests
  if (m_nodeRole == BROKER)
  {
    // Broker checks its content store and responds
    if (m_contentStore.find(contentId) != m_contentStore.end())
    {
      SendContentResponse(contentId, sender);
    }
    else
    {
      NS_LOG_WARN("Broker doesn't have requested content ID " << contentId);
      
      // In a real implementation, the broker would fetch from publisher
      Ptr<Packet> content;
      GenerateContent(contentId, content);
      m_contentStore[contentId] = content;
      
      SendContentResponse(contentId, sender);
    }
  }
  else if (m_nodeRole == PUBLISHER)
  {
    // Publisher generates and sends content
    SendContentResponse(contentId, sender);
  }
  // Regular nodes ignore content requests
}

void
BrokerApp::HandleContentResponse(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header)
{
  uint32_t contentId = header.GetContentId();
  NS_LOG_INFO("Node " << GetNode()->GetId() << " received content response for ID " 
             << contentId << " from " << sender);
  
  // If this node is the subscriber, record message success
  if (m_nodeRole == SUBSCRIBER)
  {
    s_messagesReceived++;
    RecordMessageSuccess(true);
    
    NS_LOG_INFO("Subscriber received content: " << contentId << 
               ", total received: " << s_messagesReceived);
  }
  
  // If this is a broker, store the content
  if (m_nodeRole == BROKER && packet->GetSize() > 0)
  {
    m_contentStore[contentId] = packet->Copy();
  }
}

void
BrokerApp::HandleBrokerNotification(Ptr<Packet> packet, Ipv4Address sender, BrokerAppHeader& header)
{
  uint32_t newBrokerId = header.GetBrokerId();
  Time migrationTime = header.GetMigrationTimestamp();
  NotificationType notificationType = (NotificationType)header.GetNotificationType();
  
  // Skip if we've already processed this notification
  uint32_t seqNum = header.GetSequenceNumber();
  if (m_processedNotifications.find(seqNum) != m_processedNotifications.end())
  {
    NS_LOG_INFO("Ignoring duplicate broker notification (seq: " << seqNum << ")");
    return;
  }
  m_processedNotifications.insert(seqNum);
  
  NS_LOG_INFO("Node " << GetNode()->GetId() << " received broker notification, "
             << "new broker: " << newBrokerId << ", notification type: " << notificationType);
  
  // Update broker information
  m_lastKnownBrokerId = m_currentBrokerId;
  m_currentBrokerId = newBrokerId;
  m_lastNotificationType = notificationType;
  
  // If this is publisher or subscriber, record notification delay
  if (m_nodeRole == PUBLISHER || m_nodeRole == SUBSCRIBER)
  {
    Time notificationDelay = Simulator::Now() - migrationTime;
    RecordNotificationDelay(notificationDelay, notificationType);
    
    NS_LOG_INFO("Notification delay: " << notificationDelay.GetSeconds() << "s, "
               << "migration time: " << migrationTime.GetSeconds() << "s, "
               << "current time: " << Simulator::Now().GetSeconds() << "s");
               
    LogNotificationEvent("NotificationReceived");
    
    // Record notification type-specific event
    if (notificationType == UNICAST_NOTIFICATION)
    {
      LogNotificationEvent("UnicastNotificationReceived");
    }
    else if (notificationType == AODV_ROUTE_NOTIFICATION)
    {
      LogNotificationEvent("RouteNotificationReceived");
    }
    else if (notificationType == BROADCAST_NOTIFICATION)
    {
      LogNotificationEvent("BroadcastNotificationReceived");
    }
  }
  
  // Forward notification to neighbors (if we haven't sent it already)
  // This mimics the behavior in the NDN implementation
  if (!m_hasMigrated && m_nodeRole != BROKER)
  {
    // Create new packet to forward
    Ptr<Packet> forwardPacket = Create<Packet>();
    
    BrokerAppHeader forwardHeader;
    forwardHeader.SetPacketType(BROKER_MIGRATION_NOTIFICATION);
    forwardHeader.SetBrokerId(newBrokerId);
    forwardHeader.SetSequenceNumber(seqNum); // Use same sequence to avoid duplicates
    forwardHeader.SetMigrationTimestamp(migrationTime);
    forwardHeader.SetNotificationType(notificationType);
    
    forwardPacket->AddHeader(forwardHeader);
    
    // Forward based on notification type
    if (notificationType == BROADCAST_NOTIFICATION)
    {
      // Broadcast to everyone
      Ipv4Address bcastAddr = Ipv4Address("255.255.255.255");
      InetSocketAddress destSocket = InetSocketAddress(bcastAddr, 9);
      m_socket->SendTo(forwardPacket, 0, destSocket);
      
      NS_LOG_INFO("Forwarded broadcast notification");
    }
    else
    {
      // For unicast and route notifications, only forward to immediate neighbors
      for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
      {
        if (i == GetNode()->GetId()) continue; // Skip self
        
        Ptr<Node> targetNode = NodeList::GetNode(i);
        if (NodeIsWithinRange(GetNode(), targetNode))
        {
          Ipv4Address targetAddress = GetNodeAddress(i);
          if (targetAddress != Ipv4Address::GetZero())
          {
            InetSocketAddress destSocket = InetSocketAddress(targetAddress, 9);
            m_socket->SendTo(forwardPacket->Copy(), 0, destSocket);
            
            NS_LOG_INFO("Forwarded notification to neighbor " << i);
          }
        }
      }
    }
  }
}

void
BrokerApp::RecordNotificationDelay(Time delay, NotificationType type)
{
  // Exclude unreasonable values
  if (delay < Seconds(0) || delay > Seconds(300))
  {
    NS_LOG_WARN("Ignoring abnormal delay value: " << delay.GetSeconds() << "s");
    return;
  }
  
  // Update global stats
  s_totalNotificationDelay += delay;
  s_notificationCount++;
  
  // Update type-specific stats
  switch (type)
  {
    case UNICAST_NOTIFICATION:
      s_unicastNotificationDelay += delay;
      s_unicastNotificationCount++;
      NS_LOG_INFO("Recorded unicast notification delay: " << delay.GetSeconds() << "s");
      break;
      
    case AODV_ROUTE_NOTIFICATION:
      s_routeNotificationDelay += delay;
      s_routeNotificationCount++;
      NS_LOG_INFO("Recorded route notification delay: " << delay.GetSeconds() << "s");
      break;
      
    case BROADCAST_NOTIFICATION:
      s_broadcastNotificationDelay += delay;
      s_broadcastNotificationCount++;
      NS_LOG_INFO("Recorded broadcast notification delay: " << delay.GetSeconds() << "s");
      break;
      
    default:
      NS_LOG_WARN("Unknown notification type");
      break;
  }
}

void
BrokerApp::RecordMessageSuccess(bool success)
{
  if (success)
  {
    NS_LOG_INFO("Message received successfully, total: " << s_messagesReceived 
               << " / sent: " << s_messagesSent);
  }
}

Ipv4Address
BrokerApp::GetNodeAddress(uint32_t nodeId)
{
  if (nodeId >= NodeList::GetNNodes())
  {
    return Ipv4Address::GetZero();
  }
  
  Ptr<Node> node = NodeList::GetNode(nodeId);
  if (!node)
  {
    return Ipv4Address::GetZero();
  }
  
  Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
  if (!ipv4 || ipv4->GetNInterfaces() <= 1)
  {
    return Ipv4Address::GetZero();
  }
  
  return ipv4->GetAddress(1, 0).GetLocal();
}

Ipv4Address
BrokerApp::FindPublisherAddress()
{
  for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
  {
    Ptr<Node> node = NodeList::GetNode(i);
    if (node && node->GetNApplications() > 0)
    {
      Ptr<BrokerApp> app = DynamicCast<BrokerApp>(node->GetApplication(0));
      if (app && app->GetNodeRole() == PUBLISHER)
      {
        return GetNodeAddress(i);
      }
    }
  }
  
  return Ipv4Address::GetZero();
}

Ipv4Address
BrokerApp::FindSubscriberAddress()
{
  for (uint32_t i = 0; i < NodeList::GetNNodes(); i++)
  {
    Ptr<Node> node = NodeList::GetNode(i);
    if (node && node->GetNApplications() > 0)
    {
      Ptr<BrokerApp> app = DynamicCast<BrokerApp>(node->GetApplication(0));
      if (app && app->GetNodeRole() == SUBSCRIBER)
      {
        return GetNodeAddress(i);
      }
    }
  }
  
  return Ipv4Address::GetZero();
}

bool
BrokerApp::NodeIsWithinRange(Ptr<Node> node1, Ptr<Node> node2)
{
  // Only check for direct wireless connectivity
  static const double transmissionRange = 250.0; // meters, from experiment setup
  
  // Get node positions
  Ptr<MobilityModel> mobility1 = node1->GetObject<MobilityModel>();
  Ptr<MobilityModel> mobility2 = node2->GetObject<MobilityModel>();
  
  if (!mobility1 || !mobility2)
  {
    return false;
  }
  
  Vector pos1 = mobility1->GetPosition();
  Vector pos2 = mobility2->GetPosition();
  
  double distance = CalculateDistance(pos1, pos2);
  
  return distance <= transmissionRange;
}

double
BrokerApp::CalculateDistance(Vector a, Vector b)
{
  // Calculate Euclidean distance
  double dx = a.x - b.x;
  double dy = a.y - b.y;
  double dz = a.z - b.z;
  
  return std::sqrt(dx*dx + dy*dy + dz*dz);
}

void
BrokerApp::LogNotificationEvent(const std::string& event, Time timestamp)
{
  std::ofstream eventLog;
  eventLog.open("aodv-notification-events.csv", std::ios::app);
  
  if (!eventLog.is_open())
  {
    NS_LOG_ERROR("Failed to open event log file");
    return;
  }
  
  // Write CSV format: time,nodeId,event,notificationType
  eventLog << timestamp.GetSeconds() << ","
           << GetNode()->GetId() << ","
           << event << ","
           << (int)m_lastNotificationType << std::endl;
  
  eventLog.close();
}

Time
BrokerApp::GetAverageNotificationDelay()
{
  if (s_notificationCount > 0)
  {
    return s_totalNotificationDelay / s_notificationCount;
  }
  return Time(0);
}

Time
BrokerApp::GetNotificationDelayByType(uint8_t type)
{
  switch (type)
  {
    case UNICAST_NOTIFICATION:
      if (s_unicastNotificationCount > 0)
      {
        return s_unicastNotificationDelay / s_unicastNotificationCount;
      }
      break;
    
    case AODV_ROUTE_NOTIFICATION:
      if (s_routeNotificationCount > 0)
      {
        return s_routeNotificationDelay / s_routeNotificationCount;
      }
      break;
    
    case BROADCAST_NOTIFICATION:
      if (s_broadcastNotificationCount > 0)
      {
        return s_broadcastNotificationDelay / s_broadcastNotificationCount;
      }
      break;
  }
  
  return Time(0);
}

double
BrokerApp::GetMessageSuccessRate()
{
  if (s_messagesSent > 0)
  {
    return (double)s_messagesReceived / s_messagesSent;
  }
  return 0.0;
}

uint32_t
BrokerApp::GetMessagesSent()
{
  return s_messagesSent;
}

uint32_t
BrokerApp::GetMessagesReceived()
{
  return s_messagesReceived;
}

int main(int argc, char *argv[])
{
  // Enable logging
  LogComponentEnable("AodvBrokerMigrationExperiment", LOG_LEVEL_INFO);
  LogComponentEnable("AodvRoutingProtocol", LOG_LEVEL_WARN); // Reduce AODV protocol noise
  
  // Parse command line arguments
  CommandLine cmd;
  cmd.AddValue("numNodes", "Number of nodes", numNodes);
  cmd.AddValue("simTime", "Simulation time in seconds", simulationTime);
  cmd.AddValue("mobility", "Node mobility speed in m/s", nodeMobility);
  cmd.AddValue("detailLog", "Enable detailed logging", enableDetailedLogging);
  cmd.Parse(argc, argv);
  
  // Create new event log file
  std::ofstream eventLog;
  eventLog.open("aodv-notification-events.csv", std::ios::trunc);
  eventLog << "time,nodeId,event,notificationType" << std::endl;
  eventLog.close();
  
  // Create nodes
  NodeContainer nodes;
  nodes.Create(numNodes);
  
  // Set up WiFi
  WifiHelper wifi;
  wifi.SetStandard(WIFI_STANDARD_80211b);
  
  YansWifiPhyHelper wifiPhy;
  YansWifiChannelHelper wifiChannel = YansWifiChannelHelper::Default();
  wifiPhy.SetChannel(wifiChannel.Create());
  
  // Enhanced transmission parameters
  wifiPhy.Set("TxPowerStart", DoubleValue(16.0));
  wifiPhy.Set("TxPowerEnd", DoubleValue(16.0));
  wifiPhy.Set("TxGain", DoubleValue(12.0));
  wifiPhy.Set("RxGain", DoubleValue(12.0));
  
  WifiMacHelper wifiMac;
  wifiMac.SetType("ns3::AdhocWifiMac");
  
  NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, nodes);
  
  // Set up mobility model
  MobilityHelper mobility;
  
  // Create grid positions for first 49 nodes
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator>();
  
  double spacing = 50.0; // meters
  for (uint32_t i = 0; i < 7; i++)
  {
    for (uint32_t j = 0; j < 7; j++)
    {
      if (i * 7 + j < 49)
      {
        positionAlloc->Add(Vector(i * spacing, j * spacing, 0.0));
      }
    }
  }
  
  // Position node 50 in the center
  double maxPos = 3 * spacing;
  positionAlloc->Add(Vector(maxPos, maxPos, 0.0));
  
  mobility.SetPositionAllocator(positionAlloc);
  
  // Random walk mobility model, as specified in the experiment design
  mobility.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
                           "Speed", StringValue("ns3::ConstantRandomVariable[Constant=" + 
                                               std::to_string(nodeMobility) + "]"),
                           "Bounds", RectangleValue(Rectangle(0.0, 7*spacing, 0.0, 7*spacing)));
  
  mobility.Install(nodes);
  
  // Install internet stack with AODV routing
  InternetStackHelper internet;
  AodvHelper aodv;
  internet.SetRoutingHelper(aodv);
  internet.Install(nodes);
  
  // Assign IP addresses
  Ipv4AddressHelper ipv4;
  ipv4.SetBase("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);
  
  // Define node roles (same positions as in NDN implementation)
  uint32_t publisherId = 0;    // Grid top-left
  uint32_t subscriberId = 48;  // Grid bottom-right
  uint32_t brokerId = 24;      // Near center
  uint32_t newBrokerId = 25;   // Near original broker
  
  // Create and install applications
  ApplicationContainer apps;
  
  for (uint32_t i = 0; i < numNodes; i++)
  {
    Ptr<BrokerApp> app = CreateObject<BrokerApp>();
    
    if (i == publisherId)
    {
      app->SetNodeRole(BrokerApp::PUBLISHER);
      app->SetCurrentBrokerId(brokerId);
      NS_LOG_INFO("Node " << i << " is publisher");
    }
    else if (i == subscriberId)
    {
      app->SetNodeRole(BrokerApp::SUBSCRIBER);
      app->SetCurrentBrokerId(brokerId);
      NS_LOG_INFO("Node " << i << " is subscriber");
    }
    else if (i == brokerId)
    {
      app->SetNodeRole(BrokerApp::BROKER);
      app->SetCurrentBrokerId(i);
      NS_LOG_INFO("Node " << i << " is broker");
    }
    else
    {
      app->SetNodeRole(BrokerApp::REGULAR);
    }
    
    nodes.Get(i)->AddApplication(app);
    app->SetStartTime(Seconds(1.0));
    app->SetStopTime(Seconds(simulationTime + 1.0));
    apps.Add(app);
  }
  
  // Schedule broker migration at 150 seconds (same as NDN implementation)
  Simulator::Schedule(Seconds(150.0), [&] {
    NS_LOG_INFO("Scheduled broker migration about to start: from node " 
                << brokerId << " to node " << newBrokerId);
    
    Ptr<BrokerApp> brokerApp = DynamicCast<BrokerApp>(nodes.Get(brokerId)->GetApplication(0));
    if (brokerApp)
    {
      NS_LOG_INFO("Executing broker migration");
      brokerApp->TriggerBrokerMigration(newBrokerId);
      NS_LOG_INFO("Broker migration scheduled");
    }
    else
    {
      NS_LOG_ERROR("Failed to get broker application");
    }
  });
  
  // Enable flow monitoring
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();
  
  // Enable animation
  AnimationInterface anim("aodv-broker-migration.xml");
  
  // Run simulation
  NS_LOG_INFO("Running simulation for " << simulationTime << " seconds");
  Simulator::Stop(Seconds(simulationTime));
  
  try
  {
    Simulator::Run();
  }
  catch (const std::exception& e)
  {
    NS_LOG_ERROR("Exception during simulation: " << e.what());
  }
  
  // Collect statistics
  monitor->CheckForLostPackets();
  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
  
  std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();
  
  NS_LOG_INFO("Flow statistics:");
  for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin(); i != stats.end(); i++)
  {
    Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(i->first);
    NS_LOG_INFO("Flow " << i->first << " (" << t.sourceAddress << " -> " << t.destinationAddress << ")");
    NS_LOG_INFO("  Tx Packets: " << i->second.txPackets);
    NS_LOG_INFO("  Rx Packets: " << i->second.rxPackets);
    
    double duration = i->second.timeLastRxPacket.GetSeconds() - i->second.timeFirstTxPacket.GetSeconds();
    if (duration > 0)
    {
      NS_LOG_INFO("  Throughput: " << i->second.rxBytes * 8.0 / duration / 1024 << " Kbps");
    }
  }
  
  // Output AODV-specific results
  Time avgNotificationDelay = BrokerApp::GetAverageNotificationDelay();
  Time unicastDelay = BrokerApp::GetNotificationDelayByType(UNICAST_NOTIFICATION);
  Time routeDelay = BrokerApp::GetNotificationDelayByType(AODV_ROUTE_NOTIFICATION);
  Time broadcastDelay = BrokerApp::GetNotificationDelayByType(BROADCAST_NOTIFICATION);
  double messageSuccessRate = BrokerApp::GetMessageSuccessRate();
  
  NS_LOG_INFO("AODV Broker Migration Results:");
  NS_LOG_INFO("  Average Notification Delay: " << avgNotificationDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  Unicast Notification Delay: " << unicastDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  AODV Route Notification Delay: " << routeDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  Broadcast Notification Delay: " << broadcastDelay.GetSeconds() << " seconds");
  NS_LOG_INFO("  Message Success Rate: " << messageSuccessRate * 100.0 << "%");
  NS_LOG_INFO("  Messages Sent: " << BrokerApp::GetMessagesSent());
  NS_LOG_INFO("  Messages Received: " << BrokerApp::GetMessagesReceived());
  
  // Write results to CSV file
  std::ofstream resultFile;
  resultFile.open("aodv-results.csv");
  resultFile << "Metric,Value\n";
  resultFile << "AverageNotificationDelay," << avgNotificationDelay.GetSeconds() << "\n";
  resultFile << "UnicastNotificationDelay," << unicastDelay.GetSeconds() << "\n";
  resultFile << "RouteNotificationDelay," << routeDelay.GetSeconds() << "\n";
  resultFile << "BroadcastNotificationDelay," << broadcastDelay.GetSeconds() << "\n";
  resultFile << "MessageSuccessRate," << messageSuccessRate * 100.0 << "\n";
  resultFile << "MessagesSent," << BrokerApp::GetMessagesSent() << "\n";
  resultFile << "MessagesReceived," << BrokerApp::GetMessagesReceived() << "\n";
  resultFile.close();
  
  // Clean up
  Simulator::Destroy();
  
  return 0;
}